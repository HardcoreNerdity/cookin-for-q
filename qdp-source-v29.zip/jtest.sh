#!/bin/bash
# Run a pure-logic Java test on the desktop JVM with a real org.json.
# Usage: ./jtest.sh <fully.qualified.MainClass> <test source files...>
# Tests live under test/ ; app sources are found via -sourcepath app/src. Tests must not touch android.* classes
# (anything that imports android.* cannot run on the desktop JVM).
cd "$(dirname "$0")"
OUT="build/jtest-$$"
mkdir -p "$OUT"
javac -nowarn -encoding UTF-8 -proc:none -cp tc/orgjson.jar -sourcepath app/src:test -d "$OUT" "${@:2}" 2>&1 | grep -v JAVA_TOOL_OPTIONS
java -cp "$OUT:tc/orgjson.jar" "$1" 2>&1 | grep -v JAVA_TOOL_OPTIONS
rm -rf "$OUT"
