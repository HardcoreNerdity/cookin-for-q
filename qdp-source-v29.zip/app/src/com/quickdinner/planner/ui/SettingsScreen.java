package com.quickdinner.planner.ui;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.quickdinner.planner.App;
import com.quickdinner.planner.data.Callback;
import com.quickdinner.planner.data.Store;
import com.quickdinner.planner.fx.Beverly;
import com.quickdinner.planner.model.Models;
import com.quickdinner.planner.notif.NotifSettings;
import com.quickdinner.planner.ui.Icons;
import com.quickdinner.planner.ui.Ui;
import com.quickdinner.planner.update.ReleaseInfo;
import com.quickdinner.planner.update.Updater;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/* loaded from: classes.dex */
public final class SettingsScreen extends BaseScreen {
    private boolean codeShown;
    private ScrollView sv;

    public SettingsScreen(Activity a) {
        super(a);
    }

    private static <V extends View> V full(V v) {
        v.setLayoutParams(Ui.lp(-1, -2));
        return v;
    }

    @Override // com.quickdinner.planner.ui.BaseScreen
    public void render() {
        ScrollView scrollView = this.sv;
        final int scrollY = scrollView == null ? 0 : scrollView.getScrollY();
        LinearLayout vbox = Ui.vbox(this.act);
        vbox.setPadding(Ui.dp(this.act, 16.0f), Ui.dp(this.act, 4.0f), Ui.dp(this.act, 16.0f), Ui.dp(this.act, 32.0f));
        Store store = App.store();
        if (store == null) {
            vbox.addView(Ui.emptyState(this.act, "Not connected", "Join or start a household first."));
        } else {
            household(vbox, store);
            householdSettings(vbox, store);
            thisPhone(vbox);
            vbox.addView(com.quickdinner.planner.weather.WeatherSettings.build(this.act, new Runnable() {
                @Override public void run() { render(); }
            }));
            updatesCard(vbox);
            vbox.addView(Ui.sectionTitle(this.act, "NOTIFICATIONS"));
            try {
                View build = NotifSettings.build(this.act);
                if (build != null) {
                    vbox.addView(build);
                }
            } catch (RuntimeException unused) {
                vbox.addView(Ui.muted(this.act, "Notification settings are not available."));
            }
            sync(vbox, store);
            vbox.addView(Ui.margins((Button) full(Ui.button(this.act, "Leave household", 4, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.1
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    Ui.confirm(SettingsScreen.this.act, "Leave this household?", "This phone will forget the household and its data. You can join again later with the code.", "Leave", new Runnable() { // from class: com.quickdinner.planner.ui.SettingsScreen.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            App.session().leave();
                        }
                    });
                }
            })), 0, 28, 0, 0));
            vbox.addView(Ui.sectionTitle(this.act, "ABOUT"));
            vbox.addView(Ui.muted(this.act, "Permissions: Internet, Notifications, Start at boot (to keep notification checks running). Nothing else."));
        }
        ScrollView scroll = Ui.scroll(this.act, vbox);
        this.sv = scroll;
        setContent(scroll);
        if (scrollY > 0) {
            this.sv.post(new Runnable() { // from class: com.quickdinner.planner.ui.SettingsScreen.2
                @Override // java.lang.Runnable
                public void run() {
                    SettingsScreen.this.sv.scrollTo(0, scrollY);
                }
            });
        }
    }

    private void household(LinearLayout col, final Store st) {
        col.addView(Ui.sectionTitle(this.act, "HOUSEHOLD"));
        ArrayList arrayList = new ArrayList(st.members.all());
        Collections.sort(arrayList, new Comparator<Models.Member>() { // from class: com.quickdinner.planner.ui.SettingsScreen.3
            @Override // java.util.Comparator
            public int compare(Models.Member a, Models.Member b) {
                return Long.compare(a.joinedAt, b.joinedAt);
            }
        });
        boolean isAdmin = st.isAdmin();
        LinearLayout card = Ui.card(this.act);
        if (arrayList.isEmpty()) {
            card.addView(Ui.muted(this.act, "Loading members..."));
        }
        for (int i = 0; i < arrayList.size(); i++) {
            final Models.Member member = (Models.Member) arrayList.get(i);
            LinearLayout hbox = Ui.hbox(this.act);
            hbox.setMinimumHeight(Ui.dp(this.act, 52.0f));
            hbox.addView(Ui.avatar(this.act, member, 36));
            StringBuilder sb = new StringBuilder();
            sb.append(member.name);
            sb.append((member.id == null || !member.id.equals(st.meId())) ? "" : " (you)");
            String sb2 = sb.toString();
            LinearLayout.LayoutParams lpw = Ui.lpw(0, -2, 1.0f);
            lpw.leftMargin = Ui.dp(this.act, 12.0f);
            lpw.rightMargin = Ui.dp(this.act, 8.0f);
            hbox.addView(Ui.body(this.act, sb2), lpw);
            if (member.isAdmin) {
                hbox.addView(Ui.chip(this.act, "Admin", Ui.TEAL, false));
            }
            if (member.id != null && member.id.equals(st.meId())) {
                hbox.addView(Ui.button(this.act, "Edit look", 2, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View v) {
                        ProfileSheet.show(SettingsScreen.this.act, st);
                    }
                }));
            }
            if (isAdmin && member.id != null && !member.id.equals(st.meId())) {
                hbox.addView(Ui.iconButton(this.act, Icons.Type.MORE, Ui.MUTED, "Actions for " + member.name, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View v) {
                        SettingsScreen.this.memberActions(st, member);
                    }
                }));
            }
            card.addView(hbox, Ui.lp(-1, -2));
            if (i < arrayList.size() - 1) {
                card.addView(Ui.divider(this.act));
            }
        }
        int i2 = Ui.MUTED;
        col.addView(card);
        final Activity activity = this.act;
        LinearLayout card2 = Ui.card(this.act);
        card2.addView(Ui.text(this.act, "Household code", 16.0f, Ui.TEXT, true));
        final String householdCode = App.session().householdCode();
        Activity activity2 = this.act;
        boolean z = this.codeShown;
        String str = (!z || householdCode == null) ? "••••-••••-••••-••••-••••" : householdCode;
        if (z) {
            i2 = Ui.AMBER;
        }
        TextView text = Ui.text(activity2, str, 20.0f, i2, true);
        text.setTypeface(Typeface.MONOSPACE, 1);
        card2.addView(Ui.margins(text, 0, 10, 0, 10));
        LinearLayout hbox2 = Ui.hbox(this.act);
        hbox2.addView(Ui.button(this.act, this.codeShown ? "Hide" : "Show", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.6
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                SettingsScreen.this.codeShown = !SettingsScreen.this.codeShown;
                SettingsScreen.this.render();
            }
        }), Ui.lpw(0, -2, 1.0f));
        LinearLayout.LayoutParams lpw2 = Ui.lpw(0, -2, 1.0f);
        lpw2.leftMargin = Ui.dp(this.act, 8.0f);
        hbox2.addView(Ui.button(this.act, "Copy", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.7
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                String str2 = householdCode;
                if (str2 != null) {
                    Ui.copy(activity, "Household code", str2);
                }
            }
        }), lpw2);
        card2.addView(hbox2, Ui.lp(-1, -2));
        card2.addView(Ui.margins((Button) full(Ui.button(this.act, "Share invite", 0, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.8
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                String inviteText = App.session().inviteText();
                if (inviteText != null) {
                    Ui.share(activity, inviteText);
                }
            }
        })), 0, 10, 0, 0));
        if (isAdmin) {
            card2.addView(Ui.margins((Button) full(Ui.button(this.act, "Change code (cuts off removed people)", 4, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.9
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    SettingsScreen.this.rotate();
                }
            })), 0, 10, 0, 0));
        }
        col.addView(Ui.margins(card2, 0, 12, 0, 0));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void rotate() {
        Ui.confirm(this.act, "Change the household code?", "Everything is re-locked with a new code. Everyone, including you on other phones, must join again with the new code. People you removed will be cut off.", "Change code", new Runnable() { // from class: com.quickdinner.planner.ui.SettingsScreen.10
            @Override // java.lang.Runnable
            public void run() {
                Ui.toast(SettingsScreen.this.act, "Changing code...");
                App.session().rotateCode(new Callback<String>() { // from class: com.quickdinner.planner.ui.SettingsScreen.10.1
                    @Override // com.quickdinner.planner.data.Callback
                    public void done(String value, String error) {
                        if (error == null && value != null) {
                            SettingsScreen.this.showNewCode(value);
                            return;
                        }
                        Activity activity = SettingsScreen.this.act;
                        if (error == null) {
                            error = "Could not change the code";
                        }
                        Ui.toast(activity, error);
                    }
                });
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showNewCode(final String code) {
        LinearLayout vbox = Ui.vbox(this.act);
        vbox.addView(Ui.body(this.act, "Your new household code. Share it with the people who should stay."));
        TextView text = Ui.text(this.act, code, 22.0f, Ui.AMBER, true);
        text.setTypeface(Typeface.MONOSPACE, 1);
        text.setTextIsSelectable(true);
        vbox.addView(Ui.margins(text, 0, 14, 0, 14));
        vbox.addView(full(Ui.button(this.act, "Copy", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.11
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Ui.copy(SettingsScreen.this.act, "Household code", code);
            }
        })));
        vbox.addView(Ui.margins((Button) full(Ui.button(this.act, "Share invite", 0, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.12
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                String inviteText = App.session().inviteText();
                Activity activity = SettingsScreen.this.act;
                if (inviteText == null) {
                    inviteText = code;
                }
                Ui.share(activity, inviteText);
            }
        })), 0, 10, 0, 0));
        Ui.sheet(this.act, "New code", vbox);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void memberActions(final Store st, final Models.Member m) {
        final Ui.Sheet[] sheetArr = new Ui.Sheet[1];
        LinearLayout vbox = Ui.vbox(this.act);
        vbox.addView(full(Ui.button(this.act, m.isAdmin ? "Remove admin" : "Make admin", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.13
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                sheetArr[0].dismiss();
                Models.Member member = new Models.Member();
                member.id = m.id;
                member.name = m.name;
                member.colorIdx = m.colorIdx;
                member.joinedAt = m.joinedAt;
                member.customColor = m.customColor;
                member.photo = m.photo;
                member.isAdmin = !m.isAdmin;
                st.members.put(member);
            }
        })));
        vbox.addView(Ui.margins((Button) full(Ui.button(this.act, "Remove from household", 4, new AnonymousClass14(sheetArr, m))), 0, 10, 0, 0));
        sheetArr[0] = Ui.sheet(this.act, m.name, vbox);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.quickdinner.planner.ui.SettingsScreen$14, reason: invalid class name */
    /* loaded from: classes.dex */
    public class AnonymousClass14 implements View.OnClickListener {
        final /* synthetic */ Ui.Sheet[] val$holder;
        final /* synthetic */ Models.Member val$m;

        AnonymousClass14(final Ui.Sheet[] val$holder, final Models.Member val$m) {
            this.val$holder = val$holder;
            this.val$m = val$m;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            this.val$holder[0].dismiss();
            Ui.confirm(SettingsScreen.this.act, "Remove " + this.val$m.name + "?", "They will lose access after you change the code. Use \"Change code\" next to finish cutting them off.", "Remove", new Runnable() { // from class: com.quickdinner.planner.ui.SettingsScreen.14.1
                @Override // java.lang.Runnable
                public void run() {
                    App.session().removeMember(AnonymousClass14.this.val$m.id, new Callback<Void>() { // from class: com.quickdinner.planner.ui.SettingsScreen.14.1.1
                        @Override // com.quickdinner.planner.data.Callback
                        public void done(Void value, String error) {
                            if (error != null) {
                                Ui.toast(SettingsScreen.this.act, error);
                            }
                        }
                    });
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Models.Settings copy(Models.Settings s) {
        Models.Settings settings = new Models.Settings();
        settings.id = "main";
        settings.enabledSlots = new ArrayList(s.enabledSlots);
        settings.allowVoteOwnEntry = s.allowVoteOwnEntry;
        settings.pantryPurchasedAutoAdd = s.pantryPurchasedAutoAdd;
        settings.eatenSubtractsPantry = s.eatenSubtractsPantry;
        return settings;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.quickdinner.planner.ui.SettingsScreen$27, reason: invalid class name */
    /* loaded from: classes.dex */
    public static /* synthetic */ class AnonymousClass27 {
        static final /* synthetic */ int[] $SwitchMap$com$quickdinner$planner$model$Models$Slot;

        static {
            int[] iArr = new int[Models.Slot.values().length];
            $SwitchMap$com$quickdinner$planner$model$Models$Slot = iArr;
            try {
                iArr[Models.Slot.BREAKFAST.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$quickdinner$planner$model$Models$Slot[Models.Slot.LUNCH.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    private static String slotName(Models.Slot s) {
        int i = AnonymousClass27.$SwitchMap$com$quickdinner$planner$model$Models$Slot[s.ordinal()];
        return i != 1 ? i != 2 ? "Dinner" : "Lunch" : "Breakfast";
    }

    private View lockIf(View v, boolean locked) {
        if (locked) {
            v.setAlpha(0.5f);
            disable(v);
        }
        return v;
    }

    private static void disable(View v) {
        v.setEnabled(false);
        v.setClickable(false);
        if (v instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) v;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                disable(viewGroup.getChildAt(i));
            }
        }
    }

    private void householdSettings(LinearLayout col, final Store st) {
        boolean isAdmin = st.isAdmin();
        col.addView(Ui.sectionTitle(this.act, "HOUSEHOLD SETTINGS"));
        if (!isAdmin) {
            col.addView(Ui.margins(Ui.muted(this.act, "Only admins can change these."), 0, 0, 0, 6));
        }
        Models.Settings settings = st.settings();
        LinearLayout card = Ui.card(this.act);
        card.addView(lockIf(Ui.switchRow(this.act, "Allow voting on your own entry", null, settings.allowVoteOwnEntry, new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.15
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Models.Settings copy = SettingsScreen.copy(st.settings());
                copy.allowVoteOwnEntry = on;
                st.settingsDocs.put(copy);
            }
        }), !isAdmin));
        for (final Models.Slot slot : Models.Slot.values()) {
            card.addView(lockIf(Ui.switchRow(this.act, "Plan " + slotName(slot).toLowerCase(), null, settings.enabledSlots.contains(slot), new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.16
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public void onCheckedChanged(final CompoundButton b, boolean now) {
                    Models.Settings copy = SettingsScreen.copy(st.settings());
                    if (now) {
                        if (!copy.enabledSlots.contains(slot)) {
                            copy.enabledSlots.add(slot);
                        }
                    } else {
                        copy.enabledSlots.remove(slot);
                        if (copy.enabledSlots.isEmpty()) {
                            Ui.toast(SettingsScreen.this.act, "At least one meal stays on");
                            b.post(new Runnable() { // from class: com.quickdinner.planner.ui.SettingsScreen.16.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    SettingsScreen.this.render();
                                }
                            });
                            return;
                        }
                    }
                    Collections.sort(copy.enabledSlots);
                    st.settingsDocs.put(copy);
                }
            }), !isAdmin));
        }
        card.addView(lockIf(Ui.switchRow(this.act, "Add purchased items to On hand", "When you tick an item as bought, it goes on the On hand list.", settings.pantryPurchasedAutoAdd, new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.17
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Models.Settings copy = SettingsScreen.copy(st.settings());
                copy.pantryPurchasedAutoAdd = on;
                st.settingsDocs.put(copy);
            }
        }), !isAdmin));
        card.addView(lockIf(Ui.switchRow(this.act, "Eaten meals use up On hand items", "When a meal is marked eaten, its ingredients come off the On hand list.", settings.eatenSubtractsPantry, new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.18
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Models.Settings copy = SettingsScreen.copy(st.settings());
                copy.eatenSubtractsPantry = on;
                st.settingsDocs.put(copy);
            }
        }), !isAdmin));
        col.addView(card);
    }

    private void updatesCard(final LinearLayout col) {
        final ReleaseInfo releaseInfo = Updater.available;
        int installedVersion = Updater.installedVersion(this.act);
        col.addView(Ui.sectionTitle(this.act, "APP UPDATES"));
        LinearLayout card = Ui.card(this.act);
        card.addView(Ui.body(this.act, "You have version " + installedVersion));
        if (releaseInfo != null && releaseInfo.version > installedVersion) {
            card.addView(Ui.margins(Ui.text(this.act, "Version " + releaseInfo.version + " is available.", 15.0f, Ui.AMBER, true), 0, 6, 0, 8));
            card.addView(full(Ui.button(this.act, "Download and install", 0, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.19
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    Ui.toast(SettingsScreen.this.act, "Downloading...");
                    Updater.install(SettingsScreen.this.act, releaseInfo, new Updater.Progress() { // from class: com.quickdinner.planner.ui.SettingsScreen.19.1
                        @Override // com.quickdinner.planner.update.Updater.Progress
                        public void progress(int percent) {
                        }

                        @Override // com.quickdinner.planner.update.Updater.Progress
                        public void finished(String error) {
                            if (error != null) {
                                Ui.toast(SettingsScreen.this.act, error);
                            }
                        }
                    });
                }
            })));
        } else {
            card.addView(Ui.margins((Button) full(Ui.button(this.act, "Check for updates", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.20
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    Ui.toast(SettingsScreen.this.act, "Checking...");
                    Updater.check(SettingsScreen.this.act, new Updater.Done() { // from class: com.quickdinner.planner.ui.SettingsScreen.20.1
                        @Override // com.quickdinner.planner.update.Updater.Done
                        public void done(ReleaseInfo newer, String error) {
                            if (error != null) {
                                Ui.toast(SettingsScreen.this.act, error);
                            } else if (newer == null) {
                                Ui.toast(SettingsScreen.this.act, "You're up to date.");
                            }
                            SettingsScreen.this.render();
                        }
                    });
                }
            })), 0, 8, 0, 0));
        }
        card.addView(Ui.switchRow(this.act, "Check automatically", "Looks once a day. This contacts GitHub (it sees your phone's internet address, nothing else).", Updater.autoCheck(), new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.21
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                App.prefs().putBool(Updater.PREF_AUTO, on);
            }
        }));
        col.addView(card);
    }

    private void thisPhone(LinearLayout col) {
        col.addView(Ui.sectionTitle(this.act, "ON THIS PHONE"));
        LinearLayout card = Ui.card(this.act);
        card.addView(Ui.switchRow(this.act, "Beverly mode 🐶", "Beverly's face. Everywhere. Shake your phone for a storm.", App.prefs().getBool(Beverly.PREF, false), new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.22
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                App.prefs().putBool(Beverly.PREF, on);
                if (on) {
                    Beverly.storm(SettingsScreen.this.act);
                }
            }
        }));
        card.addView(Ui.switchRow(this.act, "Woof sounds", "Little barks with the effects (follows your notification volume)", App.prefs().getBool(Beverly.PREF_SOUND, false), new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.23
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                App.prefs().putBool(Beverly.PREF_SOUND, on);
                if (on) {
                    Beverly.rain(SettingsScreen.this.act, 6);
                }
            }
        }));
        card.addView(Ui.switchRow(this.act, "Show On hand section", "Turn off to hide On hand everywhere, including alerts", App.prefs().pantryEnabled(), new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.24
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton b, boolean on) {
                App.prefs().setPantryEnabled(on);
            }
        }));
        for (final Models.Slot slot : Models.Slot.values()) {
            card.addView(Ui.switchRow(this.act, "Hide " + slotName(slot).toLowerCase() + " on my phone", null, App.prefs().hiddenSlots().contains(slot), new CompoundButton.OnCheckedChangeListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.25
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public void onCheckedChanged(CompoundButton b, boolean on) {
                    App.prefs().setSlotHidden(slot, on);
                }
            }));
        }
        col.addView(card);
    }

    private void sync(LinearLayout col, final Store st) {
        String str;
        TextView text;
        col.addView(Ui.sectionTitle(this.act, "SYNC"));
        LinearLayout card = Ui.card(this.act);
        String syncError = st.syncError();
        if (syncError != null) {
            text = Ui.text(this.act, syncError, 15.0f, Ui.CORAL, false);
        } else {
            long lastSyncMs = st.lastSyncMs();
            if (lastSyncMs <= 0) {
                str = "Not synced yet";
            } else {
                long currentTimeMillis = (System.currentTimeMillis() - lastSyncMs) / 1000;
                if (currentTimeMillis < 30) {
                    str = "Synced just now";
                } else if (currentTimeMillis < 3600) {
                    str = "Synced " + Math.max(1L, currentTimeMillis / 60) + " min ago";
                } else {
                    str = "Synced " + (currentTimeMillis / 3600) + " h ago";
                }
            }
            text = Ui.text(this.act, str, 15.0f, Ui.TEXT, false);
        }
        card.addView(text);
        card.addView(Ui.margins((Button) full(Ui.button(this.act, "Sync now", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.ui.SettingsScreen.26
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                st.syncNow();
                Ui.toast(SettingsScreen.this.act, "Syncing...");
                v.postDelayed(new Runnable() { // from class: com.quickdinner.planner.ui.SettingsScreen.26.1
                    @Override // java.lang.Runnable
                    public void run() {
                        SettingsScreen.this.render();
                    }
                }, 1500L);
            }
        })), 0, 10, 0, 0));
        col.addView(card);
    }
}
