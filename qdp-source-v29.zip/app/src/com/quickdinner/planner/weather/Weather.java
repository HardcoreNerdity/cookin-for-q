package com.quickdinner.planner.weather;

import android.app.Activity;
import android.widget.TextView;

import com.quickdinner.planner.App;
import com.quickdinner.planner.data.Bg;
import com.quickdinner.planner.data.Callback;
import com.quickdinner.planner.ui.Ui;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Optional weather on day cards and the printed menu. Off by default; set up per phone in Settings. */
public final class Weather {
    private Weather() {}

    private static final String ON = "wxOn", LAT = "wxLat", LON = "wxLon", PLACE = "wxPlace", UNIT = "wxUnit",
            DATA = "wxData", WHEN = "wxWhen", PRINT = "wxPrint";
    private static final long FRESH_MS = 3L * 60 * 60 * 1000;

    private static Map<String, WeatherData.Day> days;      // loaded lazily from the saved answer
    private static boolean loading;
    private static final List<Object[]> views = new ArrayList<>();   // {WeakReference<TextView>, iso date}

    /** The saved forecast lives apart from the app's other settings, so refreshing it never redraws screens. */
    private static android.content.SharedPreferences cache() {
        return App.get().getSharedPreferences("qdp_weather", 0);
    }

    public static boolean enabled() {
        try { return App.prefs().getBool(ON, false) && hasPlace(); } catch (Throwable t) { return false; }
    }

    /** Also print the weather on the paper menu (on by default once weather is on). */
    public static boolean printOn() { return enabled() && App.prefs().getBool(PRINT, true); }

    public static void setPrint(boolean on) { App.prefs().putBool(PRINT, on); }

    public static boolean switchedOn() { return App.prefs().getBool(ON, false); }

    public static boolean hasPlace() { return !App.prefs().getString(PLACE, "").isEmpty(); }

    public static String placeName() { return App.prefs().getString(PLACE, ""); }

    public static boolean fahrenheit() {
        String u = App.prefs().getString(UNIT, "");
        if (u.isEmpty()) return Locale.getDefault().getCountry().equals("US");
        return u.equals("F");
    }

    public static void setFahrenheit(boolean f) {
        App.prefs().putString(UNIT, f ? "F" : "C");
        forget();
        refresh(true);
    }

    public static void setOn(boolean on) {
        App.prefs().putBool(ON, on);
        if (on) refresh(false);
    }

    public static void setPlace(WeatherData.Place p) {
        App.prefs().putString(PLACE, p.label());
        App.prefs().putString(LAT, WeatherData.coarse(p.lat));
        App.prefs().putString(LON, WeatherData.coarse(p.lon));
        forget();
        refresh(true);
    }

    /** Throws away the saved answer (place or unit changed). */
    private static void forget() {
        days = null;
        cache().edit().remove(DATA).remove(WHEN).apply();
    }

    /** The weather for one day (yyyy-MM-dd), or null when off or not known. */
    public static WeatherData.Day forDay(String iso) {
        if (!enabled()) return null;
        load();
        return days == null ? null : days.get(iso);
    }

    private static void load() {
        if (days != null) return;
        String saved = cache().getString(DATA, "");
        days = saved.isEmpty() ? new java.util.LinkedHashMap<String, WeatherData.Day>() : WeatherData.parseForecast(saved);
    }

    /** Fills a small text view for a day card now, and again when fresh data arrives. */
    public static void attach(TextView tv, String iso) {
        if (!enabled()) return;
        views.add(new Object[]{new WeakReference<TextView>(tv), iso});
        paint(tv, iso);
        refresh(false);
    }

    private static void paint(TextView tv, String iso) {
        WeatherData.Day d = forDay(iso);
        tv.setText(d == null ? "" : WeatherData.shortLine(d));
        tv.setContentDescription(d == null ? null : "Weather: " + WeatherData.printLine(d));
    }

    private static void repaintAll() {
        List<Object[]> keep = new ArrayList<>();
        for (Object[] v : views) {
            TextView tv = ((WeakReference<TextView>) v[0]).get();
            if (tv == null) continue;
            paint(tv, (String) v[1]);
            keep.add(v);
        }
        views.clear();
        views.addAll(keep);
    }

    /** Asks the weather service for the forecast when ours is old (or when forced). Never blocks the screen. */
    public static void refresh(final boolean force) {
        if (!enabled() || loading) return;
        long age = System.currentTimeMillis() - cache().getLong(WHEN, 0);
        if (!force && age < FRESH_MS && cache().getString(DATA, "").length() > 0) return;
        final String lat = App.prefs().getString(LAT, ""), lon = App.prefs().getString(LON, "");
        if (lat.isEmpty() || lon.isEmpty()) return;
        loading = true;
        final boolean f = fahrenheit();
        Bg.run(new Runnable() { public void run() {
            String body = null;
            try {
                body = get(WeatherData.forecastUrl(Double.parseDouble(lat), Double.parseDouble(lon), f));
            } catch (Exception ignored) { }
            final String answer = body;
            Bg.main(new Runnable() { public void run() {
                loading = false;
                if (answer != null && !WeatherData.parseForecast(answer).isEmpty()) {
                    cache().edit().putString(DATA, answer).putLong(WHEN, System.currentTimeMillis()).apply();
                    days = null;
                    repaintAll();
                }
            } });
        } });
    }

    /** City search; result (or an error text) comes back on the main thread. */
    public static void search(final String query, final Callback<List<WeatherData.Place>> cb) {
        Bg.run(new Runnable() { public void run() {
            List<WeatherData.Place> found = null;
            String err = null;
            try {
                found = WeatherData.parsePlaces(get(WeatherData.placesUrl(query)));
            } catch (Exception e) {
                err = "Couldn't reach the weather service.";
            }
            final List<WeatherData.Place> r = found;
            final String e = err;
            Bg.main(new Runnable() { public void run() { cb.done(r, e); } });
        } });
    }

    private static String get(String url) throws Exception {
        if (!url.startsWith("https://")) throw new IllegalArgumentException("https only");
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", "QuickDinnerPlanning");
            if (c.getResponseCode() != 200) throw new java.io.IOException("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > 300000) throw new java.io.IOException("too big");
            }
            in.close();
            return out.toString("UTF-8");
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
