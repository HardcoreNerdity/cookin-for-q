package com.quickdinner.planner.weather;

import android.app.Activity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import com.quickdinner.planner.data.Callback;
import com.quickdinner.planner.ui.Ui;

import java.util.List;

/** The "Weather" card in Settings (this phone only). */
public final class WeatherSettings {
    private WeatherSettings() {}

    /** @param changed called after anything changes, so the screen can redraw. */
    public static View build(final Activity act, final Runnable changed) {
        LinearLayout col = Ui.vbox(act);
        col.addView(Ui.sectionTitle(act, "WEATHER"));
        LinearLayout card = Ui.card(act);
        card.addView(Ui.switchRow(act, "Show weather on days", "High and low temperature and the sky, on each day and (if you like) on the printed menu.",
            Weather.switchedOn(), new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    Weather.setOn(on);
                    if (on && !Weather.hasPlace()) pickPlace(act, changed);
                    else if (changed != null) changed.run();
                }
            }));
        if (Weather.switchedOn()) {
            card.addView(Ui.divider(act));
            card.addView(Ui.body(act, "Place"));
            card.addView(Ui.muted(act, Weather.hasPlace() ? Weather.placeName() : "Not chosen yet"));
            card.addView(Ui.margins(Ui.button(act, Weather.hasPlace() ? "Change place" : "Choose place", Ui.OUTLINE, new View.OnClickListener() {
                @Override public void onClick(View v) { pickPlace(act, changed); }
            }), 0, 6, 0, 8));
            card.addView(Ui.switchRow(act, "Print weather on the menu", "A small line under each day's meals.", Weather.printOn(),
                new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean on) { Weather.setPrint(on); }
                }));
            card.addView(Ui.body(act, "Temperature"));
            card.addView(Ui.segmented(act, new String[]{"°F", "°C"}, Weather.fahrenheit() ? 0 : 1, new Ui.IntPick() {
                @Override public void pick(int i) {
                    Weather.setFahrenheit(i == 0);
                    if (changed != null) changed.run();
                }
            }));
        }
        card.addView(Ui.margins(Ui.muted(act, "Privacy: when this is on, this phone asks Open-Meteo, a free weather service, for the forecast. "
            + "They can see your phone's internet address and the rough area (about 6 miles) of the place you pick. Nothing else is sent. "
            + "Each person sets this on their own phone."), 0, 8, 0, 0));
        col.addView(card);
        return col;
    }

    private static void pickPlace(final Activity act, final Runnable changed) {
        Ui.prompt(act, "Find your city", "City name, e.g. Albany", "", new Callback<String>() {
            @Override public void done(String query, String err) {
                if (query == null || query.trim().isEmpty()) return;
                Ui.toast(act, "Searching...");
                Weather.search(query, new Callback<List<WeatherData.Place>>() {
                    @Override public void done(List<WeatherData.Place> places, String error) {
                        if (error != null) { Ui.toast(act, error); return; }
                        if (places == null || places.isEmpty()) { Ui.toast(act, "No place found. Try just the city name."); return; }
                        showResults(act, places, changed);
                    }
                });
            }
        });
    }

    private static void showResults(final Activity act, List<WeatherData.Place> places, final Runnable changed) {
        final Ui.Sheet[] sh = new Ui.Sheet[1];
        LinearLayout box = Ui.vbox(act);
        for (final WeatherData.Place p : places) {
            box.addView(Ui.margins(Ui.button(act, p.label(), Ui.OUTLINE, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Weather.setPlace(p);
                    sh[0].dismiss();
                    if (changed != null) changed.run();
                }
            }), 0, 0, 0, 8));
        }
        sh[0] = Ui.sheet(act, "Pick your place", box);
    }
}
