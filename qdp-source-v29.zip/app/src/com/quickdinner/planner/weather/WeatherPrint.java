package com.quickdinner.planner.weather;

import com.quickdinner.planner.print.MenuData;
import com.quickdinner.planner.print.PrintDesign;

/**
 * Hooks used by the printed menu. PrintMenu.buildData calls fill() for every day, and the page drawing calls
 * hasNote() / noteText() where it used to print only the day's note.
 */
public final class WeatherPrint {
    private WeatherPrint() {}

    /** Called once per day while the menu data is built. */
    public static void fill(MenuData.Day day) {
        day.weather = null;
        try {
            if (!Weather.printOn() || day.date == null) return;
            WeatherData.Day w = Weather.forDay(day.date.toString());
            if (w != null) day.weather = WeatherData.printLine(w);
            Weather.refresh(false);
        } catch (Throwable ignored) { }
    }

    private static boolean userNote(PrintDesign d, MenuData.Day day) {
        return d.notes && day.note != null && !day.note.isEmpty();
    }

    /** Does this day get a small line under its meals? */
    public static boolean hasNote(PrintDesign d, MenuData.Day day) {
        return userNote(d, day) || (day.weather != null && !day.weather.isEmpty());
    }

    /** The text of that line: weather first, then the day's note (when notes are switched on). */
    public static String noteText(PrintDesign d, MenuData.Day day) {
        StringBuilder sb = new StringBuilder();
        if (day.weather != null && !day.weather.isEmpty()) sb.append(day.weather);
        if (userNote(d, day)) {
            if (sb.length() > 0) sb.append("   ·   ");
            sb.append("Note: ").append(day.note);
        }
        return sb.toString();
    }
}
