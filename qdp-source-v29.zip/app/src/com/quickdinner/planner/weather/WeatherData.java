package com.quickdinner.planner.weather;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Pure Java (no android.*): reads Open-Meteo answers and turns weather codes into words and symbols. */
public final class WeatherData {
    private WeatherData() {}

    public static final class Day {
        public final String date;   // yyyy-MM-dd
        public final int hi, lo, code;
        public Day(String date, int hi, int lo, int code) { this.date = date; this.hi = hi; this.lo = lo; this.code = code; }
    }

    public static final class Place {
        public final String name, detail;
        public final double lat, lon;
        public Place(String name, String detail, double lat, double lon) { this.name = name; this.detail = detail; this.lat = lat; this.lon = lon; }
        public String label() { return detail.isEmpty() ? name : name + ", " + detail; }
    }

    /** Daily forecast JSON -> date -> Day. Empty map when the answer is not usable. */
    public static Map<String, Day> parseForecast(String json) {
        Map<String, Day> out = new LinkedHashMap<>();
        try {
            JSONObject daily = new JSONObject(json).optJSONObject("daily");
            if (daily == null) return out;
            JSONArray t = daily.optJSONArray("time"), hi = daily.optJSONArray("temperature_2m_max"),
                    lo = daily.optJSONArray("temperature_2m_min"), code = daily.optJSONArray("weather_code");
            if (t == null || hi == null || lo == null || code == null) return out;
            for (int i = 0; i < t.length(); i++) {
                if (hi.isNull(i) || lo.isNull(i)) continue;
                out.put(t.getString(i), new Day(t.getString(i), (int) Math.round(hi.getDouble(i)),
                        (int) Math.round(lo.getDouble(i)), code.isNull(i) ? -1 : code.getInt(i)));
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** City search JSON -> places (at most 6). */
    public static List<Place> parsePlaces(String json) {
        List<Place> out = new ArrayList<>();
        try {
            JSONArray r = new JSONObject(json).optJSONArray("results");
            if (r == null) return out;
            for (int i = 0; i < r.length() && out.size() < 6; i++) {
                JSONObject o = r.getJSONObject(i);
                if (!o.has("latitude") || !o.has("longitude")) continue;
                String admin = o.optString("admin1", ""), country = o.optString("country", "");
                String detail = admin.isEmpty() ? country : (country.isEmpty() ? admin : admin + ", " + country);
                out.add(new Place(o.optString("name", ""), detail, o.getDouble("latitude"), o.getDouble("longitude")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Rounds to one decimal (about 11 km), so the weather service never learns an exact spot. */
    public static String coarse(double v) { return String.format(Locale.US, "%.1f", Math.round(v * 10.0) / 10.0); }

    public static String forecastUrl(double lat, double lon, boolean fahrenheit) {
        return "https://api.open-meteo.com/v1/forecast?latitude=" + coarse(lat) + "&longitude=" + coarse(lon)
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=16&temperature_unit="
                + (fahrenheit ? "fahrenheit" : "celsius");
    }

    public static String placesUrl(String query) {
        String q;
        try { q = java.net.URLEncoder.encode(query.trim(), "UTF-8"); } catch (Exception e) { q = ""; }
        return "https://geocoding-api.open-meteo.com/v1/search?name=" + q + "&count=6&language=en&format=json";
    }

    /** Words for a WMO weather code. */
    public static String words(int code) {
        if (code == 0) return "Clear";
        if (code == 1) return "Mostly clear";
        if (code == 2) return "Partly cloudy";
        if (code == 3) return "Cloudy";
        if (code == 45 || code == 48) return "Fog";
        if (code >= 51 && code <= 57) return "Drizzle";
        if (code >= 61 && code <= 67) return "Rain";
        if (code >= 71 && code <= 77) return "Snow";
        if (code >= 80 && code <= 82) return "Showers";
        if (code == 85 || code == 86) return "Snow showers";
        if (code >= 95 && code <= 99) return "Thunderstorms";
        return "";
    }

    /** One small symbol for a weather code. */
    public static String symbol(int code) {
        if (code == 0 || code == 1) return "☀️";            // sun
        if (code == 2) return "⛅";                               // sun behind cloud
        if (code == 3) return "☁️";                         // cloud
        if (code == 45 || code == 48) return "🌫️";    // fog
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "🌧️"; // rain
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return "❄️";         // snow
        if (code >= 95 && code <= 99) return "⛈️";          // thunder
        return "";
    }

    /** Short line for a day card, e.g. "⛅ 61°/49°". */
    public static String shortLine(Day d) {
        String s = symbol(d.code);
        return (s.isEmpty() ? "" : s + " ") + d.hi + "°/" + d.lo + "°";
    }

    /** Words for a printed menu, e.g. "Rain, high 61°, low 49°". */
    public static String printLine(Day d) {
        String w = words(d.code);
        return (w.isEmpty() ? "" : w + ", ") + "high " + d.hi + "°, low " + d.lo + "°";
    }
}
