package com.quickdinner.planner.print;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class MenuData {
    public List<Day> days = new ArrayList();
    public List<GroceryGroup> groceries = new ArrayList();
    public boolean multiSlot;

    /* loaded from: classes.dex */
    public static final class Day {
        public LocalDate date;
        public String note;
        /** Weather for this day (printed with the notes), or null. */
        public String weather;
        public List<Slot> slots = new ArrayList();
    }

    /* loaded from: classes.dex */
    public static final class GroceryGroup {
        public String category = "";
        public List<String> lines = new ArrayList();
    }

    /* loaded from: classes.dex */
    public static final class Slot {
        public int adderColor;
        public boolean decided;
        public String imageUrl;
        public boolean undecided;
        public String label = "";
        public List<String> dishes = new ArrayList();
        public String adderName = "";
    }

    public boolean hasGroceries() {
        return !this.groceries.isEmpty();
    }
}
