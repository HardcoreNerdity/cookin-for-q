package com.quickdinner.planner.menu;

import android.app.Activity;
import android.graphics.Outline;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.quickdinner.planner.fx.Beverly;
import com.quickdinner.planner.logic.DayResolver;
import com.quickdinner.planner.model.Models;
import com.quickdinner.planner.recipes.RecipeImage;
import com.quickdinner.planner.ui.Icons;
import com.quickdinner.planner.ui.Ui;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class DayCard {
    private final MenuEnv env;

    /* JADX INFO: Access modifiers changed from: package-private */
    public DayCard(MenuEnv env) {
        this.env = env;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View build(LocalDate d) {
        final String localDate = d.toString();
        boolean equals = d.equals(this.env.today);
        Activity activity = this.env.act;
        LinearLayout card = equals ? Ui.card(activity, Ui.AMBER) : Ui.card(activity);
        LinearLayout hbox = Ui.hbox(this.env.act);
        Draw.add(hbox, Ui.text(this.env.act, Ui.dateLabel(localDate), 16.0f, Ui.TEXT, true), 0, -2, 1.0f, 0, 0, 0, 0);
        if (com.quickdinner.planner.weather.Weather.enabled()) {
            TextView weatherView = Ui.text(this.env.act, "", 13.0f, Ui.MUTED, false);
            weatherView.setSingleLine(true);
            hbox.addView(Ui.margins(weatherView, 0, 0, 8, 0));
            com.quickdinner.planner.weather.Weather.attach(weatherView, localDate);
        }
        if (equals) {
            hbox.addView(Ui.margins(Ui.chip(this.env.act, "Today", Ui.AMBER, true), 0, 0, 6, 0));
        }
        hbox.addView(Ui.iconButton(this.env.act, Icons.Type.PLUS, Ui.MUTED, "Add meal on " + Ui.dateLabel(localDate), new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                AddEntry.show(DayCard.this.env, localDate, null);
            }
        }));
        Draw.full(card, hbox, 0, 0);
        Draw.full(card, noteRow(localDate), 0, 0);
        Iterator<Models.Slot> it = this.env.slots.iterator();
        while (it.hasNext()) {
            Draw.full(card, slotSection(d, it.next()), 0, 0);
        }
        return card;
    }

    private View slotSection(LocalDate d, final Models.Slot slot) {
        final String localDate = d.toString();
        LinearLayout vbox = Ui.vbox(this.env.act);
        if (this.env.multiSlot()) {
            vbox.addView(Ui.margins(Ui.text(this.env.act, MenuLogic.slotLabel(slot).toUpperCase(), 12.0f, Ui.MUTED, true), 0, 8, 0, 4));
        }
        DayResolver.DayState resolve = this.env.resolve(localDate, slot);
        boolean isBefore = d.isBefore(this.env.today);
        int i = AnonymousClass13.$SwitchMap$com$quickdinner$planner$logic$DayResolver$Status[resolve.status.ordinal()];
        if (i == 1) {
            Draw.full(vbox, Ui.button(this.env.act, this.env.addLabel(slot), 3, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.2
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    AddEntry.show(DayCard.this.env, localDate, slot);
                }
            }), 6, 0);
            return vbox;
        }
        if (i == 2) {
            Draw.full(vbox, singleBlock(resolve.entries.get(0)), 0, 0);
        } else if (i == 3 || i == 4) {
            Draw.full(vbox, votingBlock(resolve), 0, 0);
        } else {
            Draw.full(vbox, decidedBlock(resolve), 0, 0);
        }
        if (!isBefore && resolve.status != DayResolver.Status.DECIDED) {
            vbox.addView(Ui.button(this.env.act, "Add another", 2, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.3
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    AddEntry.show(DayCard.this.env, localDate, slot);
                }
            }));
        }
        Models.MealLog log = this.env.log(localDate, slot);
        if (log != null) {
            Draw.full(vbox, confirmedRow(d, slot, resolve, log), 6, 0);
        } else if (MenuLogic.needsConfirm(d, this.env.today, resolve, null)) {
            Draw.full(vbox, banner(localDate, slot, resolve), 8, 0);
        }
        return vbox;
    }

    private View stripe(Models.MenuEntry e) {
        if (Beverly.on()) {
            return Beverly.badge(this.env.act, 28, Ui.memberColor(this.env.byId.get(e.addedBy)));
        }
        View view = new View(this.env.act);
        view.setBackground(Draw.rect(this.env.act, Ui.memberColor(this.env.byId.get(e.addedBy)), 3.0f, 0, 0.0f));
        return view;
    }

    private LinearLayout.LayoutParams stripeLp() {
        LinearLayout.LayoutParams layoutParams = Beverly.on() ? new LinearLayout.LayoutParams(Ui.dp(this.env.act, 28.0f), Ui.dp(this.env.act, 28.0f)) : new LinearLayout.LayoutParams(Ui.dp(this.env.act, 4.0f), Ui.dp(this.env.act, 40.0f));
        layoutParams.rightMargin = Ui.dp(this.env.act, 10.0f);
        return layoutParams;
    }

    private View noteRow(final String iso) {
        String str = this.env.notes.get(iso);
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.4
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DayCard.this.editNote(iso);
            }
        };
        if (str == null) {
            return Ui.button(this.env.act, "+ Add note", 2, onClickListener);
        }
        LinearLayout hbox = Ui.hbox(this.env.act);
        hbox.setBackground(Draw.rect(this.env.act, Ui.SURFACE_HIGH, 10.0f, 0, 0.0f));
        Ui.pad(hbox, 10, 6, 10, 6);
        hbox.addView(Ui.text(this.env.act, "Note: " + str, 14.0f, Ui.TEXT, false), Ui.lpw(0, -2, 1.0f));
        hbox.setOnClickListener(onClickListener);
        LinearLayout vbox = Ui.vbox(this.env.act);
        Draw.full(vbox, hbox, 2, 4);
        return vbox;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void editNote(final String iso) {
        LinearLayout vbox = Ui.vbox(this.env.act);
        String str = this.env.notes.get(iso);
        final EditText field = Ui.field(this.env.act, "Note for this day", str == null ? "" : str, 147457);
        field.setMinLines(2);
        Draw.full(vbox, field, 4, 8);
        final Ui.Sheet[] sheetArr = new Ui.Sheet[1];
        Draw.full(vbox, Ui.button(this.env.act, "Save note", 0, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.5
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DayCard.this.saveNote(iso, field.getText().toString().trim());
                sheetArr[0].dismiss();
            }
        }), 0, 6);
        if (str != null) {
            Draw.full(vbox, Ui.button(this.env.act, "Remove note", 1, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.6
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    DayCard.this.saveNote(iso, "");
                    sheetArr[0].dismiss();
                }
            }), 0, 0);
        }
        sheetArr[0] = Ui.sheet(this.env.act, "Note · " + Ui.dateLabel(iso), vbox);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveNote(String iso, String text) {
        Models.DayNote dayNote = new Models.DayNote();
        dayNote.id = iso;
        dayNote.text = text;
        dayNote.updatedBy = this.env.meId;
        dayNote.updatedAt = System.currentTimeMillis();
        this.env.store.dayNotes.put(dayNote);
    }

    private View thumb(Models.MenuEntry e) {
        String imageOf = imageOf(e.recipeId);
        if (imageOf == null) {
            Iterator<Models.Part> it = e.parts.iterator();
            while (it.hasNext() && (imageOf = imageOf(it.next().recipeId)) == null) {
            }
        }
        if (imageOf == null && Beverly.on()) {
            ImageView imageView = new ImageView(this.env.act);
            imageView.setImageBitmap(Beverly.face(this.env.act, Ui.dp(this.env.act, 52.0f) * 2));
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setPadding(Ui.dp(this.env.act, 3.0f), Ui.dp(this.env.act, 3.0f), Ui.dp(this.env.act, 3.0f), Ui.dp(this.env.act, 3.0f));
            imageView.setBackground(Draw.rect(this.env.act, Ui.SURFACE_HIGH, 10.0f, 0, 0.0f));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(Ui.dp(this.env.act, 52.0f), Ui.dp(this.env.act, 52.0f));
            layoutParams.setMargins(0, 0, Ui.dp(this.env.act, 10.0f), 0);
            imageView.setLayoutParams(layoutParams);
            return imageView;
        }
        if (imageOf == null) {
            return null;
        }
        ImageView imageView2 = new ImageView(this.env.act);
        imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView2.setBackground(Draw.rect(this.env.act, Ui.SURFACE_HIGH, 10.0f, 0, 0.0f));
        final float dp = Ui.dp(this.env.act, 10.0f);
        imageView2.setClipToOutline(true);
        imageView2.setOutlineProvider(new ViewOutlineProvider() { // from class: com.quickdinner.planner.menu.DayCard.7
            @Override // android.view.ViewOutlineProvider
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp);
            }
        });
        RecipeImage.load(imageView2, imageOf, Ui.dp(this.env.act, 120.0f));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(Ui.dp(this.env.act, 52.0f), Ui.dp(this.env.act, 52.0f));
        layoutParams2.setMargins(0, 0, Ui.dp(this.env.act, 10.0f), 0);
        imageView2.setLayoutParams(layoutParams2);
        return imageView2;
    }

    private String imageOf(String recipeId) {
        Models.Recipe recipe;
        if (recipeId == null || (recipe = this.env.store.recipes.get(recipeId)) == null || recipe.imageUrl == null || recipe.imageUrl.trim().isEmpty()) {
            return null;
        }
        return recipe.imageUrl;
    }

    private View singleBlock(Models.MenuEntry e) {
        LinearLayout hbox = Ui.hbox(this.env.act);
        hbox.setMinimumHeight(Ui.dp(this.env.act, 52.0f));
        hbox.setGravity(16);
        hbox.addView(stripe(e), stripeLp());
        View thumb = thumb(e);
        if (thumb != null) {
            hbox.addView(thumb);
        }
        LinearLayout vbox = Ui.vbox(this.env.act);
        vbox.addView(Ui.body(this.env.act, e.title));
        StringBuilder sb = e.leftoverOfEntryId != null ? new StringBuilder("Leftovers · added by ") : new StringBuilder("Added by ");
        sb.append(this.env.nameOf(e.addedBy));
        String sb2 = sb.toString();
        if (e.note != null && !e.note.trim().isEmpty()) {
            sb2 = sb2 + " · " + e.note.trim();
        }
        vbox.addView(Ui.muted(this.env.act, sb2));
        hbox.addView(vbox, Ui.lpw(0, -2, 1.0f));
        addDelete(hbox, e);
        EntryActions.attach(this.env, hbox, e);
        EntryActions.tapOpen(this.env, hbox, e);
        return hbox;
    }

    private void addDelete(LinearLayout row, final Models.MenuEntry e) {
        if (this.env.canDelete(e)) {
            row.addView(Ui.iconButton(this.env.act, Icons.Type.TRASH, Ui.MUTED, "Remove " + e.title, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.8
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    Ui.confirm(DayCard.this.env.act, "Remove entry", "Remove \"" + e.title + "\" from " + Ui.dateLabel(e.date) + "?", "Remove", new Runnable() { // from class: com.quickdinner.planner.menu.DayCard.8.1
                        @Override // java.lang.Runnable
                        public void run() {
                            DayCard.this.removeEntry(e);
                        }
                    });
                }
            }));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeEntry(Models.MenuEntry e) {
        for (Models.Vote vote : this.env.votes) {
            if (e.id.equals(vote.choice)) {
                this.env.store.votes.remove(vote.id);
            }
        }
        this.env.store.menu.remove(e.id);
    }

    private View votingBlock(final DayResolver.DayState st) {
        int i;
        LinearLayout vbox = Ui.vbox(this.env.act);
        boolean z = st.status == DayResolver.Status.TIED;
        LinearLayout hbox = Ui.hbox(this.env.act);
        hbox.addView(Ui.chip(this.env.act, z ? "Tied" : "Contested", z ? -34197 : Ui.AMBER, true));
        if (z) {
            StringBuilder sb = new StringBuilder();
            for (Models.MenuEntry menuEntry : st.entries) {
                Integer num = st.tally.get(menuEntry.id);
                if (sb.length() > 0) {
                    sb.append("  ·  ");
                }
                sb.append(menuEntry.title);
                sb.append(' ');
                sb.append(num == null ? 0 : num.intValue());
            }
            i = -34197;
            Draw.add(hbox, Ui.muted(this.env.act, sb.toString()), 0, -2, 1.0f, 8, 0, 0, 0);
        } else {
            hbox.addView(Ui.margins(Ui.muted(this.env.act, st.votedMemberIds.size() + " of " + this.env.members.size() + " voted"), 8, 0, 0, 0));
            i = -34197;
        }
        Draw.full(vbox, hbox, 6, 6);
        if (z) {
            vbox.addView(Ui.margins(Ui.text(this.env.act, "Everyone voted. Sort it out!", 14.0f, i, true), 0, 0, 0, 6));
        }
        Map<String, Models.Vote> countedVotes = MenuLogic.countedVotes(st, this.env.votes, this.env.members, this.env.allowOwn);
        Models.Vote vote = countedVotes.get(this.env.meId);
        String str = vote == null ? null : vote.choice;
        Iterator<Models.MenuEntry> it = st.entries.iterator();
        while (it.hasNext()) {
            Draw.full(vbox, voteRow(st, it.next(), countedVotes, str), 0, 6);
        }
        Draw.full(vbox, Ui.button(this.env.act, Models.Vote.SKIP.equals(str) ? "I don't care ✓" : "I don't care", 3, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.9
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                DayCard.this.castVote(st, Models.Vote.SKIP);
                Beverly.burst(DayCard.this.env.act, v, 16, Ui.memberColor(DayCard.this.env.me));
            }
        }), 0, 0);
        if (!z && !st.missingMemberIds.isEmpty()) {
            ArrayList arrayList = new ArrayList();
            for (Models.Member member : this.env.members) {
                if (st.missingMemberIds.contains(member.id)) {
                    arrayList.add(member.id.equals(this.env.meId) ? "you" : member.name);
                }
            }
            vbox.addView(Ui.margins(Ui.muted(this.env.act, "Waiting on " + join(arrayList)), 0, 6, 0, 0));
        }
        return vbox;
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(l.get(i));
        }
        return sb.toString();
    }

    private View voteRow(final DayResolver.DayState st, final Models.MenuEntry e, Map<String, Models.Vote> counted, String myChoice) {
        String str;
        final boolean z = this.env.meId.equals(e.addedBy) && !this.env.allowOwn;
        boolean equals = e.id.equals(myChoice);
        LinearLayout hbox = Ui.hbox(this.env.act);
        hbox.setMinimumHeight(Ui.dp(this.env.act, 52.0f));
        int memberColor = Ui.memberColor(this.env.byId.get(e.addedBy));
        hbox.setBackground(Draw.rect(this.env.act, equals ? Ui.SURFACE_HIGH : Ui.SURFACE, 12.0f, memberColor, 2.5f));
        Ui.pad(hbox, 12, 6, 4, 6);
        hbox.setGravity(16);
        if (Beverly.on()) {
            hbox.addView(Ui.margins(Beverly.badge(this.env.act, 30, memberColor), 0, 0, 8, 0));
        }
        View thumb = thumb(e);
        if (thumb != null) {
            EntryActions.tapOpen(this.env, thumb, e);
            hbox.addView(thumb);
        }
        LinearLayout vbox = Ui.vbox(this.env.act);
        vbox.addView(Ui.body(this.env.act, e.title));
        Activity activity = this.env.act;
        if (z) {
            str = "Your entry – you can't vote for it";
        } else {
            str = "Added by " + this.env.nameOf(e.addedBy);
        }
        vbox.addView(Ui.muted(activity, str));
        if (equals) {
            vbox.addView(Ui.margins(Ui.text(this.env.act, "✓ Your vote", 12.0f, Ui.TEAL, true), 0, 2, 0, 0));
        }
        hbox.addView(vbox, Ui.lpw(0, -2, 1.0f));
        List<String> votersOf = MenuLogic.votersOf(e.id, counted);
        LinearLayout hbox2 = Ui.hbox(this.env.act);
        int i = 0;
        while (i < votersOf.size() && i < 4) {
            hbox2.addView(Ui.margins(Ui.avatar(this.env.act, this.env.byId.get(votersOf.get(i)), 22), i == 0 ? 0 : -6, 0, 0, 0));
            i++;
        }
        hbox.addView(hbox2);
        if (!votersOf.isEmpty()) {
            hbox.addView(Ui.margins(Ui.text(this.env.act, String.valueOf(votersOf.size()), 14.0f, Ui.TEXT, true), 6, 0, 4, 0));
        }
        addDelete(hbox, e);
        EntryActions.attach(this.env, hbox, e);
        if (z) {
            hbox.setAlpha(0.6f);
        }
        hbox.setOnClickListener(new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.10
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (z) {
                    Ui.toast(DayCard.this.env.act, "You can't vote for your own entry.");
                    return;
                }
                DayCard.this.castVote(st, e.id);
                Beverly.burst(DayCard.this.env.act, v, 24, Ui.memberColor(DayCard.this.env.me));
                Beverly.rain(DayCard.this.env.act, 14);
            }
        });
        return hbox;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void castVote(DayResolver.DayState st, String choice) {
        if (this.env.meId.isEmpty()) {
            return;
        }
        Models.Vote vote = new Models.Vote();
        vote.id = Models.Vote.idOf(st.date, st.slot, this.env.meId);
        vote.date = st.date;
        vote.slot = st.slot;
        vote.memberId = this.env.meId;
        vote.choice = choice;
        vote.votedAt = System.currentTimeMillis();
        this.env.store.votes.put(vote);
    }

    private View decidedBlock(DayResolver.DayState st) {
        LinearLayout vbox = Ui.vbox(this.env.act);
        Models.MenuEntry menuEntry = null;
        for (Models.MenuEntry menuEntry2 : st.entries) {
            if (menuEntry2.id.equals(st.winnerId)) {
                menuEntry = menuEntry2;
            }
        }
        if (menuEntry != null) {
            LinearLayout hbox = Ui.hbox(this.env.act);
            hbox.setGravity(16);
            if (Beverly.on()) {
                hbox.addView(Ui.margins(Beverly.badge(this.env.act, 30, Ui.memberColor(this.env.byId.get(menuEntry.addedBy))), 0, 0, 8, 0));
            }
            View thumb = thumb(menuEntry);
            if (thumb != null) {
                hbox.addView(thumb);
            }
            hbox.addView(Ui.chip(this.env.act, "Winner", Ui.TEAL, true));
            Draw.add(hbox, Ui.text(this.env.act, menuEntry.title, 17.0f, Ui.TEXT, true), 0, -2, 1.0f, 8, 0, 0, 0);
            addDelete(hbox, menuEntry);
            EntryActions.attach(this.env, hbox, menuEntry);
            EntryActions.tapOpen(this.env, hbox, menuEntry);
            Draw.full(vbox, hbox, 6, 4);
            LinearLayout hbox2 = Ui.hbox(this.env.act);
            hbox2.addView(Ui.muted(this.env.act, "Loved by "));
            Iterator<String> it = st.loverIds.iterator();
            while (it.hasNext()) {
                hbox2.addView(Ui.margins(Ui.avatar(this.env.act, this.env.byId.get(it.next()), 24), 4, 0, 0, 0));
            }
            if (st.loverIds.isEmpty()) {
                hbox2.addView(Ui.muted(this.env.act, "no one yet"));
            }
            Draw.full(vbox, hbox2, 0, 8);
        }
        for (String str : st.loserIds) {
            Models.MenuEntry menuEntry3 = null;
            for (Models.MenuEntry menuEntry4 : st.entries) {
                if (menuEntry4.id.equals(str)) {
                    menuEntry3 = menuEntry4;
                }
            }
            if (menuEntry3 != null) {
                LinearLayout hbox3 = Ui.hbox(this.env.act);
                hbox3.setMinimumHeight(Ui.dp(this.env.act, 48.0f));
                LinearLayout vbox2 = Ui.vbox(this.env.act);
                TextView body = Ui.body(this.env.act, menuEntry3.title);
                body.setPaintFlags(body.getPaintFlags() | 16);
                vbox2.addView(body);
                Models.Passed passed = this.env.passed.get(MenuLogic.passedId(menuEntry3));
                if (passed != null && passed.lastPassedDate != null) {
                    vbox2.addView(Ui.muted(this.env.act, "last passed " + Ui.dateLabel(passed.lastPassedDate)));
                }
                vbox2.setAlpha(0.5f);
                hbox3.addView(vbox2, Ui.lpw(0, -2, 1.0f));
                View chip = Ui.chip(this.env.act, "Loser", Ui.MUTED, false);
                chip.setAlpha(0.7f);
                hbox3.addView(chip);
                addDelete(hbox3, menuEntry3);
                EntryActions.attach(this.env, hbox3, menuEntry3);
                EntryActions.tapOpen(this.env, hbox3, menuEntry3);
                Draw.full(vbox, hbox3, 0, 0);
            }
        }
        return vbox;
    }

    private View banner(final String iso, final Models.Slot slot, final DayResolver.DayState st) {
        String str;
        LinearLayout vbox = Ui.vbox(this.env.act);
        vbox.setBackground(Draw.rect(this.env.act, Ui.AMBER_DIM, 12.0f, Ui.AMBER, 1.0f));
        Ui.pad(vbox, 12, 10, 12, 10);
        String confirmTitle = MenuLogic.confirmTitle(st);
        if (confirmTitle != null) {
            str = "Did you eat " + confirmTitle + "?";
        } else {
            str = "Did you eat " + MenuLogic.slotLabel(slot).toLowerCase() + "?";
        }
        vbox.addView(Ui.text(this.env.act, str, 15.0f, Ui.AMBER, true));
        LinearLayout hbox = Ui.hbox(this.env.act);
        hbox.addView(confirmBtn("Yes", 0, 0, iso, slot, st), Ui.lpw(0, -2, 1.0f));
        Draw.add(hbox, confirmBtn("Ate something else", 1, 1, iso, slot, st), 0, -2, 2.0f, 6, 0, 6, 0);
        hbox.addView(confirmBtn("No", 1, 2, iso, slot, st), Ui.lpw(0, -2, 1.0f));
        Draw.full(vbox, hbox, 8, 0);
        return vbox;
    }

    private View confirmBtn(String label, int style, final int kind, final String iso, final Models.Slot slot, final DayResolver.DayState st) {
        return Ui.button(this.env.act, label, style, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.11
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ConfirmFlow.start(DayCard.this.env, iso, slot, st, kind);
            }
        });
    }

    private View confirmedRow(LocalDate d, final Models.Slot slot, final DayResolver.DayState st, Models.MealLog log) {
        String str;
        final String localDate = d.toString();
        int i = AnonymousClass13.$SwitchMap$com$quickdinner$planner$model$Models$MealStatus[log.status.ordinal()];
        if (i == 1) {
            String str2 = null;
            for (Models.MenuEntry menuEntry : st.entries) {
                if (menuEntry.id.equals(log.eatenEntryId)) {
                    str2 = menuEntry.title;
                }
            }
            if (str2 == null) {
                str2 = this.env.entries.isEmpty() ? null : titleById(log.eatenEntryId);
            }
            str = str2 == null ? "Eaten" : "Ate " + str2;
        } else if (i != 2) {
            str = "Not eaten";
        } else {
            StringBuilder sb = new StringBuilder("Ate ");
            sb.append(log.replacementTitle == null ? "something else" : log.replacementTitle);
            sb.append(" instead");
            str = sb.toString();
        }
        if (log.hasLeftovers) {
            str = str + " · leftovers";
        }
        LinearLayout hbox = Ui.hbox(this.env.act);
        hbox.addView(Ui.iconView(this.env.act, Icons.Type.CHECK, Ui.TEAL, 20));
        Draw.add(hbox, Ui.text(this.env.act, str, 14.0f, Ui.TEAL, false), 0, -2, 1.0f, 8, 0, 0, 0);
        hbox.addView(Ui.button(this.env.act, "Change", 2, new View.OnClickListener() { // from class: com.quickdinner.planner.menu.DayCard.12
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ConfirmFlow.start(DayCard.this.env, localDate, slot, st, 3);
            }
        }));
        hbox.setGravity(16);
        return hbox;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.quickdinner.planner.menu.DayCard$13, reason: invalid class name */
    /* loaded from: classes.dex */
    public static /* synthetic */ class AnonymousClass13 {
        static final /* synthetic */ int[] $SwitchMap$com$quickdinner$planner$logic$DayResolver$Status;
        static final /* synthetic */ int[] $SwitchMap$com$quickdinner$planner$model$Models$MealStatus;

        static {
            int[] iArr = new int[Models.MealStatus.values().length];
            $SwitchMap$com$quickdinner$planner$model$Models$MealStatus = iArr;
            try {
                iArr[Models.MealStatus.EATEN.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$quickdinner$planner$model$Models$MealStatus[Models.MealStatus.SOMETHING_ELSE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            int[] iArr2 = new int[DayResolver.Status.values().length];
            $SwitchMap$com$quickdinner$planner$logic$DayResolver$Status = iArr2;
            try {
                iArr2[DayResolver.Status.EMPTY.ordinal()] = 1;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$quickdinner$planner$logic$DayResolver$Status[DayResolver.Status.SINGLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$quickdinner$planner$logic$DayResolver$Status[DayResolver.Status.CONTESTED.ordinal()] = 3;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$com$quickdinner$planner$logic$DayResolver$Status[DayResolver.Status.TIED.ordinal()] = 4;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }

    private String titleById(String id) {
        if (id == null) {
            return null;
        }
        for (Models.MenuEntry menuEntry : this.env.entries) {
            if (id.equals(menuEntry.id)) {
                return menuEntry.title;
            }
        }
        return null;
    }
}
