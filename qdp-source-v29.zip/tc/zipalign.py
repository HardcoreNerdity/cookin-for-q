import sys, zipfile, struct
# Minimal zipalign: stored entries aligned to 4 bytes (resources.arsc / .so to 4096 for .so), others copied as-is.
src, dst = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(src)
out = open(dst, 'wb')
cd = []
for zi in zin.infolist():
    data = zin.read(zi.filename)
    name = zi.filename.encode()
    method = zi.compress_type
    if method == zipfile.ZIP_DEFLATED:
        import zlib
        c = zlib.compressobj(9, zlib.DEFLATED, -15); comp = c.compress(data) + c.flush()
    else:
        comp = data
    off = out.tell()
    extra = b''
    hdr_len = 30 + len(name)
    if method == zipfile.ZIP_STORED:
        al = 4096 if zi.filename.endswith('.so') else 4
        pad = (-(off + hdr_len)) % al
        extra = b'\0' * pad
    crc = zi.CRC
    out.write(struct.pack('<IHHHHHIIIHH', 0x04034b50, 20, 0x0800, method, zi.date_time[3] << 11 | zi.date_time[4] << 5 | zi.date_time[5] // 2,
        (zi.date_time[0] - 1980) << 9 | zi.date_time[1] << 5 | zi.date_time[2], crc, len(comp), len(data), len(name), len(extra)))
    out.write(name); out.write(extra); out.write(comp)
    cd.append((zi, name, method, crc, len(comp), len(data), off))
cds = out.tell()
for zi, name, method, crc, cs, us, off in cd:
    out.write(struct.pack('<IHHHHHHIIIHHHHHII', 0x02014b50, 20, 20, 0x0800, method,
        zi.date_time[3] << 11 | zi.date_time[4] << 5 | zi.date_time[5] // 2,
        (zi.date_time[0] - 1980) << 9 | zi.date_time[1] << 5 | zi.date_time[2], crc, cs, us, len(name), 0, 0, 0, 0, zi.external_attr, off))
    out.write(name)
cde = out.tell() - cds
out.write(struct.pack('<IHHHHIIH', 0x06054b50, 0, 0, len(cd), len(cd), cde, cds, 0))
out.close()
