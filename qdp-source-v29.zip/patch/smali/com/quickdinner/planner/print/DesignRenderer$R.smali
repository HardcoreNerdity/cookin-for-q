.class final Lcom/quickdinner/planner/print/DesignRenderer$R;
.super Ljava/lang/Object;
.source "DesignRenderer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/quickdinner/planner/print/DesignRenderer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "R"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;
    }
.end annotation


# static fields
.field static final K_GRID:I = 0x0

.field static final K_LIST:I = 0x1

.field static final K_POSTER:I = 0x2


# instance fields
.field final accent:I

.field final accentInk:I

.field final autoSub:Ljava/lang/String;

.field final b:F

.field bottom:F

.field final contentW:F

.field cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

.field final d:Lcom/quickdinner/planner/print/PrintDesign;

.field final faint:I

.field final faintHi:I

.field final footerH:F

.field gridPhotos:Z

.field final groc:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field grocNext:I

.field groceryStarted:Z

.field final imgs:Lcom/quickdinner/planner/print/DesignRenderer$Images;

.field final ink:Z

.field final line:I

.field final m:Lcom/quickdinner/planner/print/MenuData;

.field final margin:F

.field final muted:I

.field final page:I

.field final pages:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/quickdinner/planner/print/DesignRenderer$Page;",
            ">;"
        }
    .end annotation
.end field

.field final ph:F

.field final photo:Landroid/graphics/Bitmap;

.field final pw:F

.field side:Z

.field sideW:F

.field final text:I

.field y:F


# direct methods
.method constructor <init>(Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData;Ljava/lang/String;Landroid/graphics/Bitmap;Lcom/quickdinner/planner/print/DesignRenderer$Images;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "d",
            "m",
            "autoSub",
            "photo",
            "imgs"
        }
    .end annotation

    .line 95
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x41b00000    # 22.0f

    .line 83
    iput v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->footerH:F

    .line 86
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pages:Ljava/util/List;

    .line 91
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    .line 96
    iput-object p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iput-object p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iput-object p3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->autoSub:Ljava/lang/String;

    iput-object p4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    iput-object p5, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->imgs:Lcom/quickdinner/planner/print/DesignRenderer$Images;

    .line 97
    invoke-virtual {p1}, Lcom/quickdinner/planner/print/PrintDesign;->pageW()F

    move-result p2

    iput p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pw:F

    invoke-virtual {p1}, Lcom/quickdinner/planner/print/PrintDesign;->pageH()F

    move-result p3

    iput p3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ph:F

    invoke-virtual {p1}, Lcom/quickdinner/planner/print/PrintDesign;->scale()F

    move-result p4

    iput p4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    sget-object p4, Lcom/quickdinner/planner/print/PrintDesign;->MARGINS:[F

    iget p5, p1, Lcom/quickdinner/planner/print/PrintDesign;->margin:I

    aget p4, p4, p5

    iput p4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    const/high16 p5, 0x40000000    # 2.0f

    mul-float/2addr p5, p4

    sub-float/2addr p2, p5

    .line 98
    iput p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    .line 99
    iget-boolean p2, p1, Lcom/quickdinner/planner/print/PrintDesign;->inkSaver:Z

    iput-boolean p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ink:Z

    const/high16 p5, -0x1000000

    if-eqz p2, :cond_0

    const/4 v1, -0x1

    goto :goto_0

    .line 100
    :cond_0
    iget v1, p1, Lcom/quickdinner/planner/print/PrintDesign;->page:I

    or-int/2addr v1, p5

    :goto_0
    iput v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->page:I

    const v2, -0xeeeeef

    if-eqz p2, :cond_1

    move v3, v2

    goto :goto_1

    .line 101
    :cond_1
    iget v3, p1, Lcom/quickdinner/planner/print/PrintDesign;->text:I

    or-int/2addr v3, p5

    :goto_1
    iput v3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    if-eqz p2, :cond_2

    goto :goto_2

    .line 102
    :cond_2
    iget p1, p1, Lcom/quickdinner/planner/print/PrintDesign;->accent:I

    or-int v2, p1, p5

    :goto_2
    iput v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->accent:I

    if-eqz p2, :cond_3

    move p1, v3

    goto :goto_3

    .line 103
    :cond_3
    invoke-static {v2}, Lcom/quickdinner/planner/print/DesignRenderer$R;->contrast(I)I

    move-result p1

    :goto_3
    iput p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->accentInk:I

    const p1, 0x3ed70a3d    # 0.42f

    .line 104
    invoke-static {v3, v1, p1}, Lcom/quickdinner/planner/print/DesignRenderer$R;->mix(IIF)I

    move-result p1

    iput p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    if-eqz p2, :cond_4

    const p1, 0x3ee66666    # 0.45f

    goto :goto_4

    :cond_4
    const p1, 0x3f47ae14    # 0.78f

    .line 105
    :goto_4
    invoke-static {v3, v1, p1}, Lcom/quickdinner/planner/print/DesignRenderer$R;->mix(IIF)I

    move-result p1

    iput p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    const/4 p1, 0x0

    const p5, 0xffffff

    if-eqz p2, :cond_5

    move v1, p1

    goto :goto_5

    :cond_5
    and-int v1, v3, p5

    const/high16 v2, 0xe000000

    or-int/2addr v1, v2

    .line 106
    :goto_5
    iput v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faint:I

    if-eqz p2, :cond_6

    goto :goto_6

    :cond_6
    and-int p1, v3, p5

    const/high16 p2, 0x1a000000

    or-int/2addr p1, p2

    .line 107
    :goto_6
    iput p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faintHi:I

    sub-float/2addr p3, p4

    sub-float/2addr p3, v0

    .line 108
    iput p3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->bottom:F

    return-void
.end method

.method static contrast(I)I
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    .line 112
    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    int-to-double v0, v0

    const-wide v2, 0x3fd322d0e5604189L    # 0.299

    mul-double/2addr v0, v2

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-double v2, v2

    const-wide v4, 0x3fe2c8b439581062L    # 0.587

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result p0

    int-to-double v2, p0

    const-wide v4, 0x3fbd2f1a9fbe76c9L    # 0.114

    mul-double/2addr v2, v4

    add-double/2addr v0, v2

    const-wide v2, 0x406fe00000000000L    # 255.0

    div-double/2addr v0, v2

    const-wide v2, 0x3fe3333333333333L    # 0.6

    cmpl-double p0, v0, v2

    if-lez p0, :cond_0

    const p0, -0xe4e4e5

    goto :goto_0

    :cond_0
    const/4 p0, -0x1

    :goto_0
    return p0
.end method

.method static drawCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FI)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "c",
            "bmp",
            "dst",
            "radius",
            "alpha"
        }
    .end annotation

    if-eqz p1, :cond_2

    .line 260
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-lez v0, :cond_2

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v0

    cmpg-float v0, v0, v1

    if-gtz v0, :cond_0

    goto :goto_1

    .line 261
    :cond_0
    invoke-virtual {p0}, Landroid/graphics/Canvas;->save()I

    cmpl-float v0, p3, v1

    if-lez v0, :cond_1

    .line 262
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    sget-object v1, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v0, p2, p3, p3, v1}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual {p0, v0}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    goto :goto_0

    .line 263
    :cond_1
    invoke-virtual {p0, p2}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    .line 264
    :goto_0
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result p3

    int-to-float p3, p3

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v0

    int-to-float v0, v0

    .line 265
    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    div-float/2addr v1, p3

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    div-float/2addr v2, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    .line 266
    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v2

    div-float/2addr v2, v1

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v3

    div-float/2addr v3, v1

    .line 267
    new-instance v1, Landroid/graphics/Rect;

    sub-float v4, p3, v2

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    sub-float v6, v0, v3

    div-float/2addr v6, v5

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    add-float/2addr p3, v2

    div-float/2addr p3, v5

    .line 268
    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    add-float/2addr v0, v3

    div-float/2addr v0, v5

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-direct {v1, v4, v6, p3, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 269
    new-instance p3, Landroid/graphics/Paint;

    const/4 v0, 0x3

    invoke-direct {p3, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 270
    invoke-virtual {p3, p4}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 271
    invoke-virtual {p0, p1, v1, p2, p3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 272
    invoke-virtual {p0}, Landroid/graphics/Canvas;->restore()V

    :cond_2
    :goto_1
    return-void
.end method

.method static join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "l",
            "sep"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 416
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    .line 417
    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    if-lez v1, :cond_0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 418
    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$buildTile$10(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 352
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$buildTile$11(ZIFFFLandroid/text/StaticLayout;FFLandroid/graphics/Canvas;)V
    .locals 2

    if-eqz p0, :cond_0

    .line 367
    new-instance p0, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroid/graphics/Paint;-><init>(I)V

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColor(I)V

    add-float p1, p2, p3

    .line 368
    invoke-virtual {p5}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    const v1, 0x3f99999a    # 1.2f

    mul-float/2addr p6, v1

    invoke-static {v0, p6}, Ljava/lang/Math;->min(FF)F

    move-result p6

    const/high16 v0, 0x40000000    # 2.0f

    div-float/2addr p6, v0

    add-float/2addr p6, p4

    invoke-virtual {p8, p1, p6, p3, p0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 370
    :cond_0
    invoke-virtual {p8}, Landroid/graphics/Canvas;->save()I

    add-float/2addr p2, p7

    invoke-virtual {p8, p2, p4}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p5, p8}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p8}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$buildTile$12(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 377
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$buildTile$13(Landroid/graphics/Bitmap;FFFLandroid/graphics/Canvas;)V
    .locals 2

    .line 384
    new-instance v0, Landroid/graphics/RectF;

    add-float v1, p1, p3

    add-float/2addr p3, p2

    invoke-direct {v0, p1, p2, v1, p3}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 p1, 0x40c00000    # 6.0f

    const/16 p2, 0xff

    invoke-static {p4, p0, v0, p1, p2}, Lcom/quickdinner/planner/print/DesignRenderer$R;->drawCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FI)V

    return-void
.end method

.method static synthetic lambda$buildTile$14(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 392
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$buildTile$15(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 398
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$buildTile$8(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 330
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$buildTile$9(Landroid/graphics/Bitmap;FFFFLandroid/graphics/Canvas;)V
    .locals 1

    .line 342
    new-instance v0, Landroid/graphics/RectF;

    add-float/2addr p3, p1

    add-float/2addr p4, p2

    invoke-direct {v0, p1, p2, p3, p4}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 p1, 0x40c00000    # 6.0f

    const/16 p2, 0xff

    invoke-static {p5, p0, v0, p1, p2}, Lcom/quickdinner/planner/print/DesignRenderer$R;->drawCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FI)V

    return-void
.end method

.method static synthetic lambda$flowGrocery$20(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 567
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$groceryPage$24(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 0

    .line 603
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$sideBar$23(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 1

    .line 594
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    const/high16 v0, 0x41000000    # 8.0f

    add-float/2addr p0, v0

    add-float/2addr p1, v0

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static synthetic lambda$weekdayHeader$19(FFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 1

    .line 506
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    const/high16 v0, 0x40000000    # 2.0f

    add-float/2addr p1, v0

    invoke-virtual {p3, p0, p1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method static mix(IIF)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "a",
            "bb",
            "t"
        }
    .end annotation

    .line 118
    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    sub-float/2addr v1, p2

    mul-float/2addr v0, v1

    invoke-static {p1}, Landroid/graphics/Color;->red(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, p2

    add-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    .line 119
    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v1

    invoke-static {p1}, Landroid/graphics/Color;->green(I)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, p2

    add-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    .line 120
    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result p0

    int-to-float p0, p0

    mul-float/2addr p0, v1

    invoke-static {p1}, Landroid/graphics/Color;->blue(I)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, p2

    add-float/2addr p0, p1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/16 p1, 0xff

    .line 117
    invoke-static {p1, v0, v2, p0}, Landroid/graphics/Color;->argb(IIII)I

    move-result p0

    return p0
.end method


# virtual methods
.method availW()F
    .locals 3

    .line 163
    iget-boolean v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->side:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pages:Ljava/util/List;

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_0

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->sideW:F

    sub-float/2addr v0, v1

    const/high16 v1, 0x41400000    # 12.0f

    sub-float/2addr v0, v1

    goto :goto_0

    :cond_0
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    :goto_0
    return v0
.end method

.method buildGroceryList()V
    .locals 5

    .line 544
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->grocery:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$Grocery;->OFF:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    if-ne v0, v1, :cond_0

    return-void

    .line 545
    :cond_0
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData;->groceries:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;

    .line 546
    iget-object v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    const-string v3, "H"

    iget-object v4, v1, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;->category:Ljava/lang/String;

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 547
    iget-object v1, v1, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;->lines:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    const-string v4, "I"

    filled-new-array {v4, v2}, [Ljava/lang/String;

    move-result-object v2

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    return-void
.end method

.method buildTile(Lcom/quickdinner/planner/print/MenuData$Day;FIZ)Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;
    .locals 42
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x0
        }
        names = {
            "day",
            "w",
            "kind",
            "showMonth"
        }
    .end annotation

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    move/from16 v11, p3

    .line 291
    new-instance v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;

    invoke-direct {v12, v9}, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;)V

    const/high16 v0, 0x41300000    # 11.0f

    const/high16 v1, 0x41080000    # 8.5f

    const/4 v13, 0x1

    if-nez v11, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    if-ne v11, v13, :cond_1

    move v2, v0

    goto :goto_0

    :cond_1
    const/high16 v2, 0x41580000    # 13.5f

    .line 292
    :goto_0
    iget v3, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v23, v2, v3

    if-nez v11, :cond_2

    const v2, 0x40d9999a    # 6.8f

    goto :goto_1

    :cond_2
    if-ne v11, v13, :cond_3

    move v2, v1

    goto :goto_1

    :cond_3
    const/high16 v2, 0x41180000    # 9.5f

    :goto_1
    mul-float v24, v2, v3

    if-nez v11, :cond_4

    move v0, v1

    goto :goto_2

    :cond_4
    if-ne v11, v13, :cond_5

    goto :goto_2

    :cond_5
    const/high16 v0, 0x41600000    # 14.0f

    :goto_2
    mul-float v2, v0, v3

    const/high16 v25, 0x41000000    # 8.0f

    if-nez v11, :cond_6

    const/high16 v0, 0x40800000    # 4.0f

    move v15, v0

    goto :goto_3

    :cond_6
    move/from16 v15, v25

    :goto_3
    const/high16 v26, 0x40000000    # 2.0f

    mul-float v0, v15, v26

    sub-float v27, p2, v0

    const/16 v28, 0x3

    const/4 v14, 0x2

    if-nez v11, :cond_7

    move/from16 v29, v28

    goto :goto_4

    :cond_7
    move/from16 v29, v14

    .line 298
    :goto_4
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->photoSize:I

    const/high16 v30, 0x3f800000    # 1.0f

    if-nez v0, :cond_8

    const v0, 0x3f333333    # 0.7f

    :goto_5
    move/from16 v31, v0

    goto :goto_6

    :cond_8
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->photoSize:I

    if-ne v0, v14, :cond_9

    const v0, 0x3fa66666    # 1.3f

    goto :goto_5

    :cond_9
    move/from16 v31, v30

    :goto_6
    if-nez v11, :cond_a

    .line 302
    iget-object v0, v10, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    invoke-virtual {v0}, Ljava/time/LocalDate;->getDayOfMonth()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    if-eqz p4, :cond_b

    .line 303
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v10, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    invoke-virtual {v3}, Ljava/time/LocalDate;->getMonth()Ljava/time/Month;

    move-result-object v3

    sget-object v4, Ljava/time/format/TextStyle;->SHORT:Ljava/time/format/TextStyle;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Ljava/time/Month;->getDisplayName(Ljava/time/format/TextStyle;Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_7

    .line 305
    :cond_a
    iget-object v0, v10, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    const-string v1, "EEEE, MMM d"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-static {v1, v3}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    move-result-object v0

    :cond_b
    :goto_7
    move-object v1, v0

    .line 307
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->dayHeader:Lcom/quickdinner/planner/print/PrintDesign$DayHeader;

    sget-object v3, Lcom/quickdinner/planner/print/PrintDesign$DayHeader;->FILLED:Lcom/quickdinner/planner/print/PrintDesign$DayHeader;

    const/16 v32, 0x0

    if-ne v0, v3, :cond_c

    iget-boolean v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->ink:Z

    if-nez v0, :cond_c

    move/from16 v16, v13

    goto :goto_8

    :cond_c
    move/from16 v16, v32

    :goto_8
    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v16, :cond_d

    .line 308
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->accentInk:I

    goto :goto_9

    :cond_d
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    :goto_9
    move v5, v0

    const/4 v7, 0x1

    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move/from16 v6, v27

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v7

    .line 309
    invoke-virtual {v7}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    if-nez v11, :cond_e

    move/from16 v1, v28

    goto :goto_a

    :cond_e
    const/4 v1, 0x7

    :goto_a
    add-int/2addr v0, v1

    int-to-float v8, v0

    .line 311
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->dayHeader:Lcom/quickdinner/planner/print/PrintDesign$DayHeader;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$DayHeader;->PLAIN:Lcom/quickdinner/planner/print/PrintDesign$DayHeader;

    if-eq v0, v1, :cond_f

    move v5, v13

    goto :goto_b

    :cond_f
    move/from16 v5, v32

    .line 312
    :goto_b
    iget-object v6, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v4, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda15;

    move-object v0, v4

    move-object/from16 v1, p0

    move/from16 v2, v16

    move/from16 v3, p2

    move-object v14, v4

    move v4, v8

    move-object v13, v6

    move v6, v15

    invoke-direct/range {v0 .. v7}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda15;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;ZFFZFLandroid/text/StaticLayout;)V

    invoke-interface {v13, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    if-nez v11, :cond_10

    move/from16 v0, v28

    goto :goto_c

    :cond_10
    const/4 v0, 0x6

    :goto_c
    int-to-float v0, v0

    add-float/2addr v8, v0

    .line 325
    iget-object v0, v10, Lcom/quickdinner/planner/print/MenuData$Day;->slots:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    move v14, v8

    move/from16 v0, v32

    :goto_d
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/high16 v17, 0x41100000    # 9.0f

    const/16 v33, 0x4

    if-eqz v1, :cond_24

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lcom/quickdinner/planner/print/MenuData$Slot;

    .line 327
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/MenuData;->multiSlot:Z

    if-eqz v0, :cond_11

    .line 328
    iget-object v0, v8, Lcom/quickdinner/planner/print/MenuData$Slot;->label:Ljava/lang/String;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    const/4 v7, 0x1

    sget-object v18, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move/from16 v2, v24

    move/from16 v6, v27

    move-object/from16 p2, v13

    move-object v13, v8

    move-object/from16 v8, v18

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 330
    iget-object v1, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda16;

    invoke-direct {v2, v15, v14, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda16;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 331
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    const/4 v1, 0x1

    add-int/2addr v0, v1

    int-to-float v0, v0

    add-float/2addr v14, v0

    goto :goto_e

    :cond_11
    move-object/from16 p2, v13

    move-object v13, v8

    .line 333
    :goto_e
    invoke-virtual {v9, v13}, Lcom/quickdinner/planner/print/DesignRenderer$R;->mealPhoto(Lcom/quickdinner/planner/print/MenuData$Slot;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_12

    if-nez v11, :cond_12

    .line 334
    iget-boolean v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->gridPhotos:Z

    if-nez v1, :cond_12

    const/4 v0, 0x0

    :cond_12
    move-object v2, v0

    const/16 v34, 0x0

    if-eqz v2, :cond_15

    const/4 v0, 0x1

    if-ne v11, v0, :cond_13

    .line 337
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->photoSize:I

    mul-int/lit8 v0, v0, 0x16

    add-int/lit8 v0, v0, 0x28

    int-to-float v0, v0

    move v1, v0

    move/from16 v0, v34

    goto :goto_10

    :cond_13
    if-nez v11, :cond_14

    const v0, 0x3f1eb852    # 0.62f

    goto :goto_f

    :cond_14
    const v0, 0x3f0ccccd    # 0.55f

    :goto_f
    mul-float v0, v0, v27

    mul-float v0, v0, v31

    move/from16 v1, v34

    goto :goto_10

    :cond_15
    move/from16 v0, v34

    move v1, v0

    :goto_10
    if-eqz v2, :cond_16

    cmpl-float v3, v0, v34

    if-lez v3, :cond_16

    .line 342
    iget-object v8, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v7, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda17;

    move-object v3, v7

    move-object v4, v2

    move v5, v15

    move v6, v14

    move-object/from16 p4, v2

    move-object v2, v7

    move/from16 v7, v27

    move-object v10, v8

    move v8, v0

    invoke-direct/range {v3 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda17;-><init>(Landroid/graphics/Bitmap;FFFF)V

    invoke-interface {v10, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/high16 v2, 0x40400000    # 3.0f

    add-float/2addr v0, v2

    add-float/2addr v14, v0

    goto :goto_11

    :cond_16
    move-object/from16 p4, v2

    :goto_11
    move v10, v14

    .line 345
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->who:Lcom/quickdinner/planner/print/PrintDesign$Who;

    sget-object v2, Lcom/quickdinner/planner/print/PrintDesign$Who;->DOT:Lcom/quickdinner/planner/print/PrintDesign$Who;

    if-ne v0, v2, :cond_18

    iget v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderColor:I

    if-eqz v0, :cond_18

    if-nez v11, :cond_17

    const v0, 0x3f4ccccd    # 0.8f

    goto :goto_12

    :cond_17
    move/from16 v0, v30

    :goto_12
    mul-float v0, v0, v17

    move/from16 v35, v0

    goto :goto_13

    :cond_18
    move/from16 v35, v34

    :goto_13
    cmpl-float v36, v1, v34

    if-lez v36, :cond_19

    add-float v0, v1, v25

    goto :goto_14

    :cond_19
    move/from16 v0, v34

    :goto_14
    sub-float v37, v27, v0

    .line 348
    iget-boolean v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->undecided:Z

    if-eqz v0, :cond_1b

    .line 349
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Undecided: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->dishes:Ljava/util/List;

    const-string v3, " / "

    invoke-static {v2, v3}, Lcom/quickdinner/planner/print/DesignRenderer$R;->join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    if-nez v11, :cond_1a

    move/from16 v7, v33

    goto :goto_15

    :cond_1a
    move/from16 v7, v28

    :goto_15
    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move v14, v1

    move-object v1, v2

    move-object/from16 v13, p4

    move/from16 v2, v23

    move/from16 v6, v37

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 352
    iget-object v1, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda18;

    invoke-direct {v2, v15, v10, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda18;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 353
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    const/16 v16, 0x2

    add-int/lit8 v0, v0, 0x2

    int-to-float v0, v0

    add-float/2addr v0, v10

    move-object v11, v13

    move v13, v14

    move/from16 v40, v16

    goto/16 :goto_1c

    :cond_1b
    move-object/from16 v8, p4

    move v14, v1

    const/16 v16, 0x2

    move v6, v10

    move/from16 v7, v32

    .line 355
    :goto_16
    iget-object v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->dishes:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/high16 v38, 0x3fc00000    # 1.5f

    if-ge v7, v0, :cond_1f

    if-nez v7, :cond_1c

    const/16 v17, 0x1

    goto :goto_17

    :cond_1c
    move/from16 v17, v32

    .line 358
    :goto_17
    iget-object v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->dishes:Ljava/util/List;

    invoke-interface {v0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/String;

    if-nez v7, :cond_1d

    iget-object v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->dishes:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    if-le v0, v2, :cond_1d

    const/4 v3, 0x1

    goto :goto_18

    :cond_1d
    move/from16 v3, v32

    :goto_18
    const/4 v4, 0x0

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    sub-float v18, v37, v35

    sget-object v19, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move/from16 v2, v23

    move/from16 p4, v6

    move/from16 v6, v18

    move/from16 v39, v7

    move/from16 v7, v29

    move-object v11, v8

    move-object/from16 v8, v19

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 361
    iget v1, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderColor:I

    const v2, 0x3e851eb8    # 0.26f

    mul-float v2, v2, v23

    const v3, 0x400ccccd    # 2.2f

    .line 362
    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v18

    if-eqz v17, :cond_1e

    cmpl-float v2, v35, v34

    if-lez v2, :cond_1e

    const/4 v2, 0x1

    goto :goto_19

    :cond_1e
    move/from16 v2, v32

    .line 365
    :goto_19
    iget-object v3, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v4, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda19;

    move v8, v14

    move/from16 v40, v16

    move-object v14, v4

    move v7, v15

    move v15, v2

    move/from16 v16, v1

    move/from16 v17, v7

    move/from16 v19, p4

    move-object/from16 v20, v0

    move/from16 v21, v23

    move/from16 v22, v35

    invoke-direct/range {v14 .. v22}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda19;-><init>(ZIFFFLandroid/text/StaticLayout;FF)V

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 372
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float v0, v0, v38

    move/from16 v14, p4

    add-float v6, v14, v0

    add-int/lit8 v0, v39, 0x1

    move v15, v7

    move v14, v8

    move-object v8, v11

    move/from16 v16, v40

    move/from16 v11, p3

    move v7, v0

    goto/16 :goto_16

    :cond_1f
    move-object v11, v8

    move v8, v14

    move v7, v15

    move/from16 v40, v16

    move v14, v6

    .line 374
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->who:Lcom/quickdinner/planner/print/PrintDesign$Who;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$Who;->NAME:Lcom/quickdinner/planner/print/PrintDesign$Who;

    if-ne v0, v1, :cond_21

    iget-object v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderName:Ljava/lang/String;

    if-eqz v0, :cond_21

    iget-object v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderName:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_21

    .line 375
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "by "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const v0, 0x3f47ae14    # 0.78f

    mul-float v2, v23, v0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderColor:I

    if-eqz v0, :cond_20

    iget-boolean v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->ink:Z

    if-nez v0, :cond_20

    iget v0, v13, Lcom/quickdinner/planner/print/MenuData$Slot;->adderColor:I

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    const v6, 0x3eb33333    # 0.35f

    invoke-static {v0, v5, v6}, Lcom/quickdinner/planner/print/DesignRenderer$R;->mix(IIF)I

    move-result v0

    goto :goto_1a

    :cond_20
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    :goto_1a
    move v5, v0

    const/4 v13, 0x1

    sget-object v15, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move/from16 v6, v37

    move/from16 v41, v7

    move v7, v13

    move v13, v8

    move-object v8, v15

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 377
    iget-object v1, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda20;

    move/from16 v15, v41

    invoke-direct {v2, v15, v14, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda20;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 378
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float v0, v0, v38

    add-float v6, v14, v0

    goto :goto_1b

    :cond_21
    move v15, v7

    move v13, v8

    move v6, v14

    :goto_1b
    add-float v0, v6, v38

    :goto_1c
    if-lez v36, :cond_22

    add-float v1, v15, v27

    sub-float/2addr v1, v13

    .line 384
    iget-object v2, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v3, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda21;

    invoke-direct {v3, v11, v1, v10, v13}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda21;-><init>(Landroid/graphics/Bitmap;FFF)V

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-float/2addr v10, v13

    add-float v10, v10, v26

    .line 385
    invoke-static {v0, v10}, Ljava/lang/Math;->max(FF)F

    move-result v0

    :cond_22
    move/from16 v10, p3

    if-nez v10, :cond_23

    move/from16 v14, v40

    goto :goto_1d

    :cond_23
    move/from16 v14, v33

    :goto_1d
    int-to-float v1, v14

    add-float v14, v0, v1

    move-object/from16 v13, p2

    move v11, v10

    const/4 v0, 0x1

    move-object/from16 v10, p1

    goto/16 :goto_d

    :cond_24
    move v10, v11

    const/16 v40, 0x2

    if-nez v0, :cond_25

    if-eqz v10, :cond_25

    const-string v1, "Nothing planned"

    const/4 v3, 0x0

    const/4 v4, 0x1

    .line 390
    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    const/4 v7, 0x1

    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move/from16 v2, v23

    move/from16 v6, v27

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 392
    iget-object v1, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda22;

    invoke-direct {v2, v15, v14, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda22;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 393
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    add-int/lit8 v0, v0, 0x4

    int-to-float v0, v0

    add-float/2addr v14, v0

    .line 395
    :cond_25
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    move-object/from16 v1, p1

    invoke-static {v0, v1}, Lcom/quickdinner/planner/weather/WeatherPrint;->hasNote(Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData$Day;)Z

    move-result v0

    if-eqz v0, :cond_29

    move-object/from16 v0, p1

    .line 396
    iget-object v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    invoke-static {v1, v0}, Lcom/quickdinner/planner/weather/WeatherPrint;->noteText(Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData$Day;)Ljava/lang/String;

    move-result-object v1

    if-nez v10, :cond_26

    const v17, 0x40e66666    # 7.2f

    goto :goto_1e

    :cond_26
    const/4 v0, 0x1

    if-ne v10, v0, :cond_27

    goto :goto_1e

    :cond_27
    const/high16 v17, 0x41280000    # 10.5f

    :goto_1e
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v2, v17, v0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    if-nez v10, :cond_28

    const/4 v0, 0x5

    move v7, v0

    goto :goto_1f

    :cond_28
    move/from16 v7, v33

    :goto_1f
    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move/from16 v6, v27

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 398
    iget-object v1, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda23;

    invoke-direct {v2, v15, v14, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda23;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 399
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    add-int/lit8 v0, v0, 0x3

    int-to-float v0, v0

    add-float/2addr v14, v0

    .line 401
    :cond_29
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->lines:I

    if-lez v0, :cond_2a

    const/high16 v0, 0x41700000    # 15.0f

    .line 402
    iget v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v7, v1, v0

    .line 403
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget v8, v0, Lcom/quickdinner/planner/print/PrintDesign;->lines:I

    .line 405
    iget-object v11, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    new-instance v13, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda24;

    move-object v0, v13

    move-object/from16 v1, p0

    move v2, v8

    move v3, v15

    move v4, v14

    move v5, v7

    move/from16 v6, v27

    invoke-direct/range {v0 .. v6}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda24;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;IFFFF)V

    invoke-interface {v11, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    int-to-float v0, v8

    mul-float/2addr v0, v7

    add-float v0, v0, v26

    add-float/2addr v14, v0

    :cond_2a
    if-nez v10, :cond_2b

    move/from16 v0, v40

    goto :goto_20

    :cond_2b
    move/from16 v0, v33

    :goto_20
    int-to-float v0, v0

    add-float/2addr v14, v0

    .line 411
    iput v14, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->h:F

    return-object v12
.end method

.method flowGrocery(FFFF)F
    .locals 18
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "x",
            "y0",
            "w",
            "maxY"
        }
    .end annotation

    move-object/from16 v9, p0

    const/high16 v0, 0x41100000    # 9.0f

    .line 554
    iget v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v10, v1, v0

    move/from16 v11, p2

    .line 555
    :goto_0
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    iget-object v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_8

    .line 556
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    iget v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    const/4 v12, 0x0

    .line 557
    aget-object v1, v0, v12

    const-string v2, "H"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    const/4 v14, 0x1

    .line 558
    aget-object v1, v0, v14

    const/4 v4, 0x0

    if-eqz v13, :cond_0

    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    goto :goto_1

    :cond_0
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    :goto_1
    move v5, v0

    const/high16 v15, 0x41400000    # 12.0f

    if-eqz v13, :cond_1

    move/from16 v6, p3

    goto :goto_2

    :cond_1
    sub-float v0, p3, v15

    move v6, v0

    :goto_2
    if-eqz v13, :cond_2

    move v7, v14

    goto :goto_3

    :cond_2
    const/4 v0, 0x2

    move v7, v0

    :goto_3
    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move v2, v10

    move v3, v13

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v8

    .line 559
    invoke-virtual {v8}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    const/high16 v16, 0x40200000    # 2.5f

    if-eqz v13, :cond_3

    const/high16 v1, 0x40c00000    # 6.0f

    goto :goto_4

    :cond_3
    move/from16 v1, v16

    :goto_4
    add-float v17, v0, v1

    if-eqz v13, :cond_4

    .line 560
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    add-int/2addr v0, v14

    iget-object v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_4

    .line 562
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    iget v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    add-int/2addr v1, v14

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    aget-object v1, v0, v14

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    sub-float v6, p3, v15

    const/4 v7, 0x2

    sget-object v15, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    move v2, v10

    move-object v12, v8

    move-object v8, v15

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float v17, v17, v0

    goto :goto_5

    :cond_4
    move-object v12, v8

    :goto_5
    add-float v17, v11, v17

    cmpl-float v0, v17, p4

    if-lez v0, :cond_5

    goto :goto_8

    :cond_5
    if-eqz v13, :cond_6

    const/4 v0, 0x4

    goto :goto_6

    :cond_6
    const/4 v0, 0x0

    :goto_6
    int-to-float v0, v0

    add-float v3, v11, v0

    if-eqz v13, :cond_7

    .line 567
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v0, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v1, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda6;

    move/from16 v6, p1

    invoke-direct {v1, v6, v3, v12}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda6;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 568
    invoke-virtual {v12}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    add-int/lit8 v0, v0, 0x6

    int-to-float v0, v0

    goto :goto_7

    :cond_7
    move/from16 v6, p1

    const v0, 0x3f4ccccd    # 0.8f

    mul-float/2addr v0, v10

    const/high16 v1, 0x40e00000    # 7.0f

    .line 570
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v4

    .line 571
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v7, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v8, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda7;

    move-object v0, v8

    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object v5, v12

    invoke-direct/range {v0 .. v5}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda7;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FFFLandroid/text/StaticLayout;)V

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 577
    invoke-virtual {v12}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float v0, v0, v16

    :goto_7
    add-float/2addr v11, v0

    .line 579
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    add-int/2addr v0, v14

    iput v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    goto/16 :goto_0

    :cond_8
    :goto_8
    return v11
.end method

.method footers()V
    .locals 16

    move-object/from16 v9, p0

    .line 224
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->pages:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v10

    const/4 v0, 0x0

    move v11, v0

    :goto_0
    if-ge v11, v10, :cond_3

    .line 227
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->footer:Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_1

    :cond_0
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->footer:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    :goto_1
    move-object v1, v0

    .line 228
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->pages:Ljava/util/List;

    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lcom/quickdinner/planner/print/DesignRenderer$Page;

    .line 229
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v13, 0x0

    const/high16 v14, 0x41080000    # 8.5f

    if-eqz v0, :cond_1

    move-object v15, v13

    goto :goto_2

    :cond_1
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v2, v0, v14

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    const v6, 0x3f333333    # 0.7f

    mul-float/2addr v6, v0

    const/4 v7, 0x1

    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    move-object v15, v0

    :goto_2
    const/4 v0, 0x1

    if-le v10, v0, :cond_2

    .line 230
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v1, v11, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " / "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v2, v0, v14

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    const/high16 v6, 0x42a00000    # 80.0f

    const/4 v7, 0x1

    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v13

    .line 231
    :cond_2
    iget-object v0, v12, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v1, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda4;

    invoke-direct {v1, v9, v15, v13}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda4;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;Landroid/text/StaticLayout;Landroid/text/StaticLayout;)V

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v11, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method groceryPage()V
    .locals 10

    .line 599
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->newPage()Lcom/quickdinner/planner/print/DesignRenderer$Page;

    .line 600
    iget-boolean v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groceryStarted:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->side:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "Grocery list"

    goto :goto_1

    :cond_1
    :goto_0
    const-string v0, "Grocery list (continued)"

    :goto_1
    move-object v2, v0

    const/high16 v0, 0x41a00000    # 20.0f

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v3, v1, v0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v6, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    iget v7, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    const/4 v8, 0x1

    sget-object v9, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object v1, p0

    invoke-virtual/range {v1 .. v9}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    const/4 v1, 0x1

    .line 601
    iput-boolean v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groceryStarted:Z

    .line 602
    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    iget v3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    .line 603
    iget-object v4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v4, v4, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v5, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda10;

    invoke-direct {v5, v2, v3, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda10;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 604
    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr v2, v0

    const/high16 v0, 0x41600000    # 14.0f

    add-float/2addr v2, v0

    .line 605
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->landscape:Z

    if-eqz v0, :cond_2

    const/4 v0, 0x4

    goto :goto_2

    :cond_2
    const/4 v0, 0x3

    .line 606
    :goto_2
    iget v3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    add-int/lit8 v4, v0, -0x1

    int-to-float v4, v4

    const/high16 v5, 0x41800000    # 16.0f

    mul-float/2addr v4, v5

    sub-float/2addr v3, v4

    int-to-float v4, v0

    div-float/2addr v3, v4

    .line 607
    iget v4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    const/4 v6, 0x0

    :goto_3
    if-ge v6, v0, :cond_3

    .line 608
    iget v7, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    iget-object v8, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-ge v7, v8, :cond_3

    iget v7, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    int-to-float v8, v6

    add-float v9, v3, v5

    mul-float/2addr v8, v9

    add-float/2addr v7, v8

    iget v8, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->bottom:F

    invoke-virtual {p0, v7, v2, v3, v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->flowGrocery(FFFF)F

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    .line 609
    :cond_3
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    if-ne v0, v4, :cond_4

    add-int/2addr v0, v1

    iput v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    :cond_4
    return-void
.end method

.method header()V
    .locals 20

    move-object/from16 v9, p0

    .line 167
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->title:Ljava/lang/String;

    const-string v1, ""

    if-nez v0, :cond_0

    move-object v2, v1

    goto :goto_0

    :cond_0
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->title:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    move-object v2, v0

    .line 168
    :goto_0
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->subtitle:Ljava/lang/String;

    if-eqz v0, :cond_2

    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->subtitle:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->subtitle:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_2
    :goto_1
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->autoSub:Ljava/lang/String;

    :goto_2
    if-nez v0, :cond_3

    move-object v10, v1

    goto :goto_3

    :cond_3
    move-object v10, v0

    .line 170
    :goto_3
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    const/4 v1, 0x1

    const/4 v11, 0x0

    if-eqz v0, :cond_4

    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->photoMode:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    sget-object v3, Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;->BANNER:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    if-ne v0, v3, :cond_4

    move v0, v1

    goto :goto_4

    :cond_4
    move v0, v11

    .line 171
    :goto_4
    iget-object v3, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_5

    iget-object v3, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v3, v3, Lcom/quickdinner/planner/print/PrintDesign;->photoMode:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    sget-object v4, Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;->CORNER:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    if-ne v3, v4, :cond_5

    move v12, v1

    goto :goto_5

    :cond_5
    move v12, v11

    :goto_5
    const/high16 v13, 0x41380000    # 11.5f

    const/4 v14, 0x0

    if-eqz v0, :cond_a

    .line 173
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->landscape:Z

    if-eqz v0, :cond_6

    const/high16 v0, 0x42dc0000    # 110.0f

    goto :goto_6

    :cond_6
    const/high16 v0, 0x43160000    # 150.0f

    :goto_6
    move v11, v0

    .line 174
    iget v12, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    iget v15, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    .line 175
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->titleCenter:Z

    if-eqz v0, :cond_7

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    goto :goto_7

    :cond_7
    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    :goto_7
    move-object/from16 v16, v0

    .line 176
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/high16 v17, 0x41c00000    # 24.0f

    if-eqz v0, :cond_8

    move-object/from16 v18, v14

    goto :goto_8

    :cond_8
    invoke-virtual/range {p0 .. p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->titlePt()F

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v6, -0x1

    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    sub-float v7, v0, v17

    const/4 v8, 0x2

    move-object/from16 v0, p0

    move-object v1, v2

    move v2, v3

    move v3, v4

    move v4, v5

    move v5, v6

    move v6, v7

    move v7, v8

    move-object/from16 v8, v16

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    move-object/from16 v18, v0

    .line 177
    :goto_8
    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_9

    move-object v6, v14

    goto :goto_9

    :cond_9
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v2, v0, v13

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, -0x1

    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    sub-float v6, v0, v17

    const/4 v7, 0x1

    move-object/from16 v0, p0

    move-object v1, v10

    move-object/from16 v8, v16

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    move-object v6, v0

    .line 178
    :goto_9
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v7, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v8, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda12;

    move-object v0, v8

    move-object/from16 v1, p0

    move v2, v12

    move v3, v15

    move v4, v11

    move-object/from16 v5, v18

    invoke-direct/range {v0 .. v6}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda12;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FFFLandroid/text/StaticLayout;Landroid/text/StaticLayout;)V

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 193
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    const/high16 v1, 0x41400000    # 12.0f

    add-float/2addr v11, v1

    add-float/2addr v0, v11

    iput v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    goto/16 :goto_12

    :cond_a
    const/4 v15, 0x0

    if-eqz v12, :cond_b

    const/high16 v0, 0x42a80000    # 84.0f

    move/from16 v16, v0

    goto :goto_a

    :cond_b
    move/from16 v16, v15

    .line 196
    :goto_a
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    if-eqz v12, :cond_c

    const/high16 v1, 0x41600000    # 14.0f

    add-float v1, v16, v1

    goto :goto_b

    :cond_c
    move v1, v15

    :goto_b
    sub-float v17, v0, v1

    .line 197
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->titleCenter:Z

    if-eqz v0, :cond_d

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    goto :goto_c

    :cond_d
    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    :goto_c
    move-object/from16 v18, v0

    .line 198
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_e

    move-object/from16 v19, v14

    goto :goto_d

    :cond_e
    invoke-virtual/range {p0 .. p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->titlePt()F

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v6, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    const/4 v7, 0x2

    move-object/from16 v0, p0

    move-object v1, v2

    move v2, v3

    move v3, v4

    move v4, v5

    move v5, v6

    move/from16 v6, v17

    move-object/from16 v8, v18

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    move-object/from16 v19, v0

    .line 199
    :goto_d
    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_f

    move-object v5, v14

    goto :goto_e

    :cond_f
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v2, v0, v13

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v5, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    const/4 v7, 0x2

    move-object/from16 v0, p0

    move-object v1, v10

    move/from16 v6, v17

    move-object/from16 v8, v18

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    move-object v5, v0

    .line 200
    :goto_e
    iget v10, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    iget v2, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    if-nez v19, :cond_10

    move v0, v11

    goto :goto_f

    .line 201
    :cond_10
    invoke-virtual/range {v19 .. v19}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    :goto_f
    if-nez v5, :cond_11

    goto :goto_10

    :cond_11
    invoke-virtual {v5}, Landroid/text/StaticLayout;->getHeight()I

    move-result v1

    add-int/lit8 v11, v1, 0x2

    :goto_10
    add-int/2addr v0, v11

    int-to-float v0, v0

    if-eqz v12, :cond_12

    move/from16 v1, v16

    goto :goto_11

    :cond_12
    move v1, v15

    .line 202
    :goto_11
    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v11

    .line 203
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v13, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v14, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda13;

    move-object v0, v14

    move-object/from16 v1, p0

    move v3, v11

    move-object/from16 v4, v19

    move v6, v10

    move v7, v12

    move/from16 v8, v16

    invoke-direct/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda13;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FFLandroid/text/StaticLayout;Landroid/text/StaticLayout;FZF)V

    invoke-interface {v13, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 209
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    add-float/2addr v0, v11

    iput v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    cmpl-float v1, v11, v15

    if-lez v1, :cond_13

    const/high16 v1, 0x40c00000    # 6.0f

    add-float/2addr v0, v1

    .line 212
    iget-object v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v1, v1, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda14;

    invoke-direct {v2, v9, v10, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda14;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FF)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 216
    iget v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    const/high16 v1, 0x41800000    # 16.0f

    add-float/2addr v0, v1

    iput v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    :cond_13
    :goto_12
    return-void
.end method

.method synthetic lambda$buildTile$16$com-quickdinner-planner-print-DesignRenderer$R(IFFFFLandroid/graphics/Canvas;)V
    .locals 8

    .line 406
    new-instance v6, Landroid/graphics/Paint;

    invoke-direct {v6}, Landroid/graphics/Paint;-><init>()V

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3f333333    # 0.7f

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v0, 0x1

    move v7, v0

    :goto_0
    if-gt v7, p1, :cond_0

    int-to-float v0, v7

    mul-float/2addr v0, p4

    add-float v4, p3, v0

    add-float v3, p2, p5

    move-object v0, p6

    move v1, p2

    move v2, v4

    move-object v5, v6

    .line 407
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method synthetic lambda$buildTile$7$com-quickdinner-planner-print-DesignRenderer$R(ZFFZFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 6

    .line 0
    if-eqz p1, :cond_0

    .line 314
    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5}, Landroid/graphics/Paint;-><init>()V

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->accent:I

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object v0, p7

    move v3, p2

    move v4, p3

    .line 315
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_2

    :cond_0
    if-eqz p4, :cond_3

    .line 317
    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5}, Landroid/graphics/Paint;-><init>()V

    iget-boolean v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ink:Z

    if-eqz v0, :cond_1

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    goto :goto_0

    :cond_1
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->accent:I

    :goto_0
    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget-boolean v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ink:Z

    if-eqz v0, :cond_2

    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_1

    :cond_2
    const v0, 0x3fe66666    # 1.8f

    :goto_1
    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v1, 0x0

    move-object v0, p7

    move v2, p3

    move v3, p2

    move v4, p3

    .line 318
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 320
    :cond_3
    :goto_2
    invoke-virtual {p7}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p6}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    sub-float v0, p3, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    invoke-virtual {p7, p5, v0}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p6, p7}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p7}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method synthetic lambda$flowGrocery$21$com-quickdinner-planner-print-DesignRenderer$R(FFFLandroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 6

    .line 572
    new-instance v5, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {v5, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 573
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3f4ccccd    # 0.8f

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 v0, 0x3fc00000    # 1.5f

    add-float v2, p2, v0

    add-float v3, p1, p3

    add-float v4, v2, p3

    move-object v0, p5

    move v1, p1

    .line 574
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 575
    invoke-virtual {p5}, Landroid/graphics/Canvas;->save()I

    const/high16 p3, 0x41400000    # 12.0f

    add-float/2addr p1, p3

    invoke-virtual {p5, p1, p2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p4, p5}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p5}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method synthetic lambda$footers$6$com-quickdinner-planner-print-DesignRenderer$R(Landroid/text/StaticLayout;Landroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 4

    .line 232
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ph:F

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    sub-float/2addr v0, v1

    const/high16 v1, 0x41b00000    # 22.0f

    sub-float/2addr v0, v1

    const/high16 v1, 0x41000000    # 8.0f

    add-float/2addr v0, v1

    if-eqz p1, :cond_0

    .line 233
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pw:F

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    const v3, 0x3eb33333    # 0.35f

    mul-float/2addr v2, v3

    sub-float/2addr v1, v2

    invoke-virtual {p3, v1, v0}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p1, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    :cond_0
    if-eqz p2, :cond_1

    .line 234
    invoke-virtual {p3}, Landroid/graphics/Canvas;->save()I

    iget p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pw:F

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    sub-float/2addr p1, v1

    const/high16 v1, 0x42a00000    # 80.0f

    sub-float/2addr p1, v1

    invoke-virtual {p3, p1, v0}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p2, p3}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p3}, Landroid/graphics/Canvas;->restore()V

    :cond_1
    return-void
.end method

.method synthetic lambda$header$3$com-quickdinner-planner-print-DesignRenderer$R(FFFLandroid/text/StaticLayout;Landroid/text/StaticLayout;Landroid/graphics/Canvas;)V
    .locals 8

    .line 179
    new-instance v0, Landroid/graphics/RectF;

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    add-float/2addr v1, p1

    add-float v6, p2, p3

    invoke-direct {v0, p1, p2, v1, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 180
    iget-object p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    const/16 p3, 0xff

    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {p6, p2, v0, v1, p3}, Lcom/quickdinner/planner/print/DesignRenderer$R;->drawCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FI)V

    const/4 p2, 0x0

    if-nez p4, :cond_0

    move p3, p2

    goto :goto_0

    .line 181
    :cond_0
    invoke-virtual {p4}, Landroid/text/StaticLayout;->getHeight()I

    move-result p3

    :goto_0
    if-nez p5, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {p5}, Landroid/text/StaticLayout;->getHeight()I

    move-result p2

    :goto_1
    add-int/2addr p3, p2

    add-int/lit8 p3, p3, 0xe

    int-to-float p2, p3

    if-nez p4, :cond_2

    if-eqz p5, :cond_4

    .line 183
    :cond_2
    invoke-virtual {p6}, Landroid/graphics/Canvas;->save()I

    .line 184
    new-instance p3, Landroid/graphics/Path;

    invoke-direct {p3}, Landroid/graphics/Path;-><init>()V

    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {p3, v0, v1, v1, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual {p6, p3}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    .line 185
    new-instance v7, Landroid/graphics/Paint;

    invoke-direct {v7}, Landroid/graphics/Paint;-><init>()V

    const/high16 p3, -0x67000000

    invoke-virtual {v7, p3}, Landroid/graphics/Paint;->setColor(I)V

    sub-float p2, v6, p2

    const/high16 p3, 0x40c00000    # 6.0f

    sub-float v4, p2, p3

    .line 186
    iget p3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    add-float v5, p1, p3

    move-object v2, p6

    move v3, p1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 187
    invoke-virtual {p6}, Landroid/graphics/Canvas;->restore()V

    const/high16 p3, 0x41400000    # 12.0f

    if-eqz p4, :cond_3

    .line 189
    invoke-virtual {p6}, Landroid/graphics/Canvas;->save()I

    add-float v0, p1, p3

    invoke-virtual {p6, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p4, p6}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p6}, Landroid/graphics/Canvas;->restore()V

    invoke-virtual {p4}, Landroid/text/StaticLayout;->getHeight()I

    move-result p4

    int-to-float p4, p4

    add-float/2addr p2, p4

    :cond_3
    if-eqz p5, :cond_4

    .line 190
    invoke-virtual {p6}, Landroid/graphics/Canvas;->save()I

    add-float/2addr p1, p3

    const/high16 p3, 0x40000000    # 2.0f

    add-float/2addr p2, p3

    invoke-virtual {p6, p1, p2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p5, p6}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p6}, Landroid/graphics/Canvas;->restore()V

    :cond_4
    return-void
.end method

.method synthetic lambda$header$4$com-quickdinner-planner-print-DesignRenderer$R(FFLandroid/text/StaticLayout;Landroid/text/StaticLayout;FZFLandroid/graphics/Canvas;)V
    .locals 2

    .line 0
    const/4 v0, 0x0

    if-nez p3, :cond_0

    move v1, v0

    goto :goto_0

    .line 204
    :cond_0
    invoke-virtual {p3}, Landroid/text/StaticLayout;->getHeight()I

    move-result v1

    :goto_0
    int-to-float v1, v1

    sub-float/2addr p2, v1

    if-nez p4, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {p4}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    add-int/lit8 v0, v0, 0x2

    :goto_1
    int-to-float v0, v0

    sub-float/2addr p2, v0

    const/high16 v0, 0x40000000    # 2.0f

    div-float/2addr p2, v0

    add-float/2addr p2, p1

    if-eqz p3, :cond_2

    .line 205
    invoke-virtual {p8}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p8, p5, p2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p3, p8}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p8}, Landroid/graphics/Canvas;->restore()V

    invoke-virtual {p3}, Landroid/text/StaticLayout;->getHeight()I

    move-result p3

    add-int/lit8 p3, p3, 0x2

    int-to-float p3, p3

    add-float/2addr p2, p3

    :cond_2
    if-eqz p4, :cond_3

    .line 206
    invoke-virtual {p8}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p8, p5, p2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p4, p8}, Landroid/text/StaticLayout;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p8}, Landroid/graphics/Canvas;->restore()V

    :cond_3
    if-eqz p6, :cond_4

    .line 207
    iget-object p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    new-instance p3, Landroid/graphics/RectF;

    iget p4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    add-float p6, p5, p4

    sub-float/2addr p6, p7

    add-float/2addr p5, p4

    add-float/2addr p7, p1

    invoke-direct {p3, p6, p1, p5, p7}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 p1, 0x41200000    # 10.0f

    const/16 p4, 0xff

    invoke-static {p8, p2, p3, p1, p4}, Lcom/quickdinner/planner/print/DesignRenderer$R;->drawCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FI)V

    :cond_4
    return-void
.end method

.method synthetic lambda$header$5$com-quickdinner-planner-print-DesignRenderer$R(FFLandroid/graphics/Canvas;)V
    .locals 6

    .line 213
    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5}, Landroid/graphics/Paint;-><init>()V

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->accent:I

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v0, 0x40000000    # 2.0f

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 214
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    add-float v3, p1, v0

    move-object v0, p3

    move v1, p1

    move v2, p2

    move v4, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method synthetic lambda$newPage$0$com-quickdinner-planner-print-DesignRenderer$R(Landroid/graphics/Canvas;)V
    .locals 1

    .line 126
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->page:I

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawColor(I)V

    return-void
.end method

.method synthetic lambda$newPage$1$com-quickdinner-planner-print-DesignRenderer$R(Landroid/graphics/Canvas;)V
    .locals 5

    .line 128
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    new-instance v1, Landroid/graphics/RectF;

    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pw:F

    iget v3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ph:F

    const/4 v4, 0x0

    invoke-direct {v1, v4, v4, v2, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/16 v2, 0x2e

    invoke-static {p1, v0, v1, v4, v2}, Lcom/quickdinner/planner/print/DesignRenderer$R;->drawCrop(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FI)V

    return-void
.end method

.method synthetic lambda$newPage$2$com-quickdinner-planner-print-DesignRenderer$R(FLandroid/graphics/Canvas;)V
    .locals 5

    .line 133
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    .line 134
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->accent:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const v1, 0x3fb33333    # 1.4f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 135
    new-instance v1, Landroid/graphics/RectF;

    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pw:F

    sub-float/2addr v2, p1

    iget v3, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ph:F

    sub-float/2addr v3, p1

    invoke-direct {v1, p1, p1, v2, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean p1, p1, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    const/high16 v2, 0x41000000    # 8.0f

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    move p1, v2

    goto :goto_0

    :cond_0
    move p1, v3

    :goto_0
    iget-object v4, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v4, v4, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    move v2, v3

    :goto_1
    invoke-virtual {p2, v1, p1, v2, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method synthetic lambda$placeEmpty$18$com-quickdinner-planner-print-DesignRenderer$R(FFFFLandroid/graphics/Canvas;)V
    .locals 6

    .line 494
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faintHi:I

    if-eqz v0, :cond_0

    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5}, Landroid/graphics/Paint;-><init>()V

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faintHi:I

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    add-float v3, p1, p3

    add-float v4, p2, p4

    move-object v0, p5

    move v1, p1

    move v2, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 495
    :cond_0
    new-instance v5, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {v5, v0}, Landroid/graphics/Paint;-><init>(I)V

    .line 496
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3f4ccccd    # 0.8f

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    add-float v3, p1, p3

    add-float v4, p2, p4

    move-object v0, p5

    move v1, p1

    move v2, p2

    .line 497
    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method synthetic lambda$placeTile$17$com-quickdinner-planner-print-DesignRenderer$R(FFFFFZLcom/quickdinner/planner/print/DesignRenderer$R$Tile;Landroid/graphics/Canvas;)V
    .locals 7

    .line 424
    new-instance v0, Landroid/graphics/RectF;

    add-float v1, p1, p3

    add-float v2, p2, p4

    invoke-direct {v0, p1, p2, v1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 425
    invoke-virtual {p8}, Landroid/graphics/Canvas;->save()I

    .line 426
    new-instance v1, Landroid/graphics/Path;

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    .line 427
    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v1, v0, p5, p5, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    .line 428
    invoke-virtual {p8, v1}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    if-eqz p6, :cond_0

    .line 429
    iget p6, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faint:I

    if-eqz p6, :cond_0

    new-instance p6, Landroid/graphics/Paint;

    invoke-direct {p6}, Landroid/graphics/Paint;-><init>()V

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faint:I

    invoke-virtual {p6, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p8, v0, p6}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 430
    :cond_0
    invoke-virtual {p8, p1, p2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 431
    iget-object p1, p7, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->ops:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/quickdinner/planner/print/DesignRenderer$Op;

    invoke-interface {p2, p8}, Lcom/quickdinner/planner/print/DesignRenderer$Op;->draw(Landroid/graphics/Canvas;)V

    goto :goto_0

    .line 432
    :cond_1
    iget-object p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean p1, p1, Lcom/quickdinner/planner/print/PrintDesign;->fillLines:Z

    if-eqz p1, :cond_2

    .line 433
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    iget p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3f333333    # 0.7f

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 p2, 0x41700000    # 15.0f

    .line 434
    iget p6, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float/2addr p6, p2

    .line 436
    iget p2, p7, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->h:F

    :goto_1
    add-float/2addr p2, p6

    const/high16 p7, 0x40400000    # 3.0f

    sub-float p7, p4, p7

    cmpg-float p7, p2, p7

    if-gez p7, :cond_2

    const/high16 p7, 0x40a00000    # 5.0f

    sub-float v4, p3, p7

    const/high16 v2, 0x40a00000    # 5.0f

    move-object v1, p8

    move v3, p2

    move v5, p2

    move-object v6, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto :goto_1

    .line 438
    :cond_2
    invoke-virtual {p8}, Landroid/graphics/Canvas;->restore()V

    .line 439
    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    .line 440
    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3f4ccccd    # 0.8f

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 441
    invoke-virtual {p8, v0, p5, p5, p1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method synthetic lambda$sideBar$22$com-quickdinner-planner-print-DesignRenderer$R(FFFFLandroid/graphics/Canvas;)V
    .locals 3

    .line 588
    new-instance v0, Landroid/graphics/RectF;

    add-float/2addr p3, p1

    invoke-direct {v0, p1, p2, p3, p4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 589
    iget p1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faint:I

    const/4 p2, 0x1

    const/high16 p3, 0x40e00000    # 7.0f

    const/4 p4, 0x0

    if-eqz p1, :cond_2

    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->faint:I

    invoke-virtual {p1, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v1, v1, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    if-eqz v1, :cond_0

    move v1, p3

    goto :goto_0

    :cond_0
    move v1, p4

    :goto_0
    iget-object v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v2, v2, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    if-eqz v2, :cond_1

    move v2, p3

    goto :goto_1

    :cond_1
    move v2, p4

    :goto_1
    invoke-virtual {p5, v0, v1, v2, p1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 590
    :cond_2
    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->line:I

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3f4ccccd    # 0.8f

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 591
    iget-object p2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean p2, p2, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    if-eqz p2, :cond_3

    move p2, p3

    goto :goto_2

    :cond_3
    move p2, p4

    :goto_2
    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v1, v1, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    if-eqz v1, :cond_4

    goto :goto_3

    :cond_4
    move p3, p4

    :goto_3
    invoke-virtual {p5, v0, p2, p3, p1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method layoutFlow()V
    .locals 22

    move-object/from16 v8, p0

    .line 512
    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->layout:Lcom/quickdinner/planner/print/PrintDesign$Layout;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$Layout;->POSTER:Lcom/quickdinner/planner/print/PrintDesign$Layout;

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-ne v0, v1, :cond_0

    move v0, v10

    goto :goto_0

    :cond_0
    move v0, v9

    :goto_0
    const/4 v1, 0x2

    if-eqz v0, :cond_1

    move v11, v1

    goto :goto_1

    :cond_1
    move v11, v10

    :goto_1
    if-eqz v0, :cond_2

    .line 514
    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->landscape:Z

    if-eqz v0, :cond_3

    const/4 v1, 0x3

    goto :goto_2

    :cond_2
    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->landscape:Z

    if-eqz v0, :cond_4

    :cond_3
    :goto_2
    move v12, v1

    goto :goto_3

    :cond_4
    move v12, v10

    .line 516
    :goto_3
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 517
    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_5
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_9

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/quickdinner/planner/print/MenuData$Day;

    .line 518
    iget-object v2, v1, Lcom/quickdinner/planner/print/MenuData$Day;->slots:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_7

    iget-object v2, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v2, v2, Lcom/quickdinner/planner/print/PrintDesign;->notes:Z

    if-eqz v2, :cond_6

    iget-object v2, v1, Lcom/quickdinner/planner/print/MenuData$Day;->note:Ljava/lang/String;

    if-eqz v2, :cond_6

    iget-object v2, v1, Lcom/quickdinner/planner/print/MenuData$Day;->note:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_7

    :cond_6
    move v2, v10

    goto :goto_5

    :cond_7
    move v2, v9

    .line 519
    :goto_5
    iget-object v3, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v3, v3, Lcom/quickdinner/planner/print/PrintDesign;->hideEmpty:Z

    if-eqz v3, :cond_8

    if-nez v2, :cond_5

    :cond_8
    invoke-interface {v13, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_9
    move v0, v9

    .line 521
    :goto_6
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_f

    .line 523
    :goto_7
    invoke-virtual/range {p0 .. p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->availW()F

    move-result v1

    add-int/lit8 v2, v12, -0x1

    int-to-float v2, v2

    const/high16 v14, 0x41200000    # 10.0f

    mul-float/2addr v2, v14

    sub-float/2addr v1, v2

    int-to-float v2, v12

    div-float v15, v1, v2

    .line 525
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    const/16 v16, 0x0

    move v1, v0

    move/from16 v2, v16

    .line 527
    :goto_8
    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v3

    add-int v6, v0, v12

    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    move-result v3

    if-ge v1, v3, :cond_a

    .line 528
    invoke-interface {v13, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/quickdinner/planner/print/MenuData$Day;

    invoke-virtual {v8, v3, v15, v11, v9}, Lcom/quickdinner/planner/print/DesignRenderer$R;->buildTile(Lcom/quickdinner/planner/print/MenuData$Day;FIZ)Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;

    move-result-object v3

    .line 529
    invoke-interface {v7, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 530
    iget v3, v3, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->h:F

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    .line 532
    :cond_a
    iget v1, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    iget v3, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    const/high16 v4, 0x3f000000    # 0.5f

    add-float/2addr v3, v4

    cmpg-float v3, v1, v3

    if-gtz v3, :cond_b

    move v3, v10

    goto :goto_9

    :cond_b
    move v3, v9

    .line 533
    :goto_9
    iget v4, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->bottom:F

    sub-float v5, v4, v1

    cmpl-float v5, v2, v5

    if-lez v5, :cond_c

    if-nez v3, :cond_c

    invoke-virtual/range {p0 .. p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->newPage()Lcom/quickdinner/planner/print/DesignRenderer$Page;

    goto :goto_7

    :cond_c
    sub-float/2addr v4, v1

    .line 534
    invoke-static {v2, v4}, Ljava/lang/Math;->min(FF)F

    move-result v17

    move v5, v9

    .line 535
    :goto_a
    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v0

    if-ge v5, v0, :cond_e

    invoke-interface {v7, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;

    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    int-to-float v2, v5

    add-float v3, v15, v14

    mul-float/2addr v2, v3

    add-float/2addr v2, v0

    iget v3, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->round:Z

    if-eqz v0, :cond_d

    const/high16 v0, 0x40e00000    # 7.0f

    move/from16 v18, v0

    goto :goto_b

    :cond_d
    move/from16 v18, v16

    :goto_b
    const/16 v19, 0x1

    move-object/from16 v0, p0

    move v4, v15

    move/from16 v20, v5

    move/from16 v5, v17

    move/from16 v21, v6

    move/from16 v6, v18

    move-object/from16 v18, v7

    move/from16 v7, v19

    invoke-virtual/range {v0 .. v7}, Lcom/quickdinner/planner/print/DesignRenderer$R;->placeTile(Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;FFFFFZ)V

    add-int/lit8 v5, v20, 0x1

    move-object/from16 v7, v18

    move/from16 v6, v21

    goto :goto_a

    :cond_e
    move/from16 v21, v6

    .line 536
    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    add-float v17, v17, v14

    add-float v0, v0, v17

    iput v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    move/from16 v0, v21

    goto/16 :goto_6

    :cond_f
    return-void
.end method

.method layoutGrid()V
    .locals 24

    move-object/from16 v8, p0

    .line 447
    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    const/4 v9, 0x0

    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/quickdinner/planner/print/MenuData$Day;

    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    iget-object v1, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v1, v1, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    iget-object v2, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v2, v2, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v10, 0x1

    sub-int/2addr v2, v10

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/quickdinner/planner/print/MenuData$Day;

    iget-object v1, v1, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    .line 448
    iget-object v2, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v2, v2, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/quickdinner/planner/print/MenuData$Day;

    iget-object v4, v3, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    invoke-virtual {v4, v0}, Ljava/time/LocalDate;->isBefore(Ljava/time/chrono/ChronoLocalDate;)Z

    move-result v4

    if-eqz v4, :cond_1

    iget-object v0, v3, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    :cond_1
    iget-object v4, v3, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    invoke-virtual {v4, v1}, Ljava/time/LocalDate;->isAfter(Ljava/time/chrono/ChronoLocalDate;)Z

    move-result v4

    if-eqz v4, :cond_0

    iget-object v1, v3, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    goto :goto_0

    .line 449
    :cond_2
    iget-object v2, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v2, v2, Lcom/quickdinner/planner/print/PrintDesign;->sundayStart:Z

    if-eqz v2, :cond_3

    sget-object v2, Ljava/time/DayOfWeek;->SUNDAY:Ljava/time/DayOfWeek;

    goto :goto_1

    :cond_3
    sget-object v2, Ljava/time/DayOfWeek;->MONDAY:Ljava/time/DayOfWeek;

    .line 450
    :goto_1
    invoke-static {v2}, Ljava/time/temporal/TemporalAdjusters;->previousOrSame(Ljava/time/DayOfWeek;)Ljava/time/temporal/TemporalAdjuster;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/time/LocalDate;->with(Ljava/time/temporal/TemporalAdjuster;)Ljava/time/LocalDate;

    move-result-object v11

    const-wide/16 v3, 0x1

    .line 451
    invoke-virtual {v2, v3, v4}, Ljava/time/DayOfWeek;->minus(J)Ljava/time/DayOfWeek;

    move-result-object v0

    invoke-static {v0}, Ljava/time/temporal/TemporalAdjusters;->nextOrSame(Ljava/time/DayOfWeek;)Ljava/time/temporal/TemporalAdjuster;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/time/LocalDate;->with(Ljava/time/temporal/TemporalAdjuster;)Ljava/time/LocalDate;

    move-result-object v0

    .line 452
    sget-object v1, Ljava/time/temporal/ChronoUnit;->DAYS:Ljava/time/temporal/ChronoUnit;

    invoke-virtual {v1, v11, v0}, Ljava/time/temporal/ChronoUnit;->between(Ljava/time/temporal/Temporal;Ljava/time/temporal/Temporal;)J

    move-result-wide v0

    add-long/2addr v0, v3

    long-to-int v0, v0

    const/4 v12, 0x7

    div-int/lit8 v13, v0, 0x7

    const/4 v14, 0x2

    if-gt v13, v14, :cond_4

    move v0, v10

    goto :goto_2

    :cond_4
    move v0, v9

    .line 453
    :goto_2
    iput-boolean v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->gridPhotos:Z

    .line 454
    new-instance v15, Ljava/util/HashMap;

    invoke-direct {v15}, Ljava/util/HashMap;-><init>()V

    .line 455
    iget-object v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/quickdinner/planner/print/MenuData$Day;

    iget-object v2, v1, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    invoke-interface {v15, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :cond_5
    move v7, v9

    move v0, v10

    :goto_4
    if-ge v7, v13, :cond_11

    const-wide/16 v1, 0x7

    int-to-long v3, v7

    mul-long/2addr v3, v1

    .line 458
    invoke-virtual {v11, v3, v4}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    move-result-object v1

    .line 460
    :goto_5
    invoke-virtual/range {p0 .. p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->availW()F

    move-result v2

    const/high16 v3, 0x40e00000    # 7.0f

    div-float v6, v2, v3

    const/4 v3, 0x0

    if-eqz v0, :cond_6

    const/high16 v4, 0x41800000    # 16.0f

    .line 462
    iget v5, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float/2addr v5, v4

    goto :goto_6

    :cond_6
    move v5, v3

    :goto_6
    new-array v4, v12, [Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;

    move v14, v9

    :goto_7
    if-ge v14, v12, :cond_a

    move/from16 v18, v13

    int-to-long v12, v14

    .line 466
    invoke-virtual {v1, v12, v13}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    move-result-object v12

    invoke-interface {v15, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/quickdinner/planner/print/MenuData$Day;

    if-eqz v12, :cond_9

    .line 468
    iget-object v13, v12, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    invoke-virtual {v13}, Ljava/time/LocalDate;->getDayOfMonth()I

    move-result v13

    if-eq v13, v10, :cond_8

    iget-object v13, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v13, v13, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v13, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    if-ne v12, v13, :cond_7

    goto :goto_8

    :cond_7
    move v13, v9

    goto :goto_9

    :cond_8
    :goto_8
    move v13, v10

    :goto_9
    invoke-virtual {v8, v12, v6, v9, v13}, Lcom/quickdinner/planner/print/DesignRenderer$R;->buildTile(Lcom/quickdinner/planner/print/MenuData$Day;FIZ)Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;

    move-result-object v12

    aput-object v12, v4, v14

    .line 469
    iget v12, v12, Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;->h:F

    invoke-static {v3, v12}, Ljava/lang/Math;->max(FF)F

    move-result v3

    :cond_9
    add-int/lit8 v14, v14, 0x1

    move/from16 v13, v18

    const/4 v12, 0x7

    goto :goto_7

    :cond_a
    move/from16 v18, v13

    .line 472
    iget v12, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->bottom:F

    iget v13, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    sub-float/2addr v12, v13

    sub-float/2addr v12, v5

    .line 473
    iget v14, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    const/high16 v19, 0x3f000000    # 0.5f

    add-float v14, v14, v19

    cmpg-float v13, v13, v14

    if-gtz v13, :cond_b

    move v13, v10

    goto :goto_a

    :cond_b
    move v13, v9

    :goto_a
    cmpl-float v14, v3, v12

    if-lez v14, :cond_c

    if-nez v13, :cond_c

    .line 474
    invoke-virtual/range {p0 .. p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->newPage()Lcom/quickdinner/planner/print/DesignRenderer$Page;

    move v0, v10

    move/from16 v13, v18

    const/4 v12, 0x7

    const/4 v14, 0x2

    goto :goto_5

    :cond_c
    sub-int v13, v18, v7

    const/high16 v1, 0x42600000    # 56.0f

    .line 476
    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    move/from16 v14, v18

    const/4 v3, 0x2

    if-gt v14, v3, :cond_d

    const/high16 v16, 0x43c80000    # 400.0f

    goto :goto_b

    :cond_d
    const/high16 v16, 0x43700000    # 240.0f

    :goto_b
    move/from16 v3, v16

    int-to-float v13, v13

    div-float v13, v12, v13

    invoke-static {v3, v13}, Ljava/lang/Math;->min(FF)F

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(FF)F

    move-result v1

    .line 477
    invoke-static {v1, v12}, Ljava/lang/Math;->min(FF)F

    move-result v12

    if-eqz v0, :cond_e

    .line 478
    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    invoke-virtual {v8, v0, v2, v6}, Lcom/quickdinner/planner/print/DesignRenderer$R;->weekdayHeader(FFF)V

    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    add-float/2addr v0, v5

    iput v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    move v13, v9

    goto :goto_c

    :cond_e
    move v13, v0

    .line 479
    :goto_c
    iget v5, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    move v3, v9

    const/4 v2, 0x7

    :goto_d
    if-ge v3, v2, :cond_10

    int-to-float v0, v3

    mul-float/2addr v0, v6

    add-float v1, v5, v0

    .line 482
    aget-object v16, v4, v3

    if-eqz v16, :cond_f

    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    const/16 v17, 0x0

    const/16 v19, 0x0

    move/from16 v20, v0

    move-object/from16 v0, p0

    move/from16 v21, v1

    move-object/from16 v1, v16

    move/from16 v16, v2

    move/from16 v2, v21

    move/from16 v18, v3

    const/16 v22, 0x2

    move/from16 v3, v20

    move-object/from16 v20, v4

    move v4, v6

    move/from16 v23, v5

    move v5, v12

    move v9, v6

    move/from16 v6, v17

    move/from16 v17, v7

    move/from16 v7, v19

    invoke-virtual/range {v0 .. v7}, Lcom/quickdinner/planner/print/DesignRenderer$R;->placeTile(Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;FFFFFZ)V

    goto :goto_e

    :cond_f
    move/from16 v21, v1

    move/from16 v16, v2

    move/from16 v18, v3

    move-object/from16 v20, v4

    move/from16 v23, v5

    move v9, v6

    move/from16 v17, v7

    const/16 v22, 0x2

    .line 483
    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    move/from16 v5, v21

    invoke-virtual {v8, v5, v0, v9, v12}, Lcom/quickdinner/planner/print/DesignRenderer$R;->placeEmpty(FFFF)V

    :goto_e
    add-int/lit8 v3, v18, 0x1

    move v6, v9

    move/from16 v2, v16

    move/from16 v7, v17

    move-object/from16 v4, v20

    move/from16 v5, v23

    const/4 v9, 0x0

    goto :goto_d

    :cond_10
    move/from16 v16, v2

    move/from16 v17, v7

    const/16 v22, 0x2

    .line 485
    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    add-float/2addr v0, v12

    iput v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    add-int/lit8 v7, v17, 0x1

    move v0, v13

    move v13, v14

    move/from16 v12, v16

    move/from16 v14, v22

    const/4 v9, 0x0

    goto/16 :goto_4

    .line 489
    :cond_11
    iget v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    const/high16 v1, 0x41000000    # 8.0f

    add-float/2addr v0, v1

    iput v0, v8, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    return-void
.end method

.method mealPhoto(Lcom/quickdinner/planner/print/MenuData$Slot;)Landroid/graphics/Bitmap;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "s"
        }
    .end annotation

    .line 284
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->imgs:Lcom/quickdinner/planner/print/DesignRenderer$Images;

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    iget-object v0, p1, Lcom/quickdinner/planner/print/MenuData$Slot;->imageUrl:Ljava/lang/String;

    if-nez v0, :cond_0

    goto :goto_0

    .line 285
    :cond_0
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->mealPhotos:Lcom/quickdinner/planner/print/PrintDesign$MealPhotos;

    sget-object v2, Lcom/quickdinner/planner/print/PrintDesign$MealPhotos;->OFF:Lcom/quickdinner/planner/print/PrintDesign$MealPhotos;

    if-ne v0, v2, :cond_1

    return-object v1

    .line 286
    :cond_1
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->mealPhotos:Lcom/quickdinner/planner/print/PrintDesign$MealPhotos;

    sget-object v2, Lcom/quickdinner/planner/print/PrintDesign$MealPhotos;->DECIDED:Lcom/quickdinner/planner/print/PrintDesign$MealPhotos;

    if-ne v0, v2, :cond_2

    iget-boolean v0, p1, Lcom/quickdinner/planner/print/MenuData$Slot;->decided:Z

    if-nez v0, :cond_2

    return-object v1

    .line 287
    :cond_2
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->imgs:Lcom/quickdinner/planner/print/DesignRenderer$Images;

    iget-object p1, p1, Lcom/quickdinner/planner/print/MenuData$Slot;->imageUrl:Ljava/lang/String;

    invoke-interface {v0, p1}, Lcom/quickdinner/planner/print/DesignRenderer$Images;->get(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p1

    return-object p1

    :cond_3
    :goto_0
    return-object v1
.end method

.method newPage()Lcom/quickdinner/planner/print/DesignRenderer$Page;
    .locals 4

    .line 125
    new-instance v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pw:F

    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ph:F

    invoke-direct {v0, v1, v2}, Lcom/quickdinner/planner/print/DesignRenderer$Page;-><init>(FF)V

    .line 126
    iget-object v1, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda1;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 127
    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->photo:Landroid/graphics/Bitmap;

    if-eqz v1, :cond_0

    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v1, v1, Lcom/quickdinner/planner/print/PrintDesign;->photoMode:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    sget-object v2, Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;->BACKGROUND:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    if-ne v1, v2, :cond_0

    iget-boolean v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->ink:Z

    if-nez v1, :cond_0

    .line 128
    iget-object v1, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda2;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 130
    :cond_0
    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v1, v1, Lcom/quickdinner/planner/print/PrintDesign;->frame:Z

    if-eqz v1, :cond_1

    .line 131
    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    const v2, 0x3ed70a3d    # 0.42f

    mul-float/2addr v1, v2

    const/high16 v2, 0x41000000    # 8.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    .line 132
    iget-object v2, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v3, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda3;

    invoke-direct {v3, p0, v1}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda3;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;F)V

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 138
    :cond_1
    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pages:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 139
    iput-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    .line 140
    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    iput v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    return-object v0
.end method

.method placeEmpty(FFFF)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "x",
            "yy",
            "w",
            "h"
        }
    .end annotation

    .line 493
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v0, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v7, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda5;

    move-object v1, v7

    move-object v2, p0

    move v3, p1

    move v4, p2

    move v5, p3

    move v6, p4

    invoke-direct/range {v1 .. v6}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda5;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FFFF)V

    invoke-interface {v0, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method placeTile(Lcom/quickdinner/planner/print/DesignRenderer$R$Tile;FFFFFZ)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "t",
            "x",
            "yy",
            "w",
            "h",
            "round",
            "filled"
        }
    .end annotation

    move-object v9, p0

    .line 423
    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v10, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v11, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda11;

    move-object v0, v11

    move-object v1, p0

    move v2, p2

    move v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move-object v8, p1

    invoke-direct/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda11;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FFFFFZLcom/quickdinner/planner/print/DesignRenderer$R$Tile;)V

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method run()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/quickdinner/planner/print/DesignRenderer$Page;",
            ">;"
        }
    .end annotation

    .line 145
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->newPage()Lcom/quickdinner/planner/print/DesignRenderer$Page;

    .line 146
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->header()V

    .line 147
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->y:F

    .line 148
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->buildGroceryList()V

    .line 149
    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v1, v1, Lcom/quickdinner/planner/print/PrintDesign;->grocery:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    sget-object v2, Lcom/quickdinner/planner/print/PrintDesign$Grocery;->SIDE:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    if-ne v1, v2, :cond_0

    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iput-boolean v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->side:Z

    if-eqz v1, :cond_2

    .line 151
    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    iget-object v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v2, v2, Lcom/quickdinner/planner/print/PrintDesign;->landscape:Z

    if-eqz v2, :cond_1

    const v2, 0x3e6147ae    # 0.22f

    goto :goto_1

    :cond_1
    const v2, 0x3e851eb8    # 0.26f

    :goto_1
    mul-float/2addr v1, v2

    const/high16 v2, 0x42f00000    # 120.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->sideW:F

    .line 152
    invoke-virtual {p0, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->sideBar(F)V

    .line 154
    :cond_2
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->m:Lcom/quickdinner/planner/print/MenuData;

    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4

    .line 155
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->layout:Lcom/quickdinner/planner/print/PrintDesign$Layout;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$Layout;->GRID:Lcom/quickdinner/planner/print/PrintDesign$Layout;

    if-ne v0, v1, :cond_3

    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->layoutGrid()V

    goto :goto_2

    .line 156
    :cond_3
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->layoutFlow()V

    .line 158
    :cond_4
    :goto_2
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->grocNext:I

    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->groc:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_5

    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->grocery:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$Grocery;->OFF:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    if-eq v0, v1, :cond_5

    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->groceryPage()V

    goto :goto_2

    .line 159
    :cond_5
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->footers()V

    .line 160
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->pages:Ljava/util/List;

    return-object v0
.end method

.method sideBar(F)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "top"
        }
    .end annotation

    .line 585
    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->contentW:F

    add-float/2addr v0, v1

    iget v6, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->sideW:F

    sub-float v9, v0, v6

    .line 586
    iget v5, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->bottom:F

    .line 587
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v7, v0, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v8, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda8;

    move-object v0, v8

    move-object v1, p0

    move v2, v9

    move v3, p1

    move v4, v6

    invoke-direct/range {v0 .. v5}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda8;-><init>(Lcom/quickdinner/planner/print/DesignRenderer$R;FFFF)V

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v1, "Grocery list"

    const/high16 v0, 0x41300000    # 11.0f

    .line 593
    iget v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float/2addr v2, v0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v5, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->text:I

    const/high16 v0, 0x41800000    # 16.0f

    sub-float v10, v6, v0

    const/4 v7, 0x1

    sget-object v8, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    move-object v0, p0

    move v6, v10

    invoke-virtual/range {v0 .. v8}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 594
    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v1, v1, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v2, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda9;

    invoke-direct {v2, v9, p1, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda9;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/high16 v1, 0x41000000    # 8.0f

    add-float/2addr v9, v1

    add-float/2addr v1, p1

    .line 595
    invoke-virtual {v0}, Landroid/text/StaticLayout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr v1, v0

    const/high16 v0, 0x40800000    # 4.0f

    add-float/2addr v1, v0

    iget v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->bottom:F

    const/high16 v2, 0x40c00000    # 6.0f

    sub-float/2addr v0, v2

    invoke-virtual {p0, v9, v1, v10, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R;->flowGrocery(FFFF)F

    return-void
.end method

.method titlePt()F
    .locals 3

    .line 221
    sget-object v0, Lcom/quickdinner/planner/print/PrintDesign;->TITLE_SCALE:[F

    iget-object v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget v1, v1, Lcom/quickdinner/planner/print/PrintDesign;->titleSize:I

    aget v0, v0, v1

    const/high16 v1, 0x41e00000    # 28.0f

    mul-float/2addr v0, v1

    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    const v2, 0x3f99999a    # 1.2f

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    mul-float/2addr v0, v1

    return v0
.end method

.method tl(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "s",
            "size",
            "bold",
            "italic",
            "color",
            "width",
            "maxLines",
            "al"
        }
    .end annotation

    move-object v10, p0

    .line 241
    iget-object v0, v10, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v1, v0, Lcom/quickdinner/planner/print/PrintDesign;->bodyFont:Lcom/quickdinner/planner/print/PrintDesign$Font;

    move-object v0, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move/from16 v6, p5

    move/from16 v7, p6

    move/from16 v8, p7

    move-object/from16 v9, p8

    invoke-virtual/range {v0 .. v9}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlF(Lcom/quickdinner/planner/print/PrintDesign$Font;Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    return-object v0
.end method

.method tlF(Lcom/quickdinner/planner/print/PrintDesign$Font;Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "font",
            "s",
            "size",
            "bold",
            "italic",
            "color",
            "width",
            "maxLines",
            "al"
        }
    .end annotation

    .line 249
    new-instance v0, Landroid/text/TextPaint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    .line 250
    invoke-virtual {v0, p3}, Landroid/text/TextPaint;->setTextSize(F)V

    .line 251
    invoke-virtual {v0, p6}, Landroid/text/TextPaint;->setColor(I)V

    .line 252
    iget-object p1, p1, Lcom/quickdinner/planner/print/PrintDesign$Font;->family:Ljava/lang/String;

    const/4 p3, 0x0

    if-eqz p4, :cond_0

    if-eqz p5, :cond_0

    const/4 p4, 0x3

    goto :goto_0

    :cond_0
    if-eqz p4, :cond_1

    move p4, v1

    goto :goto_0

    :cond_1
    if-eqz p5, :cond_2

    const/4 p4, 0x2

    goto :goto_0

    :cond_2
    move p4, p3

    :goto_0
    invoke-static {p1, p4}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    if-nez p2, :cond_3

    const-string p2, ""

    .line 254
    :cond_3
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    float-to-int p4, p7

    invoke-static {v1, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    invoke-static {p2, p3, p1, v0, p4}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    .line 255
    invoke-static {v1, p8}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/text/StaticLayout$Builder;->setMaxLines(I)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, p2}, Landroid/text/StaticLayout$Builder;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    invoke-virtual {p1, p9}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    .line 256
    invoke-virtual {p1, p3}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object p1

    return-object p1
.end method

.method tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "s",
            "size",
            "bold",
            "italic",
            "color",
            "width",
            "maxLines",
            "al"
        }
    .end annotation

    move-object v10, p0

    .line 245
    iget-object v0, v10, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-object v1, v0, Lcom/quickdinner/planner/print/PrintDesign;->titleFont:Lcom/quickdinner/planner/print/PrintDesign$Font;

    move-object v0, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move v5, p4

    move/from16 v6, p5

    move/from16 v7, p6

    move/from16 v8, p7

    move-object/from16 v9, p8

    invoke-virtual/range {v0 .. v9}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlF(Lcom/quickdinner/planner/print/PrintDesign$Font;Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    return-object v0
.end method

.method weekdayHeader(FFF)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "yy",
            "avail",
            "cw"
        }
    .end annotation

    const/4 p2, 0x0

    :goto_0
    const/4 v0, 0x7

    if-ge p2, v0, :cond_1

    .line 503
    iget-object v0, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;

    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->sundayStart:Z

    if-eqz v0, :cond_0

    sget-object v0, Ljava/time/DayOfWeek;->SUNDAY:Ljava/time/DayOfWeek;

    goto :goto_1

    :cond_0
    sget-object v0, Ljava/time/DayOfWeek;->MONDAY:Ljava/time/DayOfWeek;

    :goto_1
    int-to-long v1, p2

    invoke-virtual {v0, v1, v2}, Ljava/time/DayOfWeek;->plus(J)Ljava/time/DayOfWeek;

    move-result-object v0

    sget-object v1, Ljava/time/format/TextStyle;->SHORT:Ljava/time/format/TextStyle;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/time/DayOfWeek;->getDisplayName(Ljava/time/format/TextStyle;Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const/high16 v0, 0x41080000    # 8.5f

    .line 504
    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->b:F

    mul-float v5, v1, v0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget v8, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->muted:I

    const/4 v10, 0x1

    sget-object v11, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    move-object v3, p0

    move v9, p3

    invoke-virtual/range {v3 .. v11}, Lcom/quickdinner/planner/print/DesignRenderer$R;->tlT(Ljava/lang/String;FZZIFILandroid/text/Layout$Alignment;)Landroid/text/StaticLayout;

    move-result-object v0

    .line 505
    iget v1, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->margin:F

    int-to-float v2, p2

    mul-float/2addr v2, p3

    add-float/2addr v1, v2

    .line 506
    iget-object v2, p0, Lcom/quickdinner/planner/print/DesignRenderer$R;->cur:Lcom/quickdinner/planner/print/DesignRenderer$Page;

    iget-object v2, v2, Lcom/quickdinner/planner/print/DesignRenderer$Page;->ops:Ljava/util/List;

    new-instance v3, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda0;

    invoke-direct {v3, v1, p1, v0}, Lcom/quickdinner/planner/print/DesignRenderer$R$$ExternalSyntheticLambda0;-><init>(FFLandroid/text/StaticLayout;)V

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
