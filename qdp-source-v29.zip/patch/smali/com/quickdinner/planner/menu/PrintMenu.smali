.class final Lcom/quickdinner/planner/menu/PrintMenu;
.super Ljava/lang/Object;
.source "PrintMenu.java"


# static fields
.field private static final DAYS_SHOWN:I = 0x1c

.field private static volatile pageCount:I


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 48
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Ljava/util/List;Ljava/util/List;)Ljava/util/List;
    .locals 0

    .line 47
    invoke-static {p0, p1}, Lcom/quickdinner/planner/menu/PrintMenu;->chosen(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$100(Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/print/PrintDesign;Ljava/util/List;ZLjava/util/List;I)V
    .locals 0

    .line 47
    invoke-static/range {p0 .. p5}, Lcom/quickdinner/planner/menu/PrintMenu;->make(Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/print/PrintDesign;Ljava/util/List;ZLjava/util/List;I)V

    return-void
.end method

.method static synthetic access$200(Landroid/content/Context;Ljava/util/List;)V
    .locals 0

    .line 47
    invoke-static {p0, p1}, Lcom/quickdinner/planner/menu/PrintMenu;->sharePictures(Landroid/content/Context;Ljava/util/List;)V

    return-void
.end method

.method static synthetic access$302(I)I
    .locals 0

    .line 47
    sput p0, Lcom/quickdinner/planner/menu/PrintMenu;->pageCount:I

    return p0
.end method

.method static synthetic access$400(Landroid/content/Context;Ljava/io/File;I)V
    .locals 0

    .line 47
    invoke-static {p0, p1, p2}, Lcom/quickdinner/planner/menu/PrintMenu;->print(Landroid/content/Context;Ljava/io/File;I)V

    return-void
.end method

.method static synthetic access$500(Landroid/content/Context;Ljava/io/File;)V
    .locals 0

    .line 47
    invoke-static {p0, p1}, Lcom/quickdinner/planner/menu/PrintMenu;->share(Landroid/content/Context;Ljava/io/File;)V

    return-void
.end method

.method static autoSubtitle(Ljava/util/List;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "days"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/time/LocalDate;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 294
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const-string v1, ""

    if-eqz v0, :cond_0

    return-object v1

    :cond_0
    const/4 v0, 0x0

    .line 295
    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/time/LocalDate;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/time/LocalDate;

    .line 296
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/time/LocalDate;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/quickdinner/planner/ui/Ui;->dateLabel(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/time/LocalDate;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "  to  "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/time/LocalDate;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/quickdinner/planner/ui/Ui;->dateLabel(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static buildData(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/util/List;Ljava/util/List;Z)Lcom/quickdinner/planner/print/MenuData;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "env",
            "days",
            "toBuy",
            "groceries"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/menu/MenuEnv;",
            "Ljava/util/List<",
            "Ljava/time/LocalDate;",
            ">;",
            "Ljava/util/List<",
            "Lcom/quickdinner/planner/model/Models$ShopItem;",
            ">;Z)",
            "Lcom/quickdinner/planner/print/MenuData;"
        }
    .end annotation

    .line 229
    new-instance v0, Lcom/quickdinner/planner/print/MenuData;

    invoke-direct {v0}, Lcom/quickdinner/planner/print/MenuData;-><init>()V

    .line 230
    invoke-virtual {p0}, Lcom/quickdinner/planner/menu/MenuEnv;->multiSlot()Z

    move-result v1

    iput-boolean v1, v0, Lcom/quickdinner/planner/print/MenuData;->multiSlot:Z

    .line 231
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/time/LocalDate;

    .line 232
    new-instance v2, Lcom/quickdinner/planner/print/MenuData$Day;

    invoke-direct {v2}, Lcom/quickdinner/planner/print/MenuData$Day;-><init>()V

    .line 233
    iput-object v1, v2, Lcom/quickdinner/planner/print/MenuData$Day;->date:Ljava/time/LocalDate;

    .line 234
    iget-object v3, p0, Lcom/quickdinner/planner/menu/MenuEnv;->notes:Ljava/util/Map;

    invoke-virtual {v1}, Ljava/time/LocalDate;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    iput-object v3, v2, Lcom/quickdinner/planner/print/MenuData$Day;->note:Ljava/lang/String;

    invoke-static {v2}, Lcom/quickdinner/planner/weather/WeatherPrint;->fill(Lcom/quickdinner/planner/print/MenuData$Day;)V

    .line 235
    iget-object v3, p0, Lcom/quickdinner/planner/menu/MenuEnv;->slots:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_0
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/quickdinner/planner/model/Models$Slot;

    .line 236
    invoke-virtual {v1}, Ljava/time/LocalDate;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v5, v4}, Lcom/quickdinner/planner/menu/MenuEnv;->resolve(Ljava/lang/String;Lcom/quickdinner/planner/model/Models$Slot;)Lcom/quickdinner/planner/logic/DayResolver$DayState;

    move-result-object v5

    .line 237
    new-instance v6, Lcom/quickdinner/planner/print/MenuData$Slot;

    invoke-direct {v6}, Lcom/quickdinner/planner/print/MenuData$Slot;-><init>()V

    .line 238
    invoke-static {v4}, Lcom/quickdinner/planner/menu/MenuLogic;->slotLabel(Lcom/quickdinner/planner/model/Models$Slot;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->label:Ljava/lang/String;

    .line 239
    sget-object v4, Lcom/quickdinner/planner/menu/PrintMenu$10;->$SwitchMap$com$quickdinner$planner$logic$DayResolver$Status:[I

    iget-object v7, v5, Lcom/quickdinner/planner/logic/DayResolver$DayState;->status:Lcom/quickdinner/planner/logic/DayResolver$Status;

    invoke-virtual {v7}, Lcom/quickdinner/planner/logic/DayResolver$Status;->ordinal()I

    move-result v7

    aget v4, v4, v7

    const/4 v7, 0x1

    if-eq v4, v7, :cond_0

    const/4 v8, 0x2

    if-eq v4, v8, :cond_1

    const/4 v8, 0x3

    if-eq v4, v8, :cond_1

    .line 255
    iput-boolean v7, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->undecided:Z

    .line 256
    iget-object v4, v5, Lcom/quickdinner/planner/logic/DayResolver$DayState;->entries:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/quickdinner/planner/model/Models$MenuEntry;

    iget-object v7, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->dishes:Ljava/util/List;

    invoke-static {v5}, Lcom/quickdinner/planner/menu/PrintMenu;->dishes(Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/util/List;

    move-result-object v5

    const-string v8, " + "

    invoke-static {v5, v8}, Lcom/quickdinner/planner/menu/PrintMenu;->join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v7, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 244
    :cond_1
    iget-object v4, v5, Lcom/quickdinner/planner/logic/DayResolver$DayState;->winnerId:Ljava/lang/String;

    invoke-static {v5, v4}, Lcom/quickdinner/planner/menu/PrintMenu;->byId(Lcom/quickdinner/planner/logic/DayResolver$DayState;Ljava/lang/String;)Lcom/quickdinner/planner/model/Models$MenuEntry;

    move-result-object v4

    if-nez v4, :cond_2

    goto :goto_1

    .line 246
    :cond_2
    iget-object v5, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->dishes:Ljava/util/List;

    invoke-static {v4}, Lcom/quickdinner/planner/menu/PrintMenu;->dishes(Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/util/List;

    move-result-object v8

    invoke-interface {v5, v8}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 247
    iput-boolean v7, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->decided:Z

    .line 248
    iget-object v5, p0, Lcom/quickdinner/planner/menu/MenuEnv;->byId:Ljava/util/Map;

    iget-object v7, v4, Lcom/quickdinner/planner/model/Models$MenuEntry;->addedBy:Ljava/lang/String;

    invoke-interface {v5, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/quickdinner/planner/model/Models$Member;

    const/4 v7, 0x0

    if-nez v5, :cond_3

    move v8, v7

    goto :goto_3

    .line 249
    :cond_3
    invoke-static {v5}, Lcom/quickdinner/planner/ui/Ui;->memberColor(Lcom/quickdinner/planner/model/Models$Member;)I

    move-result v8

    :goto_3
    iput v8, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->adderColor:I

    if-eqz v5, :cond_4

    .line 250
    iget-object v8, v5, Lcom/quickdinner/planner/model/Models$Member;->name:Ljava/lang/String;

    if-eqz v8, :cond_4

    iget-object v5, v5, Lcom/quickdinner/planner/model/Models$Member;->name:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    const-string v8, "\\s+"

    invoke-virtual {v5, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    aget-object v5, v5, v7

    iput-object v5, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->adderName:Ljava/lang/String;

    .line 251
    :cond_4
    invoke-static {p0, v4}, Lcom/quickdinner/planner/menu/PrintMenu;->imageOf(Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v6, Lcom/quickdinner/planner/print/MenuData$Slot;->imageUrl:Ljava/lang/String;

    .line 259
    :cond_5
    iget-object v4, v2, Lcom/quickdinner/planner/print/MenuData$Day;->slots:Ljava/util/List;

    invoke-interface {v4, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    .line 261
    :cond_6
    iget-object v1, v0, Lcom/quickdinner/planner/print/MenuData;->days:Ljava/util/List;

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_7
    if-eqz p3, :cond_f

    if-eqz p2, :cond_f

    .line 264
    new-instance p0, Ljava/util/ArrayList;

    sget-object p1, Lcom/quickdinner/planner/shop/ShopLogic;->CATEGORIES:Ljava/util/List;

    invoke-direct {p0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 265
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_8
    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_9

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Lcom/quickdinner/planner/model/Models$ShopItem;

    iget-object v1, p3, Lcom/quickdinner/planner/model/Models$ShopItem;->category:Ljava/lang/String;

    if-eqz v1, :cond_8

    iget-object v1, p3, Lcom/quickdinner/planner/model/Models$ShopItem;->category:Ljava/lang/String;

    invoke-interface {p0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    iget-object p3, p3, Lcom/quickdinner/planner/model/Models$ShopItem;->category:Ljava/lang/String;

    invoke-interface {p0, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_4

    .line 266
    :cond_9
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_a
    :goto_5
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_f

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 267
    new-instance p3, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;

    invoke-direct {p3}, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;-><init>()V

    .line 268
    iput-object p1, p3, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;->category:Ljava/lang/String;

    .line 269
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/quickdinner/planner/model/Models$ShopItem;

    .line 270
    iget-object v3, v2, Lcom/quickdinner/planner/model/Models$ShopItem;->category:Ljava/lang/String;

    if-nez v3, :cond_b

    const-string v3, "Other"

    goto :goto_7

    :cond_b
    iget-object v3, v2, Lcom/quickdinner/planner/model/Models$ShopItem;->category:Ljava/lang/String;

    :goto_7
    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_c

    goto :goto_6

    .line 271
    :cond_c
    iget-object v3, v2, Lcom/quickdinner/planner/model/Models$ShopItem;->amount:Ljava/lang/Double;

    iget-object v4, v2, Lcom/quickdinner/planner/model/Models$ShopItem;->unit:Ljava/lang/String;

    invoke-static {v3, v4}, Lcom/quickdinner/planner/shop/ShopLogic;->quantityText(Ljava/lang/Double;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 272
    iget-object v4, p3, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;->lines:Ljava/util/List;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_d

    iget-object v2, v2, Lcom/quickdinner/planner/model/Models$ShopItem;->name:Ljava/lang/String;

    goto :goto_8

    :cond_d
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, v2, Lcom/quickdinner/planner/model/Models$ShopItem;->name:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "  \u2014  "

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_8
    invoke-interface {v4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_6

    .line 274
    :cond_e
    iget-object p1, p3, Lcom/quickdinner/planner/print/MenuData$GroceryGroup;->lines:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_a

    iget-object p1, v0, Lcom/quickdinner/planner/print/MenuData;->groceries:Ljava/util/List;

    invoke-interface {p1, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_f
    return-object v0
.end method

.method private static byId(Lcom/quickdinner/planner/logic/DayResolver$DayState;Ljava/lang/String;)Lcom/quickdinner/planner/model/Models$MenuEntry;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "st",
            "id"
        }
    .end annotation

    .line 197
    iget-object p0, p0, Lcom/quickdinner/planner/logic/DayResolver$DayState;->entries:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/quickdinner/planner/model/Models$MenuEntry;

    iget-object v1, v0, Lcom/quickdinner/planner/model/Models$MenuEntry;->id:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method private static chosen(Ljava/util/List;Ljava/util/List;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "boxes",
            "dates"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/widget/CheckBox;",
            ">;",
            "Ljava/util/List<",
            "Ljava/time/LocalDate;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/time/LocalDate;",
            ">;"
        }
    .end annotation

    .line 150
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    .line 151
    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/CheckBox;

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/time/LocalDate;

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method private static daySummary(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "env",
            "iso"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/menu/MenuEnv;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 164
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 165
    iget-object v1, p0, Lcom/quickdinner/planner/menu/MenuEnv;->slots:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/quickdinner/planner/model/Models$Slot;

    .line 166
    invoke-static {p0, p1, v2}, Lcom/quickdinner/planner/menu/PrintMenu;->slotLines(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;Lcom/quickdinner/planner/model/Models$Slot;)Ljava/util/List;

    move-result-object v3

    .line 167
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_0

    :cond_0
    const-string v4, " + "

    .line 168
    invoke-static {v3, v4}, Lcom/quickdinner/planner/menu/PrintMenu;->join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 169
    invoke-virtual {p0}, Lcom/quickdinner/planner/menu/MenuEnv;->multiSlot()Z

    move-result v4

    if-eqz v4, :cond_1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v2}, Lcom/quickdinner/planner/menu/MenuLogic;->slotLabel(Lcom/quickdinner/planner/model/Models$Slot;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :cond_1
    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method private static dishes(Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "e"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/model/Models$MenuEntry;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 202
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 203
    iget-object v1, p0, Lcom/quickdinner/planner/model/Models$MenuEntry;->parts:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x1

    if-le v1, v2, :cond_0

    iget-object p0, p0, Lcom/quickdinner/planner/model/Models$MenuEntry;->parts:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/quickdinner/planner/model/Models$Part;

    iget-object v1, v1, Lcom/quickdinner/planner/model/Models$Part;->title:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 204
    :cond_0
    iget-object p0, p0, Lcom/quickdinner/planner/model/Models$MenuEntry;->title:Ljava/lang/String;

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    return-object v0
.end method

.method static effective(Lcom/quickdinner/planner/print/PrintDesign;Z)Lcom/quickdinner/planner/print/PrintDesign;
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "d",
            "groceries"
        }
    .end annotation

    .line 301
    invoke-virtual {p0}, Lcom/quickdinner/planner/print/PrintDesign;->copy()Lcom/quickdinner/planner/print/PrintDesign;

    move-result-object p0

    if-nez p1, :cond_0

    .line 302
    sget-object p1, Lcom/quickdinner/planner/print/PrintDesign$Grocery;->OFF:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    iput-object p1, p0, Lcom/quickdinner/planner/print/PrintDesign;->grocery:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    goto :goto_0

    .line 303
    :cond_0
    iget-object p1, p0, Lcom/quickdinner/planner/print/PrintDesign;->grocery:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    sget-object v0, Lcom/quickdinner/planner/print/PrintDesign$Grocery;->OFF:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    if-ne p1, v0, :cond_1

    sget-object p1, Lcom/quickdinner/planner/print/PrintDesign$Grocery;->SIDE:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    iput-object p1, p0, Lcom/quickdinner/planner/print/PrintDesign;->grocery:Lcom/quickdinner/planner/print/PrintDesign$Grocery;

    :cond_1
    :goto_0
    return-object p0
.end method

.method private static imageOf(Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "env",
            "e"
        }
    .end annotation

    .line 281
    iget-object v0, p1, Lcom/quickdinner/planner/model/Models$MenuEntry;->recipeId:Ljava/lang/String;

    invoke-static {p0, v0}, Lcom/quickdinner/planner/menu/PrintMenu;->urlOf(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    .line 282
    iget-object p1, p1, Lcom/quickdinner/planner/model/Models$MenuEntry;->parts:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/quickdinner/planner/model/Models$Part;

    iget-object v0, v0, Lcom/quickdinner/planner/model/Models$Part;->recipeId:Ljava/lang/String;

    invoke-static {p0, v0}, Lcom/quickdinner/planner/menu/PrintMenu;->urlOf(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    :cond_1
    return-object v0
.end method

.method private static join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "l",
            "sep"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 209
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    .line 210
    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    if-lez v1, :cond_0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 211
    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static layout(Landroid/content/Context;Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData;Ljava/lang/String;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "c",
            "d",
            "data",
            "subtitle"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/quickdinner/planner/print/PrintDesign;",
            "Lcom/quickdinner/planner/print/MenuData;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/quickdinner/planner/print/DesignRenderer$Page;",
            ">;"
        }
    .end annotation

    .line 309
    iget-object v0, p1, Lcom/quickdinner/planner/print/PrintDesign;->photoMode:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    sget-object v1, Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;->NONE:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-static {p0}, Lcom/quickdinner/planner/print/PrintPhoto;->load(Landroid/content/Context;)Landroid/graphics/Bitmap;

    move-result-object v0

    :goto_0
    if-nez v0, :cond_1

    .line 310
    iget-object v1, p1, Lcom/quickdinner/planner/print/PrintDesign;->photoMode:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    sget-object v2, Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;->NONE:Lcom/quickdinner/planner/print/PrintDesign$PhotoMode;

    if-eq v1, v2, :cond_1

    invoke-static {}, Lcom/quickdinner/planner/fx/Beverly;->on()Z

    move-result v1

    if-eqz v1, :cond_1

    const/16 v0, 0x258

    invoke-static {p0, v0}, Lcom/quickdinner/planner/fx/Beverly;->face(Landroid/content/Context;I)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 311
    :cond_1
    new-instance p0, Lcom/quickdinner/planner/print/PrintImages;

    invoke-direct {p0}, Lcom/quickdinner/planner/print/PrintImages;-><init>()V

    invoke-static {p1, p2, p3, v0, p0}, Lcom/quickdinner/planner/print/DesignRenderer;->layout(Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData;Ljava/lang/String;Landroid/graphics/Bitmap;Lcom/quickdinner/planner/print/DesignRenderer$Images;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method static loadDesign()Lcom/quickdinner/planner/print/PrintDesign;
    .locals 3

    .line 217
    :try_start_0
    invoke-static {}, Lcom/quickdinner/planner/App;->prefs()Lcom/quickdinner/planner/data/Prefs;

    move-result-object v0

    const-string v1, "printDesign"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/quickdinner/planner/data/Prefs;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 218
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Lcom/quickdinner/planner/print/PrintDesign;->fromJson(Lorg/json/JSONObject;)Lcom/quickdinner/planner/print/PrintDesign;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    .line 220
    :catch_0
    :cond_0
    new-instance v0, Lcom/quickdinner/planner/print/PrintDesign;

    invoke-direct {v0}, Lcom/quickdinner/planner/print/PrintDesign;-><init>()V

    return-object v0
.end method

.method private static make(Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/print/PrintDesign;Ljava/util/List;ZLjava/util/List;I)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0,
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "env",
            "base",
            "days",
            "shop",
            "toBuy",
            "mode"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/menu/MenuEnv;",
            "Lcom/quickdinner/planner/print/PrintDesign;",
            "Ljava/util/List<",
            "Ljava/time/LocalDate;",
            ">;Z",
            "Ljava/util/List<",
            "Lcom/quickdinner/planner/model/Models$ShopItem;",
            ">;I)V"
        }
    .end annotation

    .line 319
    iget-object v0, p0, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const/4 v1, 0x2

    if-ne p5, v1, :cond_0

    const-string v1, "Making the pictures..."

    goto :goto_0

    :cond_0
    const-string v1, "Making the PDF..."

    :goto_0
    invoke-static {v0, v1}, Lcom/quickdinner/planner/ui/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    .line 320
    invoke-static {p1, p3}, Lcom/quickdinner/planner/menu/PrintMenu;->effective(Lcom/quickdinner/planner/print/PrintDesign;Z)Lcom/quickdinner/planner/print/PrintDesign;

    move-result-object v4

    .line 321
    invoke-static {p0, p2, p4, p3}, Lcom/quickdinner/planner/menu/PrintMenu;->buildData(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/util/List;Ljava/util/List;Z)Lcom/quickdinner/planner/print/MenuData;

    move-result-object v5

    .line 322
    invoke-static {p2}, Lcom/quickdinner/planner/menu/PrintMenu;->autoSubtitle(Ljava/util/List;)Ljava/lang/String;

    move-result-object v6

    .line 323
    new-instance p1, Lcom/quickdinner/planner/menu/PrintMenu$8;

    move-object v2, p1

    move-object v3, p0

    move v7, p5

    invoke-direct/range {v2 .. v7}, Lcom/quickdinner/planner/menu/PrintMenu$8;-><init>(Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData;Ljava/lang/String;I)V

    invoke-static {p1}, Lcom/quickdinner/planner/data/Bg;->run(Ljava/lang/Runnable;)V

    return-void
.end method

.method private static print(Landroid/content/Context;Ljava/io/File;I)V
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x10,
            0x10
        }
        names = {
            "c",
            "f",
            "pages"
        }
    .end annotation

    const-string v0, "print"

    .line 405
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/print/PrintManager;

    if-nez v0, :cond_0

    const-string p1, "Printing isn\'t available on this phone."

    .line 406
    invoke-static {p0, p1}, Lcom/quickdinner/planner/ui/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    .line 407
    :cond_0
    new-instance p0, Lcom/quickdinner/planner/menu/PrintMenu$9;

    invoke-direct {p0, p2, p1}, Lcom/quickdinner/planner/menu/PrintMenu$9;-><init>(ILjava/io/File;)V

    const/4 p1, 0x0

    const-string p2, "Dinner menu"

    invoke-virtual {v0, p2, p0, p1}, Landroid/print/PrintManager;->print(Ljava/lang/String;Landroid/print/PrintDocumentAdapter;Landroid/print/PrintAttributes;)Landroid/print/PrintJob;

    return-void
.end method

.method private static quickBtn(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;Ljava/util/List;I)Landroid/view/View;
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x10,
            0x10
        }
        names = {
            "env",
            "label",
            "boxes",
            "n"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/menu/MenuEnv;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Landroid/widget/CheckBox;",
            ">;I)",
            "Landroid/view/View;"
        }
    .end annotation

    .line 144
    iget-object p0, p0, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    new-instance v0, Lcom/quickdinner/planner/menu/PrintMenu$7;

    invoke-direct {v0, p2, p3}, Lcom/quickdinner/planner/menu/PrintMenu$7;-><init>(Ljava/util/List;I)V

    const/4 p2, 0x2

    invoke-static {p0, p1, p2, v0}, Lcom/quickdinner/planner/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/widget/Button;

    move-result-object p0

    return-object p0
.end method

.method static saveDesign(Lcom/quickdinner/planner/print/PrintDesign;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "d"
        }
    .end annotation

    .line 224
    :try_start_0
    invoke-static {}, Lcom/quickdinner/planner/App;->prefs()Lcom/quickdinner/planner/data/Prefs;

    move-result-object v0

    const-string v1, "printDesign"

    invoke-virtual {p0}, Lcom/quickdinner/planner/print/PrintDesign;->toJson()Lorg/json/JSONObject;

    move-result-object p0

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v1, p0}, Lcom/quickdinner/planner/data/Prefs;->putString(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method private static share(Landroid/content/Context;Ljava/io/File;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "c",
            "f"
        }
    .end annotation

    .line 364
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.SEND"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "application/pdf"

    .line 365
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 366
    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/quickdinner/planner/print/PdfShareProvider;->uriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const-string v1, "android.intent.extra.STREAM"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const-string p1, "android.intent.extra.SUBJECT"

    const-string v1, "Dinner menu"

    .line 367
    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 p1, 0x1

    .line 368
    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :try_start_0
    const-string v1, "Share menu PDF"

    .line 370
    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    .line 371
    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 372
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p1, "No app found to share with."

    .line 374
    invoke-static {p0, p1}, Lcom/quickdinner/planner/ui/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method private static sharePictures(Landroid/content/Context;Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "c",
            "names"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 379
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 381
    :cond_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const-string v2, "android.intent.extra.STREAM"

    const/4 v3, 0x1

    if-ne v0, v3, :cond_1

    .line 382
    new-instance v0, Landroid/content/Intent;

    const-string v4, "android.intent.action.SEND"

    invoke-direct {v0, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 383
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Lcom/quickdinner/planner/print/PdfShareProvider;->uriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    goto :goto_1

    .line 385
    :cond_1
    new-instance v0, Landroid/content/Intent;

    const-string v4, "android.intent.action.SEND_MULTIPLE"

    invoke-direct {v0, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 386
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 387
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-static {v6}, Lcom/quickdinner/planner/print/PdfShareProvider;->uriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 388
    :cond_2
    invoke-virtual {v0, v2, v4}, Landroid/content/Intent;->putParcelableArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    :goto_1
    const-string v2, "image/jpeg"

    .line 390
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 391
    invoke-virtual {v0, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :try_start_0
    const-string v2, "Share menu pictures"

    .line 393
    invoke-static {v0, v2}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    .line 394
    invoke-virtual {v0, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const-string v2, "menu"

    .line 395
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lcom/quickdinner/planner/print/PdfShareProvider;->uriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    invoke-static {v2, v1}, Landroid/content/ClipData;->newRawUri(Ljava/lang/CharSequence;Landroid/net/Uri;)Landroid/content/ClipData;

    move-result-object v1

    .line 396
    :goto_2
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v3, v2, :cond_3

    new-instance v2, Landroid/content/ClipData$Item;

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Lcom/quickdinner/planner/print/PdfShareProvider;->uriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/content/ClipData$Item;-><init>(Landroid/net/Uri;)V

    invoke-virtual {v1, v2}, Landroid/content/ClipData;->addItem(Landroid/content/ClipData$Item;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    .line 397
    :cond_3
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    .line 398
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    const-string p1, "No app found to share with."

    .line 400
    invoke-static {p0, p1}, Lcom/quickdinner/planner/ui/Ui;->toast(Landroid/content/Context;Ljava/lang/String;)V

    :goto_3
    return-void
.end method

.method static show(Lcom/quickdinner/planner/menu/MenuEnv;)V
    .locals 33
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "env"
        }
    .end annotation

    move-object/from16 v10, p0

    .line 53
    iget-object v11, v10, Lcom/quickdinner/planner/menu/MenuEnv;->today:Ljava/time/LocalDate;

    .line 54
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 55
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 56
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v0}, Lcom/quickdinner/planner/ui/Ui;->vbox(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v14

    .line 58
    invoke-static {}, Lcom/quickdinner/planner/menu/PrintMenu;->loadDesign()Lcom/quickdinner/planner/print/PrintDesign;

    move-result-object v15

    const/4 v9, 0x1

    new-array v8, v9, [Z

    .line 59
    iget-boolean v0, v15, Lcom/quickdinner/planner/print/PrintDesign;->notes:Z

    const/4 v7, 0x0

    aput-boolean v0, v8, v7

    new-array v6, v9, [Z

    aput-boolean v7, v6, v7

    .line 61
    invoke-static/range {p0 .. p0}, Lcom/quickdinner/planner/menu/PrintMenu;->unpurchased(Lcom/quickdinner/planner/menu/MenuEnv;)Ljava/util/List;

    move-result-object v16

    .line 62
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->isEmpty()Z

    move-result v0

    xor-int/2addr v0, v9

    aput-boolean v0, v6, v7

    .line 63
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-virtual {v15}, Lcom/quickdinner/planner/print/PrintDesign;->summary()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/quickdinner/planner/ui/Ui;->muted(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v5

    .line 64
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v0}, Lcom/quickdinner/planner/ui/Ui;->vbox(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v4

    .line 65
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const/high16 v1, 0x41600000    # 14.0f

    invoke-static {v0, v1}, Lcom/quickdinner/planner/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    iget-object v2, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const/high16 v3, 0x41400000    # 12.0f

    invoke-static {v2, v3}, Lcom/quickdinner/planner/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    iget-object v9, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v9, v1}, Lcom/quickdinner/planner/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v9

    iget-object v1, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v1, v3}, Lcom/quickdinner/planner/ui/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {v4, v0, v2, v9, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 66
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const v1, -0xd5d1c9

    const/4 v2, 0x0

    const/high16 v3, 0x41600000    # 14.0f

    invoke-static {v0, v1, v3, v7, v2}, Lcom/quickdinner/planner/menu/Draw;->rect(Landroid/content/Context;IFIF)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 67
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const/high16 v1, 0x41700000    # 15.0f

    const v2, -0x13151c

    const-string v3, "Page design"

    const/4 v9, 0x1

    invoke-static {v0, v3, v1, v2, v9}, Lcom/quickdinner/planner/ui/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 68
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 69
    iget-object v3, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    new-instance v2, Lcom/quickdinner/planner/menu/PrintMenu$1;

    move-object v0, v2

    move-object v1, v12

    move-object/from16 v17, v12

    move-object v12, v2

    move-object v2, v13

    move-object/from16 v18, v13

    move-object v13, v3

    move-object v3, v11

    move-object/from16 v19, v11

    move-object v11, v4

    move-object/from16 v4, p0

    move-object/from16 v20, v5

    move-object v5, v15

    move-object/from16 v21, v6

    move-object/from16 v22, v15

    move v15, v7

    move-object/from16 v7, v16

    move-object/from16 v23, v8

    move-object/from16 v8, v20

    move-object/from16 v9, v23

    invoke-direct/range {v0 .. v9}, Lcom/quickdinner/planner/menu/PrintMenu$1;-><init>(Ljava/util/List;Ljava/util/List;Ljava/time/LocalDate;Lcom/quickdinner/planner/menu/MenuEnv;Lcom/quickdinner/planner/print/PrintDesign;[ZLjava/util/List;Landroid/widget/TextView;[Z)V

    const-string v0, "Design the page"

    invoke-static {v13, v0, v15, v12}, Lcom/quickdinner/planner/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/widget/Button;

    move-result-object v0

    const/16 v8, 0x8

    invoke-static {v0, v15, v8, v15, v15}, Lcom/quickdinner/planner/ui/Ui;->margins(Landroid/view/View;IIII)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v9, -0x1

    const/4 v12, -0x2

    .line 78
    invoke-static {v9, v12}, Lcom/quickdinner/planner/ui/Ui;->lp(II)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v14, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 79
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const-string v1, "Choose the days to include."

    invoke-static {v0, v1}, Lcom/quickdinner/planner/ui/Ui;->muted(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    const/16 v11, 0xc

    invoke-static {v0, v15, v11, v15, v15}, Lcom/quickdinner/planner/ui/Ui;->margins(Landroid/view/View;IIII)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 80
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v0}, Lcom/quickdinner/planner/ui/Ui;->hbox(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "Next 7 days"

    const/4 v2, 0x7

    move-object/from16 v13, v17

    .line 81
    invoke-static {v10, v1, v13, v2}, Lcom/quickdinner/planner/menu/PrintMenu;->quickBtn(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;Ljava/util/List;I)Landroid/view/View;

    move-result-object v1

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v15, v12, v7}, Lcom/quickdinner/planner/ui/Ui;->lpw(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "Next 14 days"

    const/16 v3, 0xe

    .line 82
    invoke-static {v10, v1, v13, v3}, Lcom/quickdinner/planner/menu/PrintMenu;->quickBtn(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;Ljava/util/List;I)Landroid/view/View;

    move-result-object v1

    invoke-static {v15, v12, v7}, Lcom/quickdinner/planner/ui/Ui;->lpw(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "None"

    .line 83
    invoke-static {v10, v1, v13, v15}, Lcom/quickdinner/planner/menu/PrintMenu;->quickBtn(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;Ljava/util/List;I)Landroid/view/View;

    move-result-object v1

    invoke-static {v15, v12, v7}, Lcom/quickdinner/planner/ui/Ui;->lpw(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x4

    .line 84
    invoke-static {v14, v0, v1, v1}, Lcom/quickdinner/planner/menu/Draw;->full(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move v0, v15

    :goto_0
    const/16 v1, 0x1c

    if-ge v0, v1, :cond_2

    int-to-long v3, v0

    move-object/from16 v1, v19

    .line 87
    invoke-virtual {v1, v3, v4}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    move-result-object v3

    move-object/from16 v6, v18

    .line 88
    invoke-interface {v6, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 89
    iget-object v4, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v4}, Lcom/quickdinner/planner/ui/Ui;->vbox(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v4

    .line 90
    iget-object v5, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-virtual {v3}, Ljava/time/LocalDate;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-static/range {v17 .. v17}, Lcom/quickdinner/planner/ui/Ui;->dateLabel(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-ge v0, v2, :cond_0

    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    move v2, v15

    :goto_1
    const/4 v9, 0x0

    invoke-static {v5, v7, v2, v9}, Lcom/quickdinner/planner/ui/Ui;->checkbox(Landroid/content/Context;Ljava/lang/String;ZLandroid/widget/CompoundButton$OnCheckedChangeListener;)Landroid/widget/CheckBox;

    move-result-object v2

    .line 91
    invoke-interface {v13, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 92
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 93
    invoke-virtual {v3}, Ljava/time/LocalDate;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v10, v2}, Lcom/quickdinner/planner/menu/PrintMenu;->daySummary(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    .line 94
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    const-string v2, "Nothing planned"

    goto :goto_2

    :cond_1
    const-string v3, "  \u00b7  "

    invoke-static {v2, v3}, Lcom/quickdinner/planner/menu/PrintMenu;->join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 95
    :goto_2
    iget-object v3, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v3, v2}, Lcom/quickdinner/planner/ui/Ui;->muted(Landroid/content/Context;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    const/16 v3, -0xa

    const/4 v5, 0x6

    const/16 v7, 0x28

    invoke-static {v2, v7, v3, v15, v5}, Lcom/quickdinner/planner/ui/Ui;->margins(Landroid/view/View;IIII)Landroid/view/View;

    move-result-object v2

    .line 96
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 97
    invoke-static {v14, v4, v15, v15}, Lcom/quickdinner/planner/menu/Draw;->full(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    add-int/lit8 v0, v0, 0x1

    move-object/from16 v19, v1

    move-object/from16 v18, v6

    const/4 v2, 0x7

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v9, -0x1

    goto :goto_0

    :cond_2
    move-object/from16 v6, v18

    .line 100
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const-string v1, "Also include"

    invoke-static {v0, v1}, Lcom/quickdinner/planner/ui/Ui;->sectionTitle(Landroid/content/Context;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 101
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    move-object/from16 v9, v22

    iget-boolean v1, v9, Lcom/quickdinner/planner/print/PrintDesign;->notes:Z

    new-instance v2, Lcom/quickdinner/planner/menu/PrintMenu$2;

    move-object/from16 v3, v23

    invoke-direct {v2, v3, v9}, Lcom/quickdinner/planner/menu/PrintMenu$2;-><init>([ZLcom/quickdinner/planner/print/PrintDesign;)V

    const-string v3, "Day notes"

    invoke-static {v0, v3, v1, v2}, Lcom/quickdinner/planner/ui/Ui;->checkbox(Landroid/content/Context;Ljava/lang/String;ZLandroid/widget/CompoundButton$OnCheckedChangeListener;)Landroid/widget/CheckBox;

    move-result-object v0

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 104
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Grocery list ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface/range {v16 .. v16}, Ljava/util/List;->size()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-interface/range {v16 .. v16}, Ljava/util/List;->size()I

    move-result v2

    const/4 v7, 0x1

    if-ne v2, v7, :cond_3

    const-string v2, " item)"

    goto :goto_3

    :cond_3
    const-string v2, " items)"

    :goto_3
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 105
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->isEmpty()Z

    move-result v2

    xor-int/2addr v2, v7

    new-instance v3, Lcom/quickdinner/planner/menu/PrintMenu$3;

    move-object/from16 v5, v21

    invoke-direct {v3, v5}, Lcom/quickdinner/planner/menu/PrintMenu$3;-><init>([Z)V

    .line 104
    invoke-static {v0, v1, v2, v3}, Lcom/quickdinner/planner/ui/Ui;->checkbox(Landroid/content/Context;Ljava/lang/String;ZLandroid/widget/CompoundButton$OnCheckedChangeListener;)Landroid/widget/CheckBox;

    move-result-object v0

    .line 108
    invoke-interface/range {v16 .. v16}, Ljava/util/List;->isEmpty()Z

    move-result v1

    xor-int/2addr v1, v7

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 109
    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-array v4, v7, [Lcom/quickdinner/planner/ui/Ui$Sheet;

    .line 112
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    invoke-static {v0}, Lcom/quickdinner/planner/ui/Ui;->hbox(Landroid/content/Context;)Landroid/widget/LinearLayout;

    move-result-object v3

    const/16 v0, 0x10

    .line 113
    invoke-virtual {v3, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 115
    iget-object v2, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    new-instance v1, Lcom/quickdinner/planner/menu/PrintMenu$4;

    move-object v0, v1

    move-object v8, v1

    move-object v1, v13

    move-object v11, v2

    move-object v2, v6

    move-object/from16 v29, v3

    move-object v3, v5

    move-object/from16 v30, v4

    move-object/from16 v4, p0

    move-object/from16 v31, v5

    move-object/from16 v5, v30

    move-object/from16 v32, v6

    move-object v6, v9

    move-object/from16 v7, v16

    invoke-direct/range {v0 .. v7}, Lcom/quickdinner/planner/menu/PrintMenu$4;-><init>(Ljava/util/List;Ljava/util/List;[ZLcom/quickdinner/planner/menu/MenuEnv;[Lcom/quickdinner/planner/ui/Ui$Sheet;Lcom/quickdinner/planner/print/PrintDesign;Ljava/util/List;)V

    const-string v0, "Share / email PDF"

    invoke-static {v11, v0, v15, v8}, Lcom/quickdinner/planner/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/widget/Button;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    .line 122
    invoke-static {v15, v12, v1}, Lcom/quickdinner/planner/ui/Ui;->lpw(IIF)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    move-object/from16 v8, v29

    .line 115
    invoke-virtual {v8, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 123
    iget-object v11, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    new-instance v7, Lcom/quickdinner/planner/menu/PrintMenu$5;

    move-object v0, v7

    move-object v1, v13

    move-object/from16 v2, v32

    move-object/from16 v3, v31

    move-object v12, v7

    move-object/from16 v7, v16

    invoke-direct/range {v0 .. v7}, Lcom/quickdinner/planner/menu/PrintMenu$5;-><init>(Ljava/util/List;Ljava/util/List;[ZLcom/quickdinner/planner/menu/MenuEnv;[Lcom/quickdinner/planner/ui/Ui$Sheet;Lcom/quickdinner/planner/print/PrintDesign;Ljava/util/List;)V

    const-string v0, "Print"

    const/4 v7, 0x1

    invoke-static {v11, v0, v7, v12}, Lcom/quickdinner/planner/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/widget/Button;

    move-result-object v21

    const/16 v22, 0x0

    const/16 v23, -0x2

    const/high16 v24, 0x3f800000    # 1.0f

    const/16 v25, 0x8

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    move-object/from16 v20, v8

    invoke-static/range {v20 .. v28}, Lcom/quickdinner/planner/menu/Draw;->add(Landroid/widget/LinearLayout;Landroid/view/View;IIFIIII)V

    const/16 v0, 0xc

    .line 131
    invoke-static {v14, v8, v0, v15}, Lcom/quickdinner/planner/menu/Draw;->full(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    .line 132
    iget-object v8, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    new-instance v11, Lcom/quickdinner/planner/menu/PrintMenu$6;

    move-object v0, v11

    move v9, v7

    move-object/from16 v7, v16

    invoke-direct/range {v0 .. v7}, Lcom/quickdinner/planner/menu/PrintMenu$6;-><init>(Ljava/util/List;Ljava/util/List;[ZLcom/quickdinner/planner/menu/MenuEnv;[Lcom/quickdinner/planner/ui/Ui$Sheet;Lcom/quickdinner/planner/print/PrintDesign;Ljava/util/List;)V

    const-string v0, "Share as picture(s)"

    invoke-static {v8, v0, v9, v11}, Lcom/quickdinner/planner/ui/Ui;->button(Landroid/content/Context;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/widget/Button;

    move-result-object v0

    const/16 v1, 0x8

    invoke-static {v0, v15, v1, v15, v15}, Lcom/quickdinner/planner/ui/Ui;->margins(Landroid/view/View;IIII)Landroid/view/View;

    move-result-object v0

    const/4 v1, -0x1

    const/4 v2, -0x2

    .line 139
    invoke-static {v1, v2}, Lcom/quickdinner/planner/ui/Ui;->lp(II)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    .line 132
    invoke-virtual {v14, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 140
    iget-object v0, v10, Lcom/quickdinner/planner/menu/MenuEnv;->act:Landroid/app/Activity;

    const-string v1, "Print or share the menu"

    invoke-static {v0, v1, v14}, Lcom/quickdinner/planner/ui/Ui;->sheet(Landroid/app/Activity;Ljava/lang/String;Landroid/view/View;)Lcom/quickdinner/planner/ui/Ui$Sheet;

    move-result-object v0

    aput-object v0, v30, v15

    return-void
.end method

.method private static slotLines(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;Lcom/quickdinner/planner/model/Models$Slot;)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "env",
            "iso",
            "slot"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/menu/MenuEnv;",
            "Ljava/lang/String;",
            "Lcom/quickdinner/planner/model/Models$Slot;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 176
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 177
    invoke-virtual {p0, p1, p2}, Lcom/quickdinner/planner/menu/MenuEnv;->resolve(Ljava/lang/String;Lcom/quickdinner/planner/model/Models$Slot;)Lcom/quickdinner/planner/logic/DayResolver$DayState;

    move-result-object p0

    .line 178
    sget-object p1, Lcom/quickdinner/planner/menu/PrintMenu$10;->$SwitchMap$com$quickdinner$planner$logic$DayResolver$Status:[I

    iget-object p2, p0, Lcom/quickdinner/planner/logic/DayResolver$DayState;->status:Lcom/quickdinner/planner/logic/DayResolver$Status;

    invoke-virtual {p2}, Lcom/quickdinner/planner/logic/DayResolver$Status;->ordinal()I

    move-result p2

    aget p1, p1, p2

    const/4 p2, 0x1

    if-eq p1, p2, :cond_2

    const/4 p2, 0x2

    if-eq p1, p2, :cond_1

    const/4 p2, 0x3

    if-eq p1, p2, :cond_1

    .line 188
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 189
    iget-object p0, p0, Lcom/quickdinner/planner/logic/DayResolver$DayState;->entries:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/quickdinner/planner/model/Models$MenuEntry;

    invoke-static {p2}, Lcom/quickdinner/planner/menu/PrintMenu;->dishes(Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/util/List;

    move-result-object p2

    const-string v1, " + "

    invoke-static {p2, v1}, Lcom/quickdinner/planner/menu/PrintMenu;->join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 190
    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p2, "Undecided: "

    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string p2, " / "

    invoke-static {p1, p2}, Lcom/quickdinner/planner/menu/PrintMenu;->join(Ljava/util/List;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 183
    :cond_1
    iget-object p1, p0, Lcom/quickdinner/planner/logic/DayResolver$DayState;->winnerId:Ljava/lang/String;

    invoke-static {p0, p1}, Lcom/quickdinner/planner/menu/PrintMenu;->byId(Lcom/quickdinner/planner/logic/DayResolver$DayState;Ljava/lang/String;)Lcom/quickdinner/planner/model/Models$MenuEntry;

    move-result-object p0

    if-eqz p0, :cond_2

    .line 184
    invoke-static {p0}, Lcom/quickdinner/planner/menu/PrintMenu;->dishes(Lcom/quickdinner/planner/model/Models$MenuEntry;)Ljava/util/List;

    move-result-object p0

    invoke-interface {v0, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_2
    :goto_1
    return-object v0
.end method

.method private static unpurchased(Lcom/quickdinner/planner/menu/MenuEnv;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "env"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/quickdinner/planner/menu/MenuEnv;",
            ")",
            "Ljava/util/List<",
            "Lcom/quickdinner/planner/model/Models$ShopItem;",
            ">;"
        }
    .end annotation

    .line 156
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 157
    iget-object p0, p0, Lcom/quickdinner/planner/menu/MenuEnv;->store:Lcom/quickdinner/planner/data/Store;

    iget-object p0, p0, Lcom/quickdinner/planner/data/Store;->shopItems:Lcom/quickdinner/planner/data/Coll;

    invoke-virtual {p0}, Lcom/quickdinner/planner/data/Coll;->all()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/quickdinner/planner/model/Models$ShopItem;

    iget-boolean v2, v1, Lcom/quickdinner/planner/model/Models$ShopItem;->purchased:Z

    if-nez v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method private static urlOf(Lcom/quickdinner/planner/menu/MenuEnv;Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "env",
            "recipeId"
        }
    .end annotation

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    .line 288
    :cond_0
    iget-object p0, p0, Lcom/quickdinner/planner/menu/MenuEnv;->store:Lcom/quickdinner/planner/data/Store;

    iget-object p0, p0, Lcom/quickdinner/planner/data/Store;->recipes:Lcom/quickdinner/planner/data/Coll;

    invoke-virtual {p0, p1}, Lcom/quickdinner/planner/data/Coll;->get(Ljava/lang/String;)Lcom/quickdinner/planner/model/Models$Doc;

    move-result-object p0

    check-cast p0, Lcom/quickdinner/planner/model/Models$Recipe;

    if-eqz p0, :cond_2

    .line 289
    iget-object p1, p0, Lcom/quickdinner/planner/model/Models$Recipe;->imageUrl:Ljava/lang/String;

    if-eqz p1, :cond_2

    iget-object p1, p0, Lcom/quickdinner/planner/model/Models$Recipe;->imageUrl:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    .line 290
    :cond_1
    iget-object p0, p0, Lcom/quickdinner/planner/model/Models$Recipe;->imageUrl:Ljava/lang/String;

    return-object p0

    :cond_2
    :goto_0
    return-object v0
.end method
