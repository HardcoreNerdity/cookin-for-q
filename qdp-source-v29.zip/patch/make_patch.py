#!/usr/bin/env python3
"""Builds patch/patched.dex: the original PrintMenu and DesignRenderer$R with two small hooks for the weather line.
Needs the decoded original smali in patch/orig_smali (made by: java -jar tc/apktool.jar d -r -f -o patch/orig_apk <original apk>)."""
import os, re, subprocess, shutil, sys
H = os.path.dirname(os.path.abspath(__file__))
base = os.path.join(H, 'orig_apk', 'smali', 'com', 'quickdinner', 'planner')
out = os.path.join(H, 'smali', 'com', 'quickdinner', 'planner')
shutil.rmtree(os.path.join(H, 'smali'), ignore_errors=True)
os.makedirs(os.path.join(out, 'menu')); os.makedirs(os.path.join(out, 'print'))

# 1) PrintMenu.buildData: after each day's note is read, ask WeatherPrint to fill in the weather.
p = os.path.join(base, 'menu', 'PrintMenu.smali')
s = open(p).read()
old = "    iput-object v3, v2, Lcom/quickdinner/planner/print/MenuData$Day;->note:Ljava/lang/String;\n"
assert s.count(old) == 1
s = s.replace(old, old + "\n    invoke-static {v2}, Lcom/quickdinner/planner/weather/WeatherPrint;->fill(Lcom/quickdinner/planner/print/MenuData$Day;)V\n")
open(os.path.join(out, 'menu', 'PrintMenu.smali'), 'w').write(s)

# 2) DesignRenderer$R.buildTile: the day-note line also carries the weather.
p = os.path.join(base, 'print', 'DesignRenderer$R.smali')
s = open(p).read()
old = re.compile(
    r"    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer\$R;->d:Lcom/quickdinner/planner/print/PrintDesign;\n\n"
    r"    iget-boolean v0, v0, Lcom/quickdinner/planner/print/PrintDesign;->notes:Z\n\n"
    r"    if-eqz v0, :cond_29\n\n"
    r"    move-object/from16 v0, p1\n\n"
    r"    iget-object v1, v0, Lcom/quickdinner/planner/print/MenuData\$Day;->note:Ljava/lang/String;\n\n"
    r"    if-eqz v1, :cond_29\n\n"
    r"    iget-object v1, v0, Lcom/quickdinner/planner/print/MenuData\$Day;->note:Ljava/lang/String;\n\n"
    r"    invoke-virtual \{v1\}, Ljava/lang/String;->isEmpty\(\)Z\n\n"
    r"    move-result v1\n\n"
    r"    if-nez v1, :cond_29\n\n"
    r"(?:    \.line 396\n)"
    r"    new-instance v1, Ljava/lang/StringBuilder;\n\n"
    r"    const-string v2, \"Note: \"\n\n"
    r"    invoke-direct \{v1, v2\}, Ljava/lang/StringBuilder;-><init>\(Ljava/lang/String;\)V\n\n"
    r"    iget-object v0, v0, Lcom/quickdinner/planner/print/MenuData\$Day;->note:Ljava/lang/String;\n\n"
    r"    invoke-virtual \{v1, v0\}, Ljava/lang/StringBuilder;->append\(Ljava/lang/String;\)Ljava/lang/StringBuilder;\n\n"
    r"    invoke-virtual \{v1\}, Ljava/lang/StringBuilder;->toString\(\)Ljava/lang/String;\n\n"
    r"    move-result-object v1\n")
new = (
    "    iget-object v0, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;\n\n"
    "    move-object/from16 v1, p1\n\n"
    "    invoke-static {v0, v1}, Lcom/quickdinner/planner/weather/WeatherPrint;->hasNote(Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData$Day;)Z\n\n"
    "    move-result v0\n\n"
    "    if-eqz v0, :cond_29\n\n"
    "    move-object/from16 v0, p1\n\n"
    "    .line 396\n"
    "    iget-object v1, v9, Lcom/quickdinner/planner/print/DesignRenderer$R;->d:Lcom/quickdinner/planner/print/PrintDesign;\n\n"
    "    invoke-static {v1, v0}, Lcom/quickdinner/planner/weather/WeatherPrint;->noteText(Lcom/quickdinner/planner/print/PrintDesign;Lcom/quickdinner/planner/print/MenuData$Day;)Ljava/lang/String;\n\n"
    "    move-result-object v1\n")
s2, n = old.subn(lambda m: new, s)
assert n == 1, "DesignRenderer pattern matched %d times" % n
open(os.path.join(out, 'print', 'DesignRenderer$R.smali'), 'w').write(s2)

subprocess.check_call(['java', '-cp', os.path.join(H, 'tool') + ':' + os.path.join(H, '..', 'tc', 'apktool.jar'), 'SmaliRun',
                       os.path.join(H, 'smali'), os.path.join(H, 'patched.dex')])
print('patched.dex ok')
