import brut.androlib.mod.SmaliMod;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.writer.builder.DexBuilder;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import java.io.File;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class SmaliRun {
    public static void main(String[] a) throws Exception {
        DexBuilder b = new DexBuilder(new Opcodes(26, 0));
        List<Path> files;
        try (Stream<Path> w = Files.walk(Paths.get(a[0]))) { files = w.filter(p -> p.toString().endsWith(".smali")).collect(Collectors.toList()); }
        for (Path p : files) {
            if (!SmaliMod.assembleSmaliFile(p.toFile(), b, 26)) { System.err.println("failed: " + p); System.exit(1); }
        }
        b.writeTo(new FileDataStore(new File(a[1])));
        System.out.println("assembled " + files.size() + " files");
    }
}
