#!/bin/bash
# Hybrid build: new/changed classes come from app/src (compiled here); everything else is the original v28 bytecode (legacy/classes.dex).
# Usage: VERSION_CODE=29 VERSION_NAME=29 ./build2.sh out.apk
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TC="$HERE/tc"; APP="$HERE/app"; LEG="$HERE/legacy"
OUT="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
B="$HERE/build/hybrid"; MIN_SDK=26
rm -rf "$B"; mkdir -p "$B/flat" "$B/classes" "$B/dex"
clean() { grep -v JAVA_TOOL_OPTIONS || true; }
find "$APP/res" -type f | while read -r f; do "$TC/aapt2" compile "$f" -o "$B/flat/"; done
FLATS=$(find "$B/flat" -name '*.flat' | tr '\n' ' ')
"$TC/aapt2" link -o "$B/base.apk" -I "$TC/android.jar" --manifest "$APP/AndroidManifest.xml" \
  --min-sdk-version $MIN_SDK --target-sdk-version 33 --version-code "${VERSION_CODE:-1}" --version-name "${VERSION_NAME:-1.0}" \
  --auto-add-overlay -A "$APP/assets" $FLATS
cp "$B/base.apk" "$B/unsigned.apk"
SRCS=$(find "$APP/src" -name '*.java' 2>/dev/null || true)
if [ -n "$SRCS" ]; then
  javac -parameters -nowarn --release 8 -encoding UTF-8 -Xlint:-options -classpath "$TC/android.jar:$LEG/app.jar" -d "$B/classes" $SRCS 2>&1 | clean
  [ "${PIPESTATUS[0]}" -eq 0 ] || { echo "javac FAILED"; exit 1; }
  find "$B/classes" -name '*.class' > "$B/classlist.txt"
  java -cp "$TC/d8.jar" com.android.tools.r8.D8 --release --min-api $MIN_SDK --lib "$TC/android.jar" \
    --classpath "$LEG/app.jar" --output "$B/dex" @"$B/classlist.txt" 2>&1 | clean
  cp "$B/dex/classes.dex" "$B/classes.dex"
  cp "$HERE/patch/patched.dex" "$B/classes2.dex"
  cp "$LEG/classes.dex" "$B/classes3.dex"
  ( cd "$B" && zip -q -j unsigned.apk classes.dex classes2.dex classes3.dex )
else
  cp "$LEG/classes.dex" "$B/classes.dex"
  ( cd "$B" && zip -q -j unsigned.apk classes.dex )
fi
python3 -I "$TC/zipalign.py" "$B/unsigned.apk" "$B/aligned.apk"
java -jar "$TC/apksigner.jar" sign --ks "$TC/qdp.keystore" --ks-pass pass:quickdinner --key-pass pass:quickdinner \
  --ks-key-alias qdp --min-sdk-version $MIN_SDK --out "$OUT" "$B/aligned.apk" 2>&1 | clean
java -jar "$TC/apksigner.jar" verify --print-certs --min-sdk-version $MIN_SDK "$OUT" 2>&1 | clean | head -4
echo "OK -> $OUT ($(du -h "$OUT" | cut -f1))"
