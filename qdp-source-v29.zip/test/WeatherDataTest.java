import com.quickdinner.planner.weather.WeatherData;
import java.util.*;

public class WeatherDataTest {
    static int fails = 0;
    static void ok(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL " + m); } }
    public static void main(String[] a) {
        String f = "{\"daily\":{\"time\":[\"2026-11-16\",\"2026-11-17\"],\"weather_code\":[0,63],\"temperature_2m_max\":[54.4,61.6],\"temperature_2m_min\":[38.2,49.5]}}";
        Map<String, WeatherData.Day> m = WeatherData.parseForecast(f);
        ok(m.size() == 2, "two days");
        WeatherData.Day d = m.get("2026-11-17");
        ok(d != null && d.hi == 62 && d.lo == 50 && d.code == 63, "rounding");
        ok(WeatherData.words(63).equals("Rain") && WeatherData.words(0).equals("Clear") && WeatherData.words(95).equals("Thunderstorms"), "words");
        ok(WeatherData.printLine(d).equals("Rain, high 62°, low 50°"), "print line");
        ok(WeatherData.shortLine(m.get("2026-11-16")).endsWith("54°/38°"), "short line");
        ok(WeatherData.parseForecast("junk").isEmpty() && WeatherData.parseForecast("{}").isEmpty(), "bad input");
        String nulls = "{\"daily\":{\"time\":[\"2026-11-16\"],\"weather_code\":[null],\"temperature_2m_max\":[null],\"temperature_2m_min\":[1]}}";
        ok(WeatherData.parseForecast(nulls).isEmpty(), "null temps skipped");
        String g = "{\"results\":[{\"name\":\"Albany\",\"latitude\":42.65258,\"longitude\":-73.75623,\"country\":\"United States\",\"admin1\":\"New York\"},{\"name\":\"Albany\",\"latitude\":-35.02,\"longitude\":117.88,\"country\":\"Australia\"}]}";
        List<WeatherData.Place> p = WeatherData.parsePlaces(g);
        ok(p.size() == 2 && p.get(0).label().equals("Albany, New York, United States") && p.get(1).label().equals("Albany, Australia"), "places");
        ok(WeatherData.parsePlaces("{}").isEmpty(), "no results");
        ok(WeatherData.coarse(42.65258).equals("42.7") && WeatherData.coarse(-73.75623).equals("-73.8"), "coarse");
        String u = WeatherData.forecastUrl(42.65258, -73.75623, true);
        ok(u.contains("latitude=42.7") && u.contains("longitude=-73.8") && u.contains("fahrenheit") && u.startsWith("https://"), "url");
        ok(WeatherData.placesUrl("New York").contains("name=New+York"), "places url");
        System.out.println(fails == 0 ? "ALL PASS" : fails + " FAILED");
    }
}
